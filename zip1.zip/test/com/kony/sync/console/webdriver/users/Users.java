package com.kony.sync.console.webdriver.users;

import java.text.SimpleDateFormat;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Users extends BaseTestcase{

	private static WebDriverWait wait=null;
	private static String alertText=null;
	private static String status=null;
	private static List<WebElement> selectedOptions=null;
	
	/**
	 * Navigate to the users page.
	 * @param driver
	 */
	
	public static void navigateToUsersHomePage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_users")));
		waitForElement(driver, By.id(configObj.getPropertyValue("btn_addUser")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while navigating to the groups home page.");
			e.printStackTrace();
		}
		
	}
	
	/**
	 * add user to the application.
	 * @param driver
	 * @param userID
	 * @param password
	 * @param userName
	 * @param email
	 * @param mobile
	 * @param euID
	 * @return success message if user added successfully, else null.
	 */
	
	public static String add(WebDriver driver, String userID, String password, String userName, String email, String mobile, String euID){
		
		status=null;
		try{
			  
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
			  driver.switchTo().activeElement();
			  waitForElement(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")));
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), userID);
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), password);
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), password);
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), userName);
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), email);
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), mobile);
			  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEnterpriseUserID")), euID);
			  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
			  
			  SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("msg_addUserStatus")));
			  status = SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("msg_addUserStatus")));
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addUserCancel")));
			    
			  }catch(Exception e)
			  {
				  Reporter.log("ERROR: problem occurred while creating a user.");
				  e.printStackTrace();
			  }
			  return status;
		
	}
	
	/**
	 * delete user from the application.
	 * @param driver
	 * @param userid
	 */
	
	public static void delete(WebDriver driver, String userid){
		
		try{
		waitForElement(driver, By.id(configObj.getPropertyValue("btn_addUser")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), userid+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		waitForElement(driver, By.xpath(configObj.getPropertyValue("grid_usersRow")));
		select(driver, userid);
		SeleniumUtil.clickAndWait(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteUser")),1000);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		SeleniumUtil.delay(500);
		}catch(Exception e){
			 
			Reporter.log("ERROR: problem occurred while deleting a user.");
			e.printStackTrace();
		}
		
	}
	
	/**
	 * edit existing user profile.
	 * @param driver
	 * @param userid
	 * @param userName
	 * @param email
	 * @param mobile
	 * @param eUID
	 * @return success message if user profile edited successfully, else null. 
	 */
	
	public static String edit(WebDriver driver,String userID, String userName, String email, String mobile, String eUID){
		
		status=null;
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), userID+Keys.RETURN);
			SeleniumUtil.waitForElement(driver, By.linkText(userID));
			SeleniumUtil.delay(2000);
			SeleniumUtil.click(driver, By.linkText(userID));
			SeleniumUtil.delay(2000);
		  waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		  
		  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), userName);
		  
		  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), email);
		  
		  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), mobile);
		  
		  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEnterpriseUserID")), eUID);
		
		  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
		  SeleniumUtil.delay(6000);
		  SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus")), "User updated successfully.");
		  status = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus")));
		}catch(Exception e){
			
			Reporter.log("ERROR: problem occurred while editing a user.");
			e.printStackTrace();
		}
		  return status;
	}
	
	
	public static String changePassword(WebDriver driver, String userID, String newPassword){
		
		status=null;
		try{
			SeleniumUtil.click(driver, By.linkText(userID));
		waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), newPassword);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), newPassword);
	
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_changePasswordStatus")), "Password changed successfully.");
		status = SeleniumUtil.getVisibleText(driver,  By.id(configObj.getPropertyValue("msg_changePasswordStatus")));
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_Cancel")));
		}catch(Exception e){
			
			Reporter.log("ERROR: problem occurred while changing user password.");
			e.printStackTrace();
		}
		
		return status;
	}
	
	
	/**
	   * search for a record in a grid
	   * @param by
	   * @param searchText
	   * @return number of rows
	   */
	  
	  public static int search(WebDriver driver, By by,String searchText){
		  
		  List<WebElement>  rows = null;
		  try { 
			  SeleniumUtil.setText(driver, by, searchText+Keys.RETURN);  
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  SeleniumUtil.delay(1000);
		  rows = driver.findElements(By.xpath(configObj.getPropertyValue("grid_usersRowCount")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		  
		  return rows.size();	  
	  }
	  
	  /**
	   * set status to user profile.
	   * @param driver
	   * @param status
	   */
	  
	  public static void setStatus(WebDriver driver,String status){
		  
		  try{
			  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectStatus")))).selectByVisibleText(status);
			  }catch(Exception e){
				  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
				  e.printStackTrace();
			  }
		  
	  }
	  
	  /**
	   * Type the given text into the text box.
	   * @param driver
	   * @param by
	   * @param text
	   */
	  
	  public static void type(WebDriver driver, By by, String text){
		  
		  try{
			  SeleniumUtil.setText(driver, by, text);
		  }catch(Exception e){
			  Reporter.log("ERROR: Problem occurred while typing the given text in the text box.");
			  e.printStackTrace();
		  }
		  
	  }
	  
	  /**
	   * Get all the group names attached to a user.
	   * @param driver
	   * @return list of available options
	   */
	  
	  public static List<WebElement> getAllAvailableGroups(WebDriver driver){
		  
		  selectedOptions=null;
		  try{
		  selectedOptions = new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_availableGroups")))).getOptions();
		  }catch(Exception e){
			  e.printStackTrace();
		  }
		  return selectedOptions;
		  
	  }
	  
	  /**
	   * Get all the group names available for a user.
	   * @param driver
	   * @return list of available options
	   */
	  
	  public static List<WebElement> getAllAttachedGroups(WebDriver driver){
		  
		  selectedOptions=null;
		  try{
		  selectedOptions = new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectedGroups")))).getOptions();
		 
		  }catch(Exception e){
			  e.printStackTrace();
		  }
		 
		return selectedOptions;
	  
	  }
	  
	  
	  /**
	   * select the group name which are available for a user.
	   * @param driver
	   * @param groupName
	   */
	  
	  public static void selectGroupFromAvailableGroups(WebDriver driver, String groupName){
		  
		  try{
			  boolean flag=true;
			  List<WebElement> groups = driver.findElements(By.xpath(configObj.getPropertyValue("list_users_attachedGroups"))); 
			  for(WebElement element:groups)
			  {
				  if(element.getText().equalsIgnoreCase(groupName))
				  {
					  flag=false;
					  break;
				  }
			  }
			  if(flag)
			  {
			  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_availableGroups")))).selectByVisibleText(groupName);
			  }
			  }catch(Exception e){
				  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
				  e.printStackTrace();
			  }
		  
	  }
	  
	  /**
	   * select the group name which are assigned to a user.
	   * @param driver
	   * @param groupName
	   */
	  
	  public static void selectGroupFromAssignedGroups(WebDriver driver, String groupName){
		  
		  try{
			  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectedGroups")))).selectByVisibleText(groupName);
			  }catch(Exception e){
				  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
				  e.printStackTrace();
			  }
		  
	  }
	  
	  
	  
	  /**
	   * assign group to a user.
	   * @param driver
	   * @param userID
	   * @param groupName
	   */
	  
	  public static void assignGroup(WebDriver driver, String userID, String groupName){
		  
		  try{
		  selectGroupFromAvailableGroups(driver, groupName);
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_attachGroup")));
		  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
		  
		  }catch(Exception e){
			  e.printStackTrace();
		  }
		  
	  }
	  
	  /**
	   * DeAssigns group for that user
	   * @param driver
	   * @param groupName
	   */
	  
	  public static void deAssignGroup(WebDriver driver, String groupName){
		  
		  try{
			  selectGroupFromAssignedGroups(driver, groupName);
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_detachGroup")));
			  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
			  }catch(Exception e){
				  e.printStackTrace();
			  }
		  
	  }
	  
	  
	 /**
	  * close the alert and return the text present on the alert box
	  * @return text
	  */
	  
	  public static String closeAlertAndGetItsText(WebDriver driver, boolean acceptAlert) {
		  
		  	alertText=null;
		    try {
		      Alert alert = driver.switchTo().alert();
		       alertText = alert.getText();
		      if (acceptAlert) {
		        alert.accept();
		      } else {
		        alert.dismiss();
		      }
		      return alertText;
		    }finally{
		    	acceptAlert=false;
		    }
		    
		  }
	
	 /**
	   * wait for an element until it displayed on the page otherwise timeout after 10 seconds.
	   * @param driver
	   * @param byElement
	   * @return byElement
	   */
	  
	  public static By waitForElement(WebDriver driver, By byElement){
		  
		  wait = new WebDriverWait(driver, 10L);
		  try{
		  wait.until(ExpectedConditions.visibilityOfElementLocated(byElement));
		  
		  }catch(Exception e){
			  Reporter.log("FAILURE: waitForElement, "+byElement+" has not found. TIMED OUT AFTER 10 SECONDS. \n"+e);
		  }
		return byElement;
		
	  }
	
	 /**
	   * check if element is present on the page
	   * @param by
	   * @return true or false
	   */
	  
	  public static boolean isElementPresent(WebDriver driver, By by) {
		  
		  boolean flag=false;
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		      flag = false;
		    }
		    return flag;
		    
		  }
	
	  /**
	   * check if search of insertedOnDate displays correct data
	   * @param driver
	   * @param insertedOnDate
	   * @return true or false
	   */
	  
	  public static boolean verifyInsertedOnSearch(WebDriver driver, String insertedOnDate)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  int rowCount=search(driver, By.id(configObj.getPropertyValue("tbx_users_searchByInsertedOn")), insertedOnDate);
			  if(rowCount>0)
			  {
				  for(int i=2; i<=rowCount+1; i++){
					  SeleniumUtil.waitForElement(driver, By.xpath("//tr["+i+"]/td[8]"));
					  if(!(fmt.parse(SeleniumUtil.findElement(driver,By.xpath("//tr["+i+"]/td[8]")).getText()).getTime()>=fmt.parse(insertedOnDate).getTime())){
						  return false;
					  }
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
	   * check if search of updatedOnDate displays correct data
	   * @param driver
	   * @param updatedOnDate
	   * @return true or false
	   */
	  
	  public static boolean verifyUpdatedOnSearch(WebDriver driver, String updatedOnDate)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  int rowCount=search(driver, By.id(configObj.getPropertyValue("tbx_users_searchByUpdatedOn")), updatedOnDate);
			  if(rowCount>0)
			  {
				  for(int i=2; i<=rowCount+1; i++){
					  SeleniumUtil.waitForElement(driver, By.xpath("//tr["+i+"]/td[9]"));
					  if(!(fmt.parse(SeleniumUtil.findElement(driver,By.xpath("//tr["+i+"]/td[9]")).getText()).getTime()<=fmt.parse(updatedOnDate).getTime())){
						  return false;
					  }
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
	   * check if search of insertedOnDate and updatedOnDate together displays correct data
	   * @param driver
	   * @param insertedOnDate
	   * @param updatedOnDate
	   * @return true or false
	   */
	  
	  public static boolean verifyInsertedOnUpdatedOnSearch(WebDriver driver,String insertedOnDate, String updatedOnDate)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  search(driver, By.id(configObj.getPropertyValue("tbx_users_searchByInsertedOn")), insertedOnDate);
			  int rowCount=search(driver, By.id(configObj.getPropertyValue("tbx_users_searchByUpdatedOn")), updatedOnDate);
			  if(rowCount>0)
			  {
				for (int i = 2; i <= rowCount + 1; i++) {
					SeleniumUtil.waitForElement(driver,
							By.xpath("//tr[" + i + "]/td[9]"));
					if (!((fmt.parse(
							SeleniumUtil.findElement(driver,
									By.xpath("//tr[" + i + "]/td[8]"))
									.getText()).getTime() >= fmt.parse(
							insertedOnDate).getTime()) && (fmt.parse(
							SeleniumUtil.findElement(driver,
									By.xpath("//tr[" + i + "]/td[8]"))
									.getText()).getTime() <= fmt.parse(
							updatedOnDate).getTime())))
					{
						return false;
					}
							if (!((fmt.parse(
									SeleniumUtil.findElement(driver,
											By.xpath("//tr[" + i + "]/td[9]"))
											.getText()).getTime() >= fmt.parse(
									insertedOnDate).getTime()) && (fmt.parse(
									SeleniumUtil.findElement(driver,
											By.xpath("//tr[" + i + "]/td[9]"))
											.getText()).getTime() <= fmt.parse(
									updatedOnDate).getTime()))) {
						return false;
					}
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
		 * search by status
		 * @param driver
		 * @param searchKey
		 */
	  
	  public static boolean searchByStatus(WebDriver driver, String searchKey){
		  
		  try{
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_userStatusSearchDropDown")));
			  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_userStatusSearchTypes")));
			  for (WebElement option : options) {
			     if(searchKey.equalsIgnoreCase(option.getText()))
			     {
			        option.click();
			     	break;
			     }
			  }
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  List<WebElement> rows  = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_users"))).findElements(By.tagName("tr"));
			  int rowCount = rows.size();
			  if(rowCount > 1){
				  for(int i=2; i<=rowCount; i++){
					  if(!SeleniumUtil.findElement(driver,By.xpath("//tr["+i+"]/td[7]//a/span")).getText().equalsIgnoreCase(searchKey)){
					  return false;
					  }
				  }
			  }
			  else{
				  Assert.fail("Data is not existing in the table to perform search operation");
				  return false;
			  }
			  return true;
		  }catch(Exception e){
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
		 * change user status
		 * @param driver
		 * @param searchKey
		 */
	  
		public static void changeUserStatus(WebDriver driver, String searchKey){
			try{

				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_userStatusDropDown")));
				  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_userStatusypes")));
				  for (WebElement option : options) {
				     if(searchKey.equalsIgnoreCase(option.getText()))
				     {
				        option.click();
				     	break;
				     }
				  }
				  
				SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		
		/**
		 * select the userID from the grid
		 * @param driver
		 * @param authName
		 * @return boolean flag
		 */
		
		public static boolean select(WebDriver driver, String userID){
			
			boolean flag=false;
			try{
				WebElement	table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_users")));
				List<WebElement> rows  =	table.findElements(By.tagName("tr"));
				int rowCount = rows.size();
				if(rowCount > 1){
					
					for(int i=2; i<=rowCount; i++){
						SeleniumUtil.waitForElement(driver, By.xpath("//tr["+i+"]/td[3]/a/span"));
						if(table.findElement(By.xpath("//tr["+i+"]/td[3]/a/span")).getText().equals(userID)){
							SeleniumUtil.findElement(driver,By.xpath("//table[@id='usergrid']/tbody/tr["+i+"]/td[1]/input")).click();
								flag=true;
								break;
							}
					}
					if(!flag){
						Assert.fail("User Id is not found in the table to delete");
					}
				}else{
					Assert.fail("No record exist in the table");
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		
			return flag;
		}
		
		/**
		   * assign device to a user.
		   * @param driver
		   * @param userID
		   * @param deviceId
		   */
		
		  public static void assignDevice(WebDriver driver, String deviceId){
			  
			  try{
			  selectDeviceFromAvailableDevices(driver, deviceId);
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_attachDevice")));
			  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
			  
			  }catch(Exception e){
				  e.printStackTrace();
			  }
			  
		  }		
		
		  /**
		   * select the device which is available for a user.
		   * @param driver
		   * @param deviceId
		   */
		  
		  public static void selectDeviceFromAvailableDevices(WebDriver driver, String deviceId){
			  
			  try{
				  boolean flag=true;
				  List<WebElement> devices = driver.findElements(By.xpath(configObj.getPropertyValue("list_users_attachedDevices"))); 
				  for(WebElement element:devices)
				  {
					  if(element.getText().equalsIgnoreCase(deviceId))
					  {
						  flag=false;
						  break;
					  }
				  }
				  if(flag)
				  {
				  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_availableDevices")))).selectByVisibleText(deviceId);
				  }
				  }catch(Exception e){
					  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
					  e.printStackTrace();
				  }
			  
		  }
		
		  /**
		   * Get all the device ids available for a user.
		   * @param driver
		   * @return list of available options
		   */
		  
		  public static List<WebElement> getAllAttachedDevices(WebDriver driver){
			  
			  selectedOptions=null;
			  try{
			  selectedOptions = new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectedDevices")))).getOptions();
			 
			  }catch(Exception e){
				  e.printStackTrace();
			  }
			 
			return selectedOptions;
		  
		  }
		  
		  /**
		   * DeAssigns the device for that user
		   * @param driver
		   * @param deviceId
		   */
		  
		  public static void deAssignDevice(WebDriver driver, String deviceId){
			  
			  try{
				  selectDeviceFromAssignedDevices(driver, deviceId);
				  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_detachDevice")));
				  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
				  }catch(Exception e){
					  e.printStackTrace();
				  }
			  
		  }
		  
		  /**
		   * select the device id which is assigned to a user.
		   * @param driver
		   * @param deviceId
		   */
		  
		  public static void selectDeviceFromAssignedDevices(WebDriver driver, String deviceId){
			  
			  try{
				  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectedDevices")))).selectByVisibleText(deviceId);
				  }catch(Exception e){
					  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
					  e.printStackTrace();
				  }
			  
		  }
}
