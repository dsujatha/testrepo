
package com.kony.sync.console.webdriver.users;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.devices.Devices;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;



public class UsersTest extends BaseTestcase{
	
	@BeforeTest	
	public void loadDriver() {
		
		try {
			super.setUp();
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			Users.navigateToUsersHomePage(driver);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-228:Add User
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddUser(){
		
		//Don't delete the commented part
	/*	String userId= "SampleUser"+new Random().nextInt(200);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), userId);
		driver.findElement(By.id(configObj.getPropertyValue("tbx_searchByUserID"))).clear();
		if(!Users.isElementPresent(driver, By.linkText(userId))){
			Assert.assertEquals(Users.add(driver, userId, "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony"),"User "+userId+" added successfully.");
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), userId);
		    Assert.assertTrue(Users.isElementPresent(driver, By.linkText(userId)),"User is not added");
		}
		else{
			userId= "SampleUser"+new Random().nextInt(200);
			Assert.assertEquals(Users.add(driver, userId, "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony"),"User "+userId+" added successfully.");
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), userId);
		    Assert.assertTrue(Users.isElementPresent(driver, By.linkText(userId)),"User is not added");
		}*/
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(Users.isElementPresent(driver, By.linkText("SampleUser"))){
			
			Users.delete(driver, "SampleUser");
	}

	Assert.assertEquals(Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony"),"User SampleUser added successfully.");
	Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
    Assert.assertTrue(Users.isElementPresent(driver, By.linkText("SampleUser")));
    SeleniumUtil.verifySecurityAudit(driver, "ADDED_USER(SampleUser)", "Created new user");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 *   Sync-229:Edit User
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditUser(){
		
		try{
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser38");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
			if(!Users.isElementPresent(driver, By.linkText("SampleUser38"))){
				Users.add(driver, "SampleUser38", "SampleUser123", "Sample User", "kony@sync.com", "1234567890", "kony");
			}
			SeleniumUtil.delay(2000);
		    Assert.assertEquals(Users.edit(driver, "SampleUser38", "sample user edited", "kony_edited@sync.com", "0987654321", "kony_edited"),"User updated successfully.");
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-230:Change Password
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testChangeUserPassword(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "NormalUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(!Users.isElementPresent(driver, By.linkText("NormalUser"))){
			Users.add(driver, "NormalUser", "NormalUser123", "Normal User", "kony@sync.com", "1234567890", "kony");
		}
		Assert.assertEquals(Users.changePassword(driver, "NormalUser", "NormalUser321"),"Password changed successfully.");
		SeleniumUtil.verifySecurityAudit(driver, "UPDATED_USER(NormalUser)", "Updated the user");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-236:Delete user under User Management User Screen
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteUser(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(!Users.isElementPresent(driver, By.linkText("SampleUser"))){
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}
		Users.delete(driver, "SampleUser");
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_deleteUsersMessageId")), "User(s) deleted successfully."),"Message after deleting user is not proper");
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Assert.assertFalse(Users.isElementPresent(driver, By.linkText("SampleUser")),"Delete user is not working");
		SeleniumUtil.verifySecurityAudit(driver, "DELETED_USER(SampleUser)", "Deleted the user");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-237:Verify Validation messages while Adding a new User with Empty Fields 
	 * Sync-592:Verify Length validations messages
	 * Sync-593:Verify Validation message with invalid data
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateUserIDFieldMessage() {
		
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
		    //switch from main window to modal dialog box
		    driver.switchTo().activeElement();
		    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User ID must not be blank.");
		    
		    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), "$%&");
		    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User ID should only contain alphanumeric digits and special characters .,@,- and _. e.g.user_1234");
		    
		    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), "test user");
		    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User ID should only contain alphanumeric digits and special characters .,@,- and _. e.g.user_1234");
		}catch(Exception e){
			e.printStackTrace();
		}
		    
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidatePasswordFieldMessage(){
		
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
	    //switch from main window to modal dialog box
	    driver.switchTo().activeElement();
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), "TestUserID");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "TestUs");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Password should match with Confirm Password");
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateConfirmPwdFieldMessage(){
		
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
	    //switch from main window to modal dialog box
	    driver.switchTo().activeElement();
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), "TestUserID");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "TestUserID123");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "TestUserID");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Password should match with Confirm Password");
		}catch(Exception e){
			e.printStackTrace();
		}
	    
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateUserNameFieldMessage(){
		
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
	    //switch from main window to modal dialog box
	    driver.switchTo().activeElement();
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), "TestUserIDS");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "TestUserID123");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "TestUserID123");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User Name must not be blank.");
	    
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), "   ");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User Name must not be blank.");
	    }catch(Exception e){
			e.printStackTrace();
		}
		
	    }
	
	/*
	 * verify email and mobile fields
	 * DEF479 : Mobile Number validation should be asked while Adding User
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateEmailMobileFieldMessageDEF479(){
		
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
	    //switch from main window to modal dialog box
	    driver.switchTo().activeElement();
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUserID")), "TestUserID");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "TestUserID123");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "TestUserID123");
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), "TestUserName");

	    SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")));
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), "test");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid email ID.");
	    
	    SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")));
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), "test@test");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid email ID.");
	    
	    Users.type(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), "test@test.com");
	    SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), "abcd");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid mobile number.");
	    SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), "1234");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid mobile number.");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-232:Inactive User - SampleUser3 must be present in the users list before running this test
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInactiveUser(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser3");
		if(Users.isElementPresent(driver, By.linkText("SampleUser3"))){
		Users.waitForElement(driver, By.linkText("SampleUser3"));
		SeleniumUtil.click(driver, By.linkText("SampleUser3"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignGroup(driver, "SampleUser3", "Administrator");
		Users.navigateToUsersHomePage(driver);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser3");
		Users.setStatus(driver, "Inactive");
		Login.logout(driver);
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_userID")));
		Login.login(driver, "SampleUser3", "SampleUser123");
		Assert.assertEquals(SeleniumUtil.findElement(driver,By.xpath(configObj.getPropertyValue("msg_loginError"))).getText().toString(),"Your login attempt was not successful, try again."+"\nReason : User is disabled");
		}
		else{
			Assert.fail("Please add SampleUser3 in the users list and then run again.");
		}
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.linkText("Logout")))
			{
			Login.logout(driver);
			}
		}
		 
	}
	
	/*
	 * Sync-233:Activate User
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testActiveUser(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		 SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(Users.isElementPresent(driver, By.linkText("SampleUser"))){
			Users.delete(driver, "SampleUser");
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}else{
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}
		
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Users.waitForElement(driver, By.linkText("SampleUser"));
		SeleniumUtil.click(driver, By.linkText("SampleUser"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignGroup(driver, "SampleUser", "Administrator");
		Users.navigateToUsersHomePage(driver);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		Users.setStatus(driver, "Active");
		SeleniumUtil.verifySecurityAudit(driver, "UPDATED_USER(SampleUser)", "Updated the user");
		Login.logout(driver);
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_userID")));
		Login.login(driver, "SampleUser", "sampleuser123");
		SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_logout")));
		Assert.assertEquals(Login.getTitle(driver), "Analytics Dashboard");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
			Login.logout(driver);
		}
		
	}
	
	/*
	 * Sync-231:Verify Search functionality on Users page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUserByUserID(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
			{
			 	Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "syncadmin");
				Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_users"), "syncadmin", configObj.getPropertyValue("txt_users_userIdInEachRow")),"Valid Search of user Id is not working as expected.");
			}
			else {
				Assert.fail("Users page is not obtained");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUserByName(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
			{
			    Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserName")), "Sync Admin");
			 	Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_users"), "Sync Admin", configObj.getPropertyValue("txt_users_userNameInEachRow")),"Valid Search of user name is not working as expected.");
			}
			else {
				Assert.fail("Users page is not obtained");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUserByEmail(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByEmail")), "syncadmin@konylabs.com");
			Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_users"), "syncadmin@konylabs.com", configObj.getPropertyValue("txt_users_emailInEachRow")),"Valid Search of email is not working as expected.");
		}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUserByMobile(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		 Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByMobile")), "1234567890");
		 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_users"), "1234567890", configObj.getPropertyValue("txt_users_mobileInEachRow")),"Valid Search of mobile is not working as expected.");
		 
		}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUserByUserID(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
			{
			  Assert.assertTrue(Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "xyz")==0,"Search by invalid userId is not working.");
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			  Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_searchByUserID"))).equals("xyz"), "Text in the search field is not cleared after refreshing");

			}
			else {
				Assert.fail("Users page is not obtained");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUserByName(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
			{
			 Assert.assertTrue(Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserName")), "xyz")==0,"Search by invalid username is not working.");
			 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			  Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_searchByUserName"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
			}
			else {
				Assert.fail("Users page is not obtained");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUserByEmail(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
			Assert.assertTrue(Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByEmail")), "xyz")==0, "Search by invalid email is not working.");
			 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_searchByEmail"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
		}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUserByMobile(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
			Assert.assertTrue(Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByMobile")), "111111111111111111")==0, "Search by invalid mobile is not working.");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_searchByMobile"))).equals("111111111111111111"), "Text in the search field is not cleared after refreshing");
		}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchInsertedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		Assert.assertTrue(Users.verifyInsertedOnSearch(driver,"03/23/2012 20:27:45 +0530"),"Valid search for inserted on is not working.");
	}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchInsertedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		Assert.assertFalse(Users.verifyInsertedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Invalid search for inserted on is not working.");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_users_searchByInsertedOn"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		Assert.assertTrue(Users.verifyUpdatedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Valid search for updated on is not working.");
		
	}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		Assert.assertFalse(Users.verifyUpdatedOnSearch(driver,"03/23/2001 20:27:45 +0530"),"Invalid search for updated on is not working.");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_users_searchByUpdatedOn"))).contains("03/23/2001 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchInsertedOnUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		Assert.assertTrue(Users.verifyInsertedOnUpdatedOnSearch(driver,"03/23/2012 20:27:45 +0530", "03/23/2030 20:27:45 +0530"),"Valid search for inserted on updated on together is not working.");
	}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchInsertedOnUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
		Assert.assertFalse(Users.verifyInsertedOnUpdatedOnSearch(driver,"03/23/2030 20:27:45 +0530", "03/23/2012 20:27:45 +0530"),"InValid search for inserted on updated on together is not working.");
	}
		else {
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testCheckStatusSearch(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users"))
		{
			Assert.assertTrue(Users.searchByStatus(driver, "Active"),"Status search is not working in users page.");
			Assert.assertTrue(Users.searchByStatus(driver, "Inactive"),"Status search is not working in users page.");
		}
		else
		{
			Assert.fail("Users page is not obtained");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		}
	
	/*
	 * test based on user status
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUserStatus(){

		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "inactiveuser");
		Users.select(driver, "inactiveuser");
		
		if(new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectStatus")))).getFirstSelectedOption().getText().equalsIgnoreCase("Active") )
		{
			Users.changeUserStatus(driver, "Inactive");
		}
		
		Users.changeUserStatus(driver, "Active");
		Assert.assertTrue(SeleniumUtil.waitForText(driver,
				By.id("userStatusDiv"), "User enabled successfully"));
		SeleniumUtil.verifySecurityAudit(driver, "ENABLED_USER(inactiveuser)", "Enabled the user");
		Login.logout(driver);
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_userID")));
		Login.login(driver, "inactiveuser", "inactiveuser123");
		Assert.assertEquals(Login.getTitle(driver), "Analytics Dashboard");
		Login.logout(driver);
		
		Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		Users.navigateToUsersHomePage(driver);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "inactiveuser");
		Users.select(driver, "inactiveuser");
		Users.changeUserStatus(driver, "Inactive");
		Assert.assertTrue(SeleniumUtil.waitForText(driver,
				By.id("userStatusDiv"), "User disabled successfully"));
		SeleniumUtil.verifySecurityAudit(driver, "DISABLED_USER(inactiveuser)", "Disabled the user");
		Login.logout(driver);
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_userID")));
		Login.login(driver, "inactiveuser", "inactiveuser123");
		Assert.assertEquals(SeleniumUtil.findElement(driver,By.xpath(configObj.getPropertyValue("msg_loginError"))).getText().toString(),"Your login attempt was not successful, try again."+"\nReason : User is disabled");
		}
		catch(Exception e)
		{
			Login.logout(driver);
		}
		finally{
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
			Users.navigateToUsersHomePage(driver);
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "inactiveuser");
			Users.select(driver, "inactiveuser");
			if(!SeleniumUtil.findElement(driver,By.xpath("//tr//div[@id='s2id_usen']/a[@class='select2-choice']/span")).getText().equalsIgnoreCase("Inactive"))
			{
			Users.changeUserStatus(driver, "Inactive");
			}
		}
		

	}
	
	/*
	 *Sync-234:Assign/DeAssign Group to user under User Management User Screen
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAssignDeassignGroupToUser(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(Users.isElementPresent(driver, By.linkText("SampleUser"))){
			Users.delete(driver, "SampleUser");
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}else{
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}
		
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Users.waitForElement(driver, By.linkText("SampleUser"));
		SeleniumUtil.click(driver, By.linkText("SampleUser"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignGroup(driver, "SampleUser", "Administrator");
		Users.assignGroup(driver, "SampleUser", "Report_viewer");
		List<WebElement> options= Users.getAllAttachedGroups(driver);
		Assert.assertTrue(options.size() == 2,"Groups are not assigned to the user");
		Users.deAssignGroup(driver, "Report_viewer");
		options= Users.getAllAttachedGroups(driver);
		Assert.assertTrue(options.size() == 1,"Group is not de-assigned for the user");
		SeleniumUtil.verifySecurityAudit(driver, "UPDATED_USER(SampleUser)", "Updated the user");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_users"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_users", By.id(configObj.getPropertyValue("tbx_searchByUserName"))),"Refresh is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar for inserted time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForInsertedOn()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_users_searchByInsertedOn", "grid_users", "start")," Time search through calendar is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	
	/*
	 * Verifying calendar for updated on
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForUpdatedOn()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_users_searchByUpdatedOn", "grid_users", "end")," Time search through calendar is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on inserted on time field to check the presence of calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForInsertedOnTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_users_searchByInsertedOn"), "Calendar is not visible on alternate clicks");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForUpdatedOnTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_users_searchByUpdatedOn"), "Calendar is not visible on alternate clicks");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,3),"Data is not sorted on the click of column name");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "users";
		
	}
	
	
	/*
	 * verify edit profile
	 * DEF499 : User details Grid not refreshed when any user is edited from edit profile button on the top right corner of the page
	 */
	
	@Test(enabled=true, timeOut=300000)
	 public void testEditProfileDEF499(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SyncSampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(Users.isElementPresent(driver, By.linkText("SyncSampleUser"))){
			Users.delete(driver, "SyncSampleUser");
			Users.add(driver, "SyncSampleUser", "syncsampleuser123", "sync sample user", "sync@kony.com", "1234567890", "kony");
		}else{
			Users.add(driver, "SyncSampleUser", "syncsampleuser123", "sync sample user", "sync@kony.com", "1234567890", "kony");
		}
		
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SyncSampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Users.waitForElement(driver, By.linkText("SyncSampleUser"));
		SeleniumUtil.click(driver, By.linkText("SyncSampleUser"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignGroup(driver, "SyncSampleUser", "Administrator");
		SeleniumUtil.click(driver, By.linkText("Logout"));
		Login.login(driver, "SyncSampleUser", "syncsampleuser123");

		SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_users")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUser")));
		  driver.switchTo().activeElement();
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addUserCancel")));
		  
		  Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SyncSampleUser");
		  SeleniumUtil.click(driver, By.linkText("Edit Profile"));
		  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbox_editProfileUserName")), "sync sample users");
		  Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("win_editProfile")),"Edit Profile"),"Edit profile window/layout is not opened");
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
		  Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_editProfile_Status")), "User edited successfully."), "profile is not updated successfully");
		  
		  SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbox_editProfileUserName")), "  ");
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
		  Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User Name must not be blank.");
		  
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cancel_editProfile")));
		  Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath("//td[@aria-describedby='usergrid_name']"), "sync sample users"), "Users details are not saved when edited through edit profile");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
			Login.logout(driver);
		}
		
	}
	
	/*
	 * Deleting logged-in user
	 * DEF505 - Alert message misleading to the user when deleted multiple users.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteLoggedInUserDEF505()
	{
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser1");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Users.waitForElement(driver, By.linkText("SampleUser1"));
		SeleniumUtil.click(driver, By.linkText("SampleUser1"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignGroup(driver, "SampleUser1", "Administrator");
		SeleniumUtil.click(driver, By.linkText("Logout"));
		Login.login(driver, "SampleUser1", "SampleUser123");
		SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_users")));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_users_pageHeader")), "Users");
		
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser1");
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("grid_usersRow")));
		Users.select(driver, "SampleUser1");
		SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteUser")));
		SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteUser")));
		
		//to verify deleting the logged-in user alone
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "You cannot delete the logged in user. Please login with some other account to delete it.");
		//to verify deleting the multiple users along with logged-in user
		if(!Users.isElementPresent(driver, By.linkText("SampleUser12")))
		{
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser1");
			if(!Users.isElementPresent(driver, By.linkText("SampleUser12")))
			{
			Users.add(driver, "SampleUser12", "SampleUser123", "sample user", "sync@kony.com", "1234567890", "kony");
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser1");
			Users.select(driver, "SampleUser1");
			Users.select(driver, "SampleUser12");
			}
			else{
				Users.select(driver, "SampleUser1");
				Users.select(driver, "SampleUser12");
			}
		}
		else{
		Users.select(driver, "SampleUser12");
		}
		SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteUser")));
		SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteUser")));
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "You cannot delete the logged in user. Selected list contains logged in user");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_searchByUserID");
		
	}
	
	/*
	 *verify delete with out selecting a user
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteWithOutSelectingAUser()
	{
		
		try{
		SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteUser")));
		SeleniumUtil.click(driver,By.cssSelector(configObj.getPropertyValue("btn_deleteUser")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please select at least one user to delete."), "Error pop up is not shown when trying to delete with out selecting any user.");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *verify display of single quote character while creating a new user
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDisplayOfSingleQuoteCharacterOnNewUser()
	{
		
		try{
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser70");
			SeleniumUtil.clear(driver,By.id(configObj.getPropertyValue("tbx_searchByUserID")));
			if(Users.isElementPresent(driver, By.linkText("SampleUser70"))){
				
				Users.delete(driver, "SampleUser70");
		}
		Assert.assertEquals(Users.add(driver, "SampleUser70", "sampleuser123", "sample'user", "sync@kony.com", "1234567890", "kony"),"User SampleUser70 added successfully.");
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser70");
	    Assert.assertTrue(Users.isElementPresent(driver, By.linkText("SampleUser70")));
	    String username= SeleniumUtil.findElement(driver,By.xpath("//td[@*='usergrid_name']")).getText();
	    Assert.assertFalse(username.contains("&#039;"), "Single quote is displayed as '&#039;'");
	    Assert.assertTrue(username.equalsIgnoreCase("sample'user"), "Username is not saved as expected");
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *verify display of single quote character while editing a user
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDisplayOfSingleQuoteCharacterOnEditUser()
	{
		
		try{
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser66");
			SeleniumUtil.clear(driver,By.id(configObj.getPropertyValue("tbx_searchByUserID")));
			if(!Users.isElementPresent(driver, By.linkText("SampleUser66"))){
				Users.add(driver, "SampleUser66", "sampleuser123", "sample'user", "sync@kony.com", "1234567890", "kony");
		}
		    Assert.assertEquals(Users.edit(driver, "SampleUser66", "sample 'user edited", "kony_edited@sync.com", "0987654321", "kony_edited"),"User updated successfully.");
		    SeleniumUtil.click(driver, SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_cancelEditUser"))));
		    SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addUser")));
		    Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_addUser"))),"Cancel button is not working in Edit User page");
		    Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser66");
		    SeleniumUtil.clear(driver,By.id(configObj.getPropertyValue("tbx_searchByUserID")));
	    String username= SeleniumUtil.findElement(driver,By.xpath("//td[@*='usergrid_name']")).getText();
	    Assert.assertFalse(username.contains("&#039;"), "Single quote is displayed as '&#039;'");
	    Assert.assertTrue(username.equalsIgnoreCase("sample 'user edited"), "Username is not saved as expected");
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying user name field in edit user page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateUserNameFieldInEditUser(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser56");
		SeleniumUtil.delay(1000);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(!Users.isElementPresent(driver, By.linkText("SampleUser56"))){
			Users.add(driver, "SampleUser56", "SampleUser123", "Sample User", "sync@kony.com", "1234567890", "kony");
		}
		SeleniumUtil.delay(1000);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser56"+Keys.RETURN);
		SeleniumUtil.waitForElement(driver, By.linkText("SampleUser56"));
		SeleniumUtil.delay(1000);
		SeleniumUtil.click(driver, By.linkText("SampleUser56"));
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
    	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), "");
    	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
    	SeleniumUtil.delay(2000);
        Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User Name must not be blank.");
        
        SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), " ");
    	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
    	SeleniumUtil.delay(1000);
        Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "User Name must not be blank.");
        
        SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserUsername")), "sample user");
        SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
        SeleniumUtil.delay(8000);
	    SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus")), "User updated successfully.");
	    Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus"))), "User updated successfully.");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	    }
	
	/*
	 * DEF508:Verifying email, mobile field in edit user page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateEmailMobileFieldInEditUserDEF508(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser137");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(!Users.isElementPresent(driver, By.linkText("SampleUser137"))){
			Users.add(driver, "SampleUser137", "SampleUser123", "Sample User", "sync@kony.com", "1234567890", "kony");
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser137"+Keys.RETURN);
		SeleniumUtil.waitForElement(driver, By.linkText("SampleUser137"));
		SeleniumUtil.click(driver, By.linkText("SampleUser137"));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
        SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), "test");
    	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
        Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid email ID.");
        SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), "test@test");
    	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
    	SeleniumUtil.delay(500);
        Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid email ID.");
        SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEmail")), "sync@kony.com");
    	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
    	SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus")), "User updated successfully.");
	    Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus"))), "User updated successfully.");
	    SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), "abcd");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid mobile number.");
	    SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), "1234");
	    SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
	    Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter valid mobile number.");
	    SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), "");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEnterpriseUserID")), "");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
    	SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus")), "User updated successfully.");
	    Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus"))), "User updated successfully.");
	    SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserMobile")), "123456789");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserEnterpriseUserID")), "kony");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editUser")));
    	SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus")), "User updated successfully.");
	    Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editUserStatus"))), "User updated successfully.");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   DEF110:Verifying password field in change password dialog
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPasswordFieldsValidationInChangePasswordDialogDEF110(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser159");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(!Users.isElementPresent(driver, By.linkText("SampleUser159"))){
			Users.add(driver, "SampleUser159", "SampleUser159123", "Sample User", "kony@sync.com", "1234567890", "kony");
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser159");
		}		
		SeleniumUtil.click(driver, By.linkText("SampleUser159"));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Password must not be blank.");
		
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "sampleuse");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Password must not be blank.");
		
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "sampleuser");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Password should match with Confirm Password");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "sampleuse");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Password should match with Confirm Password");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "SampleUser159");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "SampleUser159");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_changePasswordStatus")), "User ID and password cannot be same.");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("msg_changePasswordStatus"))),"User ID and password cannot be same.");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserPassword")), "SampleUser1591");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_addUserConfirmPassword")), "SampleUser1591");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addUserSave")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_changePasswordStatus")), "Password changed successfully.");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("msg_changePasswordStatus"))),"Password changed successfully.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Assign/DeAssign Device to user under User Management User Screen
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAssignDeAssignDeviceToUser(){
		
		try{
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(Users.isElementPresent(driver, By.linkText("SampleUser"))){
			Users.delete(driver, "SampleUser");
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}else{
			Users.add(driver, "SampleUser", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Users.waitForElement(driver, By.linkText("SampleUser"));
		SeleniumUtil.click(driver, By.linkText("SampleUser"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignDevice(driver,"000000000000000");
		Users.assignDevice(driver,"1111100003");
		List<WebElement> options= Users.getAllAttachedDevices(driver);
		Assert.assertTrue(options.size() == 2,"Devices are not assigned to the user");
		Users.deAssignDevice(driver, "1111100003");
		options= Users.getAllAttachedDevices(driver);
		Assert.assertTrue(options.size() == 1,"Device is not de-assigned for the user");
		Devices.navigateToDevicesPage(driver);
		SeleniumUtil.waitForText(driver,By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")),"Devices");	
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Devices.searchByDeviceId(driver, "000000000000000");
		Assert.assertTrue(SeleniumUtil.verifyContainsText(driver, By.xpath(configObj.getPropertyValue("txt_devices_firstRowUsers")), "SampleUser"), "User who is assigned with a device is not shown in the Device page");
		Devices.searchByDeviceId(driver, "1111100003");
		Assert.assertFalse(SeleniumUtil.verifyContainsText(driver, By.xpath(configObj.getPropertyValue("txt_devices_firstRowUsers")), "SampleUser"), "User who is de-assigned with a device is shown in the Device page");
		SeleniumUtil.verifySecurityAudit(driver, "UPDATED_USER(SampleUser)", "Updated the user");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_users", By.id(configObj.getPropertyValue("tbx_searchByUserName"))),"Refresh is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_users"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
