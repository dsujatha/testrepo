package com.kony.sync.console.webdriver.authentication;

import java.text.SimpleDateFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Authentication extends BaseTestcase {

	private static List<WebElement> authTypes;
	private static String text;
	
	/**
	 * Navigate to the Authentication page
	 * @param driver
	 */
	
	public static void navigateToAuthenticationPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_authentication")));
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while navigating to the authentication page");
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Get all available authentication types
	 * @param driver
	 * @return authTypes
	 */
	
	public static List<WebElement> getAllAuthenticationTypes(WebDriver driver){
		
		authTypes=null;
		try{
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			driver.switchTo().activeElement();
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("list_authTypes")));
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addAuthProfileDropDown")));
			authTypes = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_addAuthenticationTypes")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while reading various authentication types from the 'Select Authentication Type' drop down.");
			e.printStackTrace();
		}
		return authTypes;
		
	}
	
	/**
	 * Navigate to the form to add a new authentication type. 
	 * @param driver
	 */
	
	public static void openAddAuthentication(WebDriver driver){
		
		try{	
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			driver.switchTo().activeElement();
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("list_authTypes")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while opening add authentication page.");
			e.printStackTrace();
		}
		
	}
	
	/**
	 * select the authentication type from the list.
	 * @param driver
	 * @param authType
	 */
	
	public static void selectAuthType(WebDriver driver, String authType){
		
		try{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addAuthProfileDropDown")));
				  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_auth_authenticationTypes")));
				  for (WebElement option : options) {
				     if(authType.equalsIgnoreCase(option.getText()))
				     {
				        option.click();
				     	break;
				     }
				  }
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while selecting the given authentication type.");
		}
		
	}
	
	/**
	 * Get text from LDAP Authentication Name field.
	 * @param driver
	 * @return text
	 */
	
	public static String getLdapAuthName(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	
	/**
	 * set text in LDAP Authentication Name field.
	 * @param driver
	 * @param authName
	 */
	
	public static void typeLdapAuthName(WebDriver driver, String authName){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")), authName);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get the pre-populated text from the OPEN LDAP URL field.
	 * @param driver
	 * @return text
	 */
	
	public static String getLDAPURL(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ldap_url")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while reading pre-populated text of LDAP URL field.");
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * set text in LDAP URL field.
	 * @param driver
	 * @param url
	 */
	
	public static void typeLdapURL(WebDriver driver, String url){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ldap_url")), url);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	
	/**
	 * set text in LDAP password field
	 * @param driver
	 * @param password
	 */
	
	public static void typeLdapPassword(WebDriver driver, String password){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ldap_password")), password);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get the pre-populated text from the OPEN LDAP UserDn field.
	 * @param driver
	 * @return text
	 */
	
	public static String getLDAPUserDn(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ldap_userDn")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while reading pre-populated text of LDAP UserDn field.");
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * set text in LDAP UserDn field
	 * @param driver
	 * @param userDn
	 */
	
	public static void typeLdapUserDn(WebDriver driver, String userDn){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ldap_userDn")), userDn);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get the text from Salesforce authentication name field.
	 * @param driver
	 * @return text
	 */
	
	public static String getSalesforceAuthName(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_salesforceAuthName")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * get the text from Salesforce URL field.
	 * @param driver
	 * @return text
	 */
	
	public static String getSalesforceURL(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_salesforceURL")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * get the text from Salesforce namespace field.
	 * @param driver
	 * @return text
	 */
	
	public static String getSalesforceNamespace(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_salesforceNamespace")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * Get the text from LDAP Test connection username field.
	 * @param driver
	 * @return
	 */
	
	public static String getTestConnUserNameForLdap(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("tbx_ldap_testConnection_Username")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * Get the text from Salesforce Test connection username field.
	 * @param driver
	 * @return
	 */
	
	public static String getTestConnUserNameForSF(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("tbx_SF_testConnect_Username")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * set text in Salesforce authentication field.
	 * @param driver
	 * @param text
	 */
	
	public static void typeSalesforceAuthName(WebDriver driver, String text){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_salesforceAuthName")), text);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Get the text from the LDAP Test connection password field.
	 * @param driver
	 * @return
	 */
	
	public static String getTestConnPwdForLdap(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("tbx_ldap_testConnect_Password")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * Get the text from the Salesforce Test connection password field.
	 * @param driver
	 * @return
	 */
	
	public static String getTestConnPwdForSF(WebDriver driver){
		
		text=null;
		try{
			text = SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("tbx_SF_testConnect_Password")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * Test LDAP connectiom with given username and password.
	 * @param driver
	 * @param username
	 * @param password
	 */
	
	public static void testLDAPConnection(WebDriver driver, String username, String password){
		
		try{
			SeleniumUtil.setText(driver, By.xpath(configObj.getPropertyValue("tbx_ldap_testConnection_Username")), username);
			SeleniumUtil.setText(driver, By.xpath(configObj.getPropertyValue("tbx_ldap_testConnect_Password")), password);
			
			SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("btn_ldap_testConnection")),30000);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Test SalesForce connection with given username and password.
	 * @param driver
	 * @param username
	 * @param password
	 */
	
	public static void testSFConnection(WebDriver driver, String username, String password){
		
		try{
			SeleniumUtil.setText(driver, By.xpath(configObj.getPropertyValue("tbx_SF_testConnect_Username")), username);
			SeleniumUtil.setText(driver, By.xpath(configObj.getPropertyValue("tbx_SF_testConnect_Password")), password);
			SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_SF_testConnection")), 30000);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Test the connection after editing the authentication profile.
	 * @param driver
	 * @param username
	 * @param password
	 */
	
	public static void testEditedProfileConnection(WebDriver driver, String username, String password){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Username")), username);
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Password")), password);
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_testEditConnection")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * save the new or edited profile.
	 * @param driver
	 */
	
	public static void save(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_auth_save")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * reset any unsaved profile.
	 * @param driver
	 */
	
	public static void reset(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_auth_reset")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * cancel unsaved profile.
	 * @param driver
	 */
	
	public static void cancel(WebDriver driver){
		try{
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_auth_cancel")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * add a LDAP profile
	 * @param driver
	 * @param authName
	 * @param Url
	 * @param password
	 * @param userDn
	 */
	
	public static void add(WebDriver driver, String authName, String Url, String password, String userDn){
		
		try{
			openAddAuthentication(driver);
			selectAuthType(driver, "Open LDAP");
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")));
			typeLdapAuthName(driver, authName);
			typeLdapURL(driver, Url);
			typeLdapPassword(driver, password);
			typeLdapUserDn(driver, userDn);
			save(driver);
			cancel(driver);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * add a Salesforce profile
	 * @param driver
	 * @param authName
	 * @param Url
	 * @param nameSpace
	 */
	
	public static void add(WebDriver driver, String authName){
		
		try{
			openAddAuthentication(driver);
			selectAuthType(driver, "SalesForce");
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_sales_authName")));
			typeSalesforceAuthName(driver, authName);
			save(driver);
			cancel(driver);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * Delete the given authentication profile.
	 * @param driver
	 * @param authName
	 */
	
	public static void delete(WebDriver driver, String authName){
		
		try{
			select(driver, authName);
			SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteAuthentication")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * select the authentication name from the grid
	 * @param driver
	 * @param authName
	 * @return boolean flag
	 */
	
	public static boolean select(WebDriver driver, String authName){
		
		boolean flag=false;
		try{
			WebElement	table =SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_authentication")));
			List<WebElement> rows  =	table.findElements(By.tagName("tr"));
			int rowCount = rows.size();
			if(rowCount > 1){
				
				for(int i=2; i<=rowCount; i++){
					
					if(table.findElement(By.xpath("//tr["+i+"]/td[3]/a/span")).getText().equals(authName)){
							table.findElement(By.xpath("//tr["+i+"]/td[1]/input")).click();
							flag=true;
							break;
						}
				}
				if(!flag){
					System.out.println("Authentication name not found.");
				}
			}else{
				System.out.println("No record exist inside the Authentication grid.");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	
		return flag;
	}
	
	/**
	 * search by text
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByText(WebDriver driver , By by , String searchKey){

		try{
			SeleniumUtil.setText(driver, by, searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	   * check if search of insertedOnDate displays correct data
	   * @param driver
	   * @param insertedOnDate
	   * @return true or false
	   */
	
	  public static boolean verifyInsertedOnSearch(WebDriver driver, String insertedOnDate)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  List<WebElement> rows = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_authentication"))).findElements(By.tagName("tr"));
				int rowCount = rows.size();
			  if(rowCount>1)
			  {
				  for(int i=2; i<=rowCount; i++){
					  SeleniumUtil.waitForElement(driver, By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[7]"));
					  if(!(fmt.parse(SeleniumUtil.getVisibleText(driver,By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[7]"))).getTime()>=fmt.parse(insertedOnDate).getTime())){
						  return false;
					  }
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
	   * check if search of updatedOnDate displays correct data
	   * @param driver
	   * @param updatedOnDate
	   * @return true or false
	   */
	  
	  public static boolean verifyUpdatedOnSearch(WebDriver driver, String updatedOnDate)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  List<WebElement> rows = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_authentication"))).findElements(By.tagName("tr"));

			  int rowCount = rows.size();
			  if(rowCount>1)
			  {
				  for(int i=2; i<=rowCount; i++){
					  SeleniumUtil.waitForElement(driver, By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[8]"));
					  if(!(fmt.parse(SeleniumUtil.getVisibleText(driver,By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[8]"))).getTime()<=fmt.parse(updatedOnDate).getTime())){
						  return false;
					  }
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
	   * check if search of insertedOnDate and updatedOnDate together displays correct data
	   * @param driver
	   * @param insertedOnDate
	   * @param updatedOnDate
	   * @return true or false
	   */
	  
	  public static boolean verifyInsertedOnUpdatedOnSearch(WebDriver driver,String insertedOnDate, String updatedOnDate)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  List<WebElement> rows = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_authentication"))).findElements(By.tagName("tr"));

			  int rowCount = rows.size();
			  if(rowCount>1)
			  {
				for (int i = 2; i <= rowCount; i++) {
					SeleniumUtil.waitForElement(driver,
							By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[8]"));
					if (!((fmt.parse(
							SeleniumUtil.getVisibleText(driver,
									By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[7]")))
									.getTime() >= fmt.parse(
							insertedOnDate).getTime()) && (fmt.parse(
							SeleniumUtil.getVisibleText(driver,
									By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[7]")))
									.getTime() <= fmt.parse(
							updatedOnDate).getTime())))
						{
						return false;
						}
							
							if (!((fmt.parse(
									SeleniumUtil.getVisibleText(driver,
											By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[8]")))
											.getTime() >= fmt.parse(
									insertedOnDate).getTime()) && (fmt.parse(
									SeleniumUtil.getVisibleText(driver,
											By.xpath("//table[@id='authenticationgrid']//tr["+i+"]/td[8]")))
											.getTime() <= fmt.parse(
									updatedOnDate).getTime()))) {
						return false;
					}
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	
	  /**
		 * set text in MSADS Authentication Name field.
		 * @param driver
		 * @param authName
		 */
	  
		public static void typeMSADSAuthName(WebDriver driver, String authName){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")), authName);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS URL field.
		 * @param driver
		 * @param url
		 */
		
		public static void typeMSADSURL(WebDriver driver, String url){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Url")), url);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS domain name field.
		 * @param driver
		 * @param domainName
		 */
		
		public static void typeMSADSDomainName(WebDriver driver, String domainName){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Domain")), domainName);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS userDn field.
		 * @param driver
		 * @param userDn
		 */
		
		public static void typeMSADSUserDn(WebDriver driver, String userDn){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserDn")), userDn);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS password field.
		 * @param driver
		 * @param msAdsPassword
		 */
		
		public static void typeMSADSPassword(WebDriver driver, String msAdsPassword){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Password")), msAdsPassword);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS Referral field.
		 * @param driver
		 * @param msAdsReferral
		 */
		
		public static void typeMSADSReferral(WebDriver driver, String msAdsReferral){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Referral")), msAdsReferral);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS UserName field.
		 * @param driver
		 * @param msAdsUserName
		 */
		
		public static void typeMSADSUserName(WebDriver driver, String msAdsUserName){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserName")), msAdsUserName);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * set text in MSADS UserPassword field.
		 * @param driver
		 * @param msAdsUserPassword
		 */
		
		public static void typeMSADSUserPassword(WebDriver driver, String msAdsPassword){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserPassword")), msAdsPassword);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * Test MSADS connection with given username and password.
		 * @param driver
		 * @param username
		 * @param password
		 */
		
		public static void testMSADSConnection(WebDriver driver, String username, String password){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserName")), username);
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserPassword")), password);
				SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("adsTestConnectionButton")),30000);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * Get text from MSADS Authentication Name field.
		 * @param driver
		 * @return text
		 */
		
		public static String getMSADSAuthName(WebDriver driver){
			
			text=null;
			try{
				text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")));
			}catch(Exception e){
				e.printStackTrace();
			}
			return text;
			
		}
		
		/**
		 * set text in SAP Authentication Name field.
		 * @param driver
		 * @param authName
		 */
		
		public static void typeSAPAuthName(WebDriver driver, String authName){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_sap_authName")), authName);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * Get text from SAP Authentication Name field.
		 * @param driver
		 * @return text
		 */
		
		public static String getSAPAuthName(WebDriver driver){
			
			text=null;
			try{
				text = SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_sap_authName")));
			}catch(Exception e){
				e.printStackTrace();
			}
			return text;
		}
		
}
