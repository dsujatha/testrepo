
package com.kony.sync.console.webdriver.authentication;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.groups.Groups;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class AuthenticationTest extends BaseTestcase{
	private boolean flag;
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.click(driver, Groups.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_authentication"))));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
		e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-367,DEF258,DEF483:Add Authentication
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testVerifyAuthTypesDEF258_DEF483(){
		
		try{
		String expectedAuthTypes[] = {"Custom","Microsoft ADS","Open LDAP","SalesForce","SAP"};
		List<WebElement> authTypes = Authentication.getAllAuthenticationTypes(driver);
		Assert.assertEquals(authTypes.get(0).getText(), "Select Authentication Type");
		
		for(int i=1; i<=authTypes.size()-1;i++){
			
			Assert.assertEquals(authTypes.get(i).getText(), expectedAuthTypes[i-1], "Either authentication type is missing or they are not sorted");
		}
		driver.navigate().refresh();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-373.a:Verify Open LDAP details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLdapURLFieldPrepopulatedText(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Open LDAP");
		Assert.assertEquals(Authentication.getLDAPURL(driver), "ldap://localhost:389/dc=maxcrc,dc=com");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 * Sync-373.b:Verify Open LDAP details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLdapUserDnFieldPrepopulatedText(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Open LDAP");
		Assert.assertEquals(Authentication.getLDAPUserDn(driver), "cn=manager,dc=maxcrc,dc=com");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 *   Sync-374.a:Test Open LDAP connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLDAPConnectionWithValidCredentials(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Open LDAP");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")));
		Authentication.typeLdapAuthName(driver, "testLdap");
		//Authentication.typeLdapURL(driver, "ldap://KH1017_Temp:389/dc=maxcrc,dc=com");
		Authentication.typeLdapURL(driver, configObj.getPropertyValue("ldapUrl"));
		Authentication.typeLdapPassword(driver, configObj.getPropertyValue("ldapPassword"));
		Authentication.typeLdapUserDn(driver, "cn=manager,dc=maxcrc,dc=com");
		//Authentication.testLDAPConnection(driver, "manager", "secret");
		Authentication.testLDAPConnection(driver, configObj.getPropertyValue("ldapUserName"), configObj.getPropertyValue("ldapUserPassword"));
		SeleniumUtil.delay(2000);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful"),"Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-374.b:Test Open LDAP connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLDAPConnectionWithInvalidCredentials(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Open LDAP");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")));
		Authentication.typeLdapAuthName(driver, "testLdap");
		//Authentication.typeLdapURL(driver, "ldap://KH1017_Temp:389/dc=maxcrc,dc=com");
		Authentication.typeLdapURL(driver, configObj.getPropertyValue("ldapUrl"));
		//Authentication.typeLdapPassword(driver, "default");
		Authentication.typeLdapPassword(driver, configObj.getPropertyValue("ldapPassword"));
		Authentication.typeLdapUserDn(driver, "cn=manager,dc=maxcrc,dc=com");
		
		Authentication.testLDAPConnection(driver, "invaliduname", "invalidpwd");
		// Checking for the test connection failure message
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Authentication failed"));
		// Checking "Click Here" link is present to view the log file
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")));
		//driver.findElement(By.linkText("Click here")).click();
		String parentWindow= driver.getWindowHandle();
		SeleniumUtil.click(driver, By.linkText("Click here"));
		Thread.sleep(2000);
		Set<String> availableWindows = driver.getWindowHandles();
		// Checking if new window has opened after clicking on 'Click Here' link
		Assert.assertTrue(availableWindows.size()==2);
		
		 for(String windowHandle  : availableWindows)
	       {
	       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
	          {
	    	   driver.switchTo().window(windowHandle);
	    	   driver.close();
	    	   break;
	          }
	       }
	         driver.switchTo().window(parentWindow);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-374.c:Test Open LDAP connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testResetLDAPProfile(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Open LDAP");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")));
		Authentication.typeLdapAuthName(driver, "testLdap");
		//Authentication.typeLdapURL(driver, "ldap://KH1017_Temp:389/dc=maxcrc,dc=com");
		Authentication.typeLdapURL(driver, configObj.getPropertyValue("ldapUrl"));
		//Authentication.typeLdapPassword(driver, "default");
		Authentication.typeLdapPassword(driver, configObj.getPropertyValue("ldapPassword"));
		Authentication.typeLdapUserDn(driver, "cn=manager,dc=maxcrc,dc=com");
		//Authentication.testLDAPConnection(driver, "manager", "secret");
		Authentication.testLDAPConnection(driver, configObj.getPropertyValue("ldapUserName"), configObj.getPropertyValue("ldapUserPassword"));
		Authentication.reset(driver);
		SeleniumUtil.delay(2000);
		//Verifying if all the fields value are reset
		Assert.assertTrue(Authentication.getLdapAuthName(driver).isEmpty(),"Authentication name field should be empty.");
		Assert.assertEquals(Authentication.getLDAPURL(driver), "ldap://localhost:389/dc=maxcrc,dc=com","URL field should not be empty.");
		Assert.assertEquals(Authentication.getLDAPUserDn(driver), "cn=manager,dc=maxcrc,dc=com","UserDn field should not be empty.");
		Assert.assertTrue(Authentication.getTestConnUserNameForLdap(driver).isEmpty(), "Test connection username field should be empty.");
		Assert.assertTrue(Authentication.getTestConnPwdForLdap(driver).isEmpty(),"Test connection password field should be empty.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-374.c :Test Open LDAP connection
	 *   DEF465: Page not refreshed upon closing the pop-up after adding the authentication profile.
	 *   DEF477:All data fields getting cleared when user saves Authentication Profile Screen.
	 *   DEF257:Not able to create an auth profile with a name that was deleted.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddLDAPProfileDEF465_DEF477() throws Exception{
		
		flag=false;
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "ldap");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("ldap"))){
			Authentication.delete(driver, "ldap");
		}
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Open LDAP");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_ldap_authName")));
		Authentication.typeLdapAuthName(driver, "ldap");
		//Authentication.typeLdapURL(driver, "ldap://KH1017_Temp:389/dc=maxcrc,dc=com");
		Authentication.typeLdapURL(driver, configObj.getPropertyValue("ldapUrl"));
		//Authentication.typeLdapPassword(driver, "default");
		Authentication.typeLdapPassword(driver, configObj.getPropertyValue("ldapPassword"));
		Authentication.typeLdapUserDn(driver, "cn=manager,dc=maxcrc,dc=com");
		//Authentication.testLDAPConnection(driver, "manager", "secret");
		Authentication.testLDAPConnection(driver, configObj.getPropertyValue("ldapUserName"), configObj.getPropertyValue("ldapUserPassword"));
		SeleniumUtil.delay(2000);
		if(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful")){
			Authentication.save(driver);
			SeleniumUtil.delay(2000);
			// Verifying the success message
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
			Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ldap_url"))), "ldap://localhost:389/dc=maxcrc,dc=com");
			Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ldap_userDn"))), "cn=manager,dc=maxcrc,dc=com");

			Authentication.cancel(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			// Verifying the new LDAP profile added in the grid. 
			Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "ldap");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("ldap")));
			SeleniumUtil.click(driver, By.linkText("ldap"));
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
			// Verifying test connection username and password are not saved along with the other details.
			Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Username"))).isEmpty(), "Test connection username should be empty.");
			Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Password"))).isEmpty(), "Test connection password should be empty");
			// Verifying the authentication profile created here is displaying under the Authentication type of Application page
			Applications.navigateToApplicationsPage(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.delay(2000);
			List<WebElement> authTypes = Applications.getAuthentication(driver);
			Assert.assertTrue(authTypes.size()>1, "Insufficient authentication profiles listed under authentication type drop dowm of application page.");
			for(WebElement authType:authTypes){
				if(authType.getText().equalsIgnoreCase("ldap")){
					flag=true;
				}
			}
			Assert.assertTrue(flag, "Added LDAP profile not found under the authentication type drop down of application page.");
		}else{
			
			Assert.fail("Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		driver.navigate().refresh();
		SeleniumUtil.verifySecurityAudit(driver, "ADDED_AUTH_PROFILE(ldap)", "Added authentication profile");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
		}
		
	}
	
	/*
	 * Sync-380:Delete Authentication Profile
	 * DEF504 : Authentication is wrongly spell in the status message that comes when the auth profile is deleted
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteAuthenticationProfileDEF504(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "ldap");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("ldap"))){
			Authentication.add(driver, "ldap", configObj.getPropertyValue("ldapUrl"), configObj.getPropertyValue("ldapPassword"), "cn=manager,dc=maxcrc,dc=com");
		}
		Authentication.delete(driver, "ldap");
		SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteAuthentication")));
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_deleteAuthenticationMessageid")), "Authentication profile(s) deleted successfully."),"Message after deleting authentication is not proper");
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "ldap");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText("ldap")));
		SeleniumUtil.verifySecurityAudit(driver, "DELETED_AUTH_PROFILE(ldap)", "Deleted authentication profile");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-371.a:Verify Salesforce details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSalesforceURLFieldPrepopulatedText(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Assert.assertEquals(Authentication.getSalesforceURL(driver), "https://login.salesforce.com/services/Soap/u/25.0");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-371.b:Verify Salesforce details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSalesforceNamespaceFieldPrepopulatedText(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Assert.assertEquals(Authentication.getSalesforceNamespace(driver), "urn:partner.soap.sforce.com");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-375.a:Test Salesforce Connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSFConnectionWithValidCred(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Authentication.typeSalesforceAuthName(driver, "SalesForce");
		Authentication.testSFConnection(driver,configObj.getPropertyValue("sfUserName"),configObj.getPropertyValue("sfPassword"));
		SeleniumUtil.delay(2000);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful"),"Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-375.b:Test Salesforce Connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSFConnectionWithInValidCred(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Authentication.typeSalesforceAuthName(driver, "SalesForce");
		//Authentication.testSFConnection(driver, "syncautomation@kony.com", "Kony1234");
		Authentication.testSFConnection(driver,configObj.getPropertyValue("sfUserName"),"Kony1234");
		// Checking for the test connection failure message
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Authentication failed"));
		// Checking "Click Here" link is present to view the log file
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-375.b:Test Salesforce Connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddSFProfile() throws Exception{
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SalesForce");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("SalesForce"))){
			Authentication.delete(driver, "SalesForce");
		}
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Authentication.typeSalesforceAuthName(driver, "SalesForce");
		Authentication.testSFConnection(driver,configObj.getPropertyValue("sfUserName"),configObj.getPropertyValue("sfPassword"));
		SeleniumUtil.delay(2000);
		if(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful")){
			Authentication.save(driver);
			SeleniumUtil.delay(2000);
			// Verifying the success message
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
			Authentication.cancel(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			//Verifying the new LDAP profile added in the grid. 
			Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SalesForce");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("SalesForce")));
			SeleniumUtil.click(driver, By.linkText("SalesForce"));
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
	
			Assert.assertTrue(SeleniumUtil.findElement(driver, By.id("overwriteEndPointURL")).isSelected(), "'Use dynamic end point url' is not checked while performing edit operation");
			
			//Verifying test connection username and password are not saved along with the other details.
			Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Username"))).isEmpty(), "Test connection username should be empty.");
			Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Password"))).isEmpty(), "Test connection password should be empty");
			// Verifying the authentication profile created here is displaying under the Authentication type of Application page
			Applications.navigateToApplicationsPage(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.delay(2000);
			List<WebElement> authTypes = Applications.getAuthentication(driver);
			Assert.assertTrue(authTypes.size()>1, "Insufficient authentication profiles listed under authentication type drop down of application page.");
			for(WebElement authType:authTypes){
				if(authType.getText().equalsIgnoreCase("SalesForce")){
						flag=true;
					}
				}
			Assert.assertTrue(flag, "Added SalesForce profile not found under the authentication type drop down of application page.");
		}else{
			Assert.fail("Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		driver.navigate().refresh();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
		}
		
	}
	
	/*
	 * Sync-375.c:Test Salesforce Connection
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testResetSFProfile(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Authentication.typeSalesforceAuthName(driver, "SalesForce");
		//Authentication.testSFConnection(driver, "syncautomation@kony.com", "Kony1234!");
		Authentication.testSFConnection(driver,configObj.getPropertyValue("sfUserName"),configObj.getPropertyValue("sfPassword"));
		Authentication.reset(driver);
		//verifying whether the required fields are reset or not.
		Assert.assertTrue(Authentication.getSalesforceAuthName(driver).isEmpty(),"Authentication name field should be empty.");
		Assert.assertFalse(Authentication.getSalesforceURL(driver).isEmpty(), "URL field should not be empty.");
		Assert.assertFalse(Authentication.getSalesforceNamespace(driver).isEmpty(), "Namespace field should not be empty.");
		Assert.assertTrue(Authentication.getTestConnUserNameForSF(driver).isEmpty(), "Test connection user name field should be empty. ");
		Assert.assertTrue(Authentication.getTestConnPwdForSF(driver).isEmpty(), "Test connection password field should be empty.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-369.a:Verify Microsoft ADS details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testADSUrlFieldPrepopulatedTest(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Url"))), "ldap://platformtest.kony.internal:389/");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-369.b:Verify Microsoft ADS details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testADSDomainFieldPrepopulatedTest(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Domain"))),"ldap://platformtest.kony.internal:389/DC=platformtest,DC=kony,DC=internal");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-369.c:Verify Microsoft ADS details page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testADSUserDnFieldPrepopulatedTest(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserDn"))), "administrator@platformtest.kony.internal");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-378.a:Edit LDAP Authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditLdapProfile(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "ldap");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("ldap"))){
			Authentication.add(driver, "ldap", configObj.getPropertyValue("ldapUrl"), configObj.getPropertyValue("ldapPassword"), "cn=manager,dc=maxcrc,dc=com");
		}
		SeleniumUtil.waitForElement(driver, By.linkText("ldap"));
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "ldap");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		SeleniumUtil.click(driver, By.linkText("ldap"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
		Authentication.typeLdapURL(driver, "test ldap url");
		Authentication.typeLdapUserDn(driver, "test userDn");
		// Testing the connection using incorrect edited data
		//Authentication.testEditedProfileConnection(driver, "manager", "secret");
		Authentication.testEditedProfileConnection(driver,configObj.getPropertyValue("ldapUserName"), configObj.getPropertyValue("ldapUserPassword"));
		// Checking for the test connection failure message
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_edit_testConnect_Result")), "Authentication failed"));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editProfile_Result")), "Authentication details updated successfully");
		Assert.assertEquals(Authentication.getLDAPURL(driver),"test ldap url");
		Assert.assertEquals(Authentication.getLDAPUserDn(driver), "test userDn");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-378.b:Edit Salesforce Authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditSFProfile(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SalesForce");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("SalesForce"))){
			Authentication.add(driver, "SalesForce");
		}
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SalesForce");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		SeleniumUtil.waitForElement(driver, By.linkText("SalesForce"));
		SeleniumUtil.click(driver, By.linkText("SalesForce"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_salesforceURL")), "Url");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_salesforceNamespace")), "nameSpace");
		// Testing the connection using incorrect edited data
		//Authentication.testEditedProfileConnection(driver, "syncautomation@kony.com", "Kony1234!");
		Authentication.testEditedProfileConnection(driver,configObj.getPropertyValue("sfUserName"),configObj.getPropertyValue("sfPassword"));
		// Checking for the test connection failure message
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_edit_testConnect_Result")), "Authentication failed"));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editProfile_Result")), "Authentication details updated successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByName(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 	Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "CUSTOM");
				Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "CUSTOM", configObj.getPropertyValue("txt_authentication_nameInEachRow")),"Valid Search of name is not working as expected.");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByName(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 	Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "xyz");
				Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "xyz", configObj.getPropertyValue("txt_authentication_nameInEachRow")),"Invalid Search of name is not working as expected.");
				SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_refresh")));
				 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name"))).equals("xyz"), "Text in the search field is not cleared after refreshing");	
				
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByType(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_type")), "custom");
			 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "custom", configObj.getPropertyValue("txt_authentication_typeInEachRow")),"Valid Search of type is not working as expected.");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByType(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_type")), "xyz");
			 Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "xyz", configObj.getPropertyValue("txt_authentication_typeInEachRow")),"Invalid Search of type is not working as expected.");
			 SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_type"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByInsertID(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedid")), "syncadmin");
			 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "syncadmin", configObj.getPropertyValue("txt_authentication_insertedIdInEachRow")),"Valid Search of insert ID is not working as expected.");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByInsertID(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedid")), "xyz");
			 Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "xyz", configObj.getPropertyValue("txt_authentication_insertedIdInEachRow")),"Invalid Search of insert ID is not working as expected.");
			 SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedid"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByUpdatedID(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedid")), "syncadmin");
			 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "syncadmin", configObj.getPropertyValue("txt_authentication_updatedIdInEachRow")),"Valid Search of updated ID is not working as expected.");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByUpdatedID(){
		
		try{
		 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
			{
			 Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedid")), "xyz");
			 Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_authentication"), "xyz", configObj.getPropertyValue("txt_authentication_updatedIdInEachRow")),"Invalid Search of updated ID is not working as expected.");
			 SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedid"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
			}
			else {
				Assert.fail("Authentication page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchInsertedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
		{
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedon")), "03/23/2012 20:27:45 +0530");	
		Assert.assertTrue(Authentication.verifyInsertedOnSearch(driver,"03/23/2012 20:27:45 +0530"),"Valid search for inserted on is not working.");
	}
		else {
			Assert.fail("Authentication page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchInsertedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
		{
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedon")), "03/23/2030 20:27:45 +0530");
		Assert.assertFalse(Authentication.verifyInsertedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Invalid search for inserted on is not working.");
		SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedon"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Authentication page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
		{
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedon")), "03/23/2030 20:27:45 +0530");
		Assert.assertTrue(Authentication.verifyUpdatedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Valid search for updated on is not working.");
	}
		else {
			Assert.fail("Authentication page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
		{
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedon")), "03/23/2001 20:27:45 +0530");
		Assert.assertFalse(Authentication.verifyUpdatedOnSearch(driver,"03/23/2001 20:27:45 +0530"),"Invalid search for updated on is not working.");
		SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedon"))).contains("03/23/2001 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Authentication page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchInsertedOnUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
		{
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedon")), "03/23/2012 20:27:45 +0530");
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedon")), "03/23/2030 20:27:45 +0530");
			
		Assert.assertTrue(Authentication.verifyInsertedOnUpdatedOnSearch(driver,"03/23/2012 20:27:45 +0530", "03/23/2030 20:27:45 +0530"),"Valid search for inserted on, updated on together is not working.");
	}
		else {
			Assert.fail("Authentication page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchInsertedOnUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"))
		{
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedon")), "03/23/2030 20:27:45 +0530");
			Authentication.searchByText(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedon")), "03/23/2001 20:27:45 +0530");
		Assert.assertFalse(Authentication.verifyInsertedOnUpdatedOnSearch(driver,"03/23/2030 20:27:45 +0530", "03/23/2012 20:27:45 +0530"),"InValid search for inserted on, updated on together is not working.");
	}
		else {
			Assert.fail("Authentication page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_authentication"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_authentication", By.id(configObj.getPropertyValue("tbx_authentication_searchBy_type"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying calendar
	 
	@Test(enabled=true, timeOut=300000)
	public void testCalendar() throws InterruptedException
	{
		driver.findElement(By.id(configObj.getPropertyValue("tbx_authentication_searchBy_insertedon"))).click();
		Thread.sleep(1000);
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@id='ui-datepicker-div' and contains(@style,'display: block')]")),"Calendar is not present");
		driver.findElement(By.id(configObj.getPropertyValue("tbx_authentication_searchBy_updatedon"))).click();
		Thread.sleep(1000);
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@id='ui-datepicker-div' and contains(@style,'display: block')]")),"Calendar is not present");
	}
	*/
	
	/*
	 * Verifying calendar for inserted time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForInsertedOn()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_authentication_searchBy_insertedon", "grid_authentication", "start")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for updated on
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForUpdatedOn()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_authentication_searchBy_updatedon", "grid_authentication", "end")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForInsertedOnTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_authentication_searchBy_insertedon"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 * DEF488: Calendar is not opening while clicking calendar input field for the second time after clicking any non-calendar input area
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForUpdatedOnTimeFieldDEF488()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_authentication_searchBy_updatedon"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,3),"Data is not sorted on the click of column name");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	
	 * verify page title
	 
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle() throws Exception{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_authentication")), "page title is not appropriate");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return "authentication";
	}
	
	/*
	 * Edit Custom Authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditCustomProfile(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "TestCustom");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("TestCustom"))){
			Authentication.openAddAuthentication(driver);
			Authentication.selectAuthType(driver, "Custom");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_authName")), "TestCustom");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_customClass")), "test");
			Authentication.save(driver);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
			Authentication.cancel(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
		}
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "TestCustom");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		SeleniumUtil.waitForElement(driver, By.linkText("TestCustom"));
		SeleniumUtil.click(driver, By.linkText("TestCustom"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_customClass")), "");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please enter all the mandatory fields."),"ALert box is not displayed while saving edit authentication details with out custom class");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_customClass")), "sample");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
		SeleniumUtil.verifySecurityAudit(driver, "UPDATED_AUTH_PROFILE(TestCustom)", "Updated authentication profile");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		

	/*
	 * DEF513 : TestConnection progress is not shown in edit auth profile 
	 * verify loading status in edit authentication page 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoadingInEditAuthenticationStatusDEF513(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SampleSalesForce");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("SampleSalesForce"))){
			Authentication.add(driver, "SampleSalesForce");
		}
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SampleSalesForce");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		SeleniumUtil.waitForElement(driver, By.linkText("SampleSalesForce"));
		SeleniumUtil.click(driver, By.linkText("SampleSalesForce"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_testEditConnection")));
		SeleniumUtil.closeAlertBoxAndGetItsText(driver);
		if(SeleniumUtil.isElementDisplayed(driver, By.id("loadingImg")))
		{
			Assert.fail("Loading image is displayed even when the alert is shown");
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_salesforceNamespace")), "https://login.salesfor.com/services/Soap/u/25.0");
		Authentication.testEditedProfileConnection(driver,"test","test");
		if(!configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
		{
		boolean flag=false;
		for(int i=0;i<20;i++)
		{
			if(SeleniumUtil.isElementDisplayed(driver, By.id("loadingImg"))){
				flag=true;
				break;
			}
		}
		Assert.assertTrue(flag, "Loading image is not shown while trying to connect after clicking 'Test Connection'");
	    }
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return configObj.getPropertyValue("tbx_authentication_searchBy_name");
	}
	
	/*
	 *verify delete with out selecting authentication
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteWithOutSelectingAuthentication()
	{
		
		try{
		SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteAuthentication")));
		SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteAuthentication")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please select at least one Authentication profile to delete."), "Error pop up is not shown when trying to delete with out selecting any authentication.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *verify display of single quote character while adding authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDisplayOfSingleQuoteCharacterOnNewAuthenticationProfile()
	{
		
			try{
				Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "Test'8");
				SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
				if(SeleniumUtil.isElementPresent(driver, By.linkText("Test'8"))){
					Authentication.delete(driver, "Test'8");
				}
				Authentication.openAddAuthentication(driver);
				Authentication.selectAuthType(driver, "Custom");
				SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_custom_authName")));
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_authName")), "Test'8");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_customClass")), "Test8");
					Authentication.save(driver);
					// Verifying the success message
					Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
					Authentication.cancel(driver);
					SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
					// Verifying the new Custom profile added in the grid. 
					Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "Test'8");
					SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
					Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Test'8")),"Custom authentication is not added successfully");
					String name= SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("txt_authenticationName")));
					Assert.assertFalse(name.contains("&#039;"), "Single quote is displayed as '&#039;' in profile name");
					Assert.assertTrue(name.equalsIgnoreCase("Test'8"), "name is not saved as expected");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
	}
	
	/*
	 *verify display of single quote character while editing authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDisplayOfSingleQuoteCharacterOnEditAuthenticationProfile()
	{
		try{
			
			Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "Test'9");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
			if(SeleniumUtil.isElementPresent(driver, By.linkText("Test'9"))){
				Authentication.delete(driver, "Test'9");
			}
			Authentication.openAddAuthentication(driver);
			Authentication.selectAuthType(driver, "Custom");
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_custom_authName")));
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_authName")), "Test'9");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_customClass")), "Test9");
			Authentication.save(driver);
			SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully");
				Authentication.cancel(driver);
				SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
				Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "Test'9");
				SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
				SeleniumUtil.click(driver, By.linkText("Test'9"));
				SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_custom_customClass")), "Test123");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
	Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editProfile_Result")), "Authentication details updated successfully"),"Authentication details are not updated successfully when single quote is present in the name of authentication profile");
	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_cancelEditAuthentication")));
	Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_authentication_pageHeader")), "Authentication"),"Cancel button is not working when single quote is present in the name of authentication profile");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_authentication", By.id(configObj.getPropertyValue("tbx_authentication_searchBy_type"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_authentication"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Test Salesforce Connection By UnChecking Use Dynamic End Point URL
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddSFProfileByUnCheckingUseDynamicEndPointURL() throws Exception{
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SalesForceSample");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("SalesForceSample"))){
			Authentication.delete(driver, "SalesForceSample");
		}
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SalesForce");
		Authentication.typeSalesforceAuthName(driver, "SalesForceSample");
		SeleniumUtil.findElement(driver, By.id("overwriteEndPointURL")).click();
		Authentication.testSFConnection(driver,configObj.getPropertyValue("sfUserName"),configObj.getPropertyValue("sfPassword"));
		SeleniumUtil.delay(2000);
		if(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful")){
			Authentication.save(driver);
			SeleniumUtil.delay(2000);
			// Verifying the success message
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
			Authentication.cancel(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SalesForceSample");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("SalesForceSample")));
			SeleniumUtil.click(driver, By.linkText("SalesForceSample"));
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
			Assert.assertFalse(SeleniumUtil.findElement(driver, By.id("overwriteEndPointURL")).isSelected(), "Use dynamic end point url is checked while performing edit operation");
		}else{
			Assert.fail("Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		driver.navigate().refresh();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
		}
		
	}
	
	/*
	 * Tests addition of Microsoft ADS Authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddMSADSAuthenticationProfile() throws Exception{
		
		flag=false;
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SampleMSADS");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("SampleMSADS"))){
			Authentication.delete(driver, "SampleMSADS");
		}
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")));
		Authentication.typeMSADSAuthName(driver, "SampleMSADS");
		Authentication.typeMSADSURL(driver, configObj.getPropertyValue("adsUrl"));
		Authentication.typeMSADSDomainName(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.typeMSADSUserDn(driver, configObj.getPropertyValue("adsUserDn"));
		Authentication.typeMSADSPassword(driver, configObj.getPropertyValue("adsPassword"));
		Authentication.typeMSADSReferral(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.testMSADSConnection(driver, configObj.getPropertyValue("adsUserName"), configObj.getPropertyValue("adsUserPassword"));
		if(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful")){
			Authentication.save(driver);
			SeleniumUtil.delay(2000);
			// Verifying the success message
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
			Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Url"))), "ldap://platformtest.kony.internal:389/");
			Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Domain"))), "ldap://platformtest.kony.internal:389/DC=platformtest,DC=kony,DC=internal");
			Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserDn"))), "administrator@platformtest.kony.internal");
			Authentication.cancel(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			// Verifying the new MSADS profile added in the grid. 
			Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "SampleMSADS");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("SampleMSADS")));
			SeleniumUtil.click(driver, By.linkText("SampleMSADS"));
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
			// Verifying test connection username and password are not saved along with the other details.
			Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Username"))).isEmpty(), "Test connection username should be empty.");
			Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editTestConnect_Password"))).isEmpty(), "Test connection password should be empty");
			// Verifying the authentication profile created here is displaying under the Authentication type of Application page
			Applications.navigateToApplicationsPage(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.delay(2000);
			List<WebElement> authTypes = Applications.getAuthentication(driver);
			Assert.assertTrue(authTypes.size()>1, "Insufficient authentication profiles listed under authentication type drop dowm of application page.");
			for(WebElement authType:authTypes){
				if(authType.getText().equalsIgnoreCase("SampleMSADS")){
					flag=true;
				}
			}
			Assert.assertTrue(flag, "Added MSADS profile not found under the authentication type drop down of application page.");
		}else{
			
			Assert.fail("Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		driver.navigate().refresh();
		SeleniumUtil.verifySecurityAudit(driver, "ADDED_AUTH_PROFILE(SampleMSADS)", "Added authentication profile");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
		}
		
	}
	
	/*
	 * Test reset operation of MSADS profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testResetMSADSProfile(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")));
		Authentication.typeMSADSAuthName(driver, "testMSADS");
		Authentication.typeMSADSURL(driver, configObj.getPropertyValue("adsUrl"));
		Authentication.typeMSADSDomainName(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.typeMSADSUserDn(driver, configObj.getPropertyValue("adsUserDn"));
		Authentication.typeMSADSPassword(driver, configObj.getPropertyValue("adsPassword"));
		Authentication.typeMSADSReferral(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.testMSADSConnection(driver, configObj.getPropertyValue("adsUserName"), configObj.getPropertyValue("adsUserPassword"));
		Authentication.reset(driver);
		SeleniumUtil.delay(2000);
		//Verifying if all the fields value are reset
		Assert.assertTrue(Authentication.getMSADSAuthName(driver).isEmpty(),"Authentication name field should be empty.");
		Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserName"))).isEmpty(), "Test connection username field should be empty.");
		Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserPassword"))).isEmpty(),"Test connection password field should be empty.");
		Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Password"))).isEmpty(), "ADS password field should be empty.");
		Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Referral"))).isEmpty(),"ADS referral field should be empty.");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Url"))), "ldap://platformtest.kony.internal:389/");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Domain"))), "ldap://platformtest.kony.internal:389/DC=platformtest,DC=kony,DC=internal");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserDn"))), "administrator@platformtest.kony.internal");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Test MSADS authentication pre-populated text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testMSADSFieldPrepopulatedText(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Url"))), "ldap://platformtest.kony.internal:389/");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Domain"))), "ldap://platformtest.kony.internal:389/DC=platformtest,DC=kony,DC=internal");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_UserDn"))), "administrator@platformtest.kony.internal");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Test MSADS connection with valid credentials
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testMSADSConnectionWithValidCredentials(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")));
		Authentication.typeMSADSAuthName(driver, "testMSADS");
		Authentication.typeMSADSURL(driver, configObj.getPropertyValue("adsUrl"));
		Authentication.typeMSADSDomainName(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.typeMSADSUserDn(driver, configObj.getPropertyValue("adsUserDn"));
		Authentication.typeMSADSPassword(driver, configObj.getPropertyValue("adsPassword"));
		Authentication.typeMSADSReferral(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.testMSADSConnection(driver, configObj.getPropertyValue("adsUserName"), configObj.getPropertyValue("adsUserPassword"));
		SeleniumUtil.delay(2000);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Test Authentication is successful"),"Authentication might not have been tested successfully because of wrong data or functionality failure");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Test MSADS connection with invalid credentials
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testMSADSConnectionWithInValidCredentials(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "Microsoft ADS");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")));
		Authentication.typeMSADSAuthName(driver, "testMSADS");
		Authentication.typeMSADSURL(driver, configObj.getPropertyValue("adsUrl"));
		Authentication.typeMSADSDomainName(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.typeMSADSUserDn(driver, configObj.getPropertyValue("adsUserDn"));
		Authentication.typeMSADSPassword(driver, configObj.getPropertyValue("adsPassword"));
		Authentication.typeMSADSReferral(driver, configObj.getPropertyValue("adsDomainName"));
		Authentication.testMSADSConnection(driver, "invalidUserName", "invalidPassword");
		SeleniumUtil.delay(2000);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")), "Authentication failed"));
		// Checking "Click Here" link is present to view the log file
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")));
		String parentWindow= driver.getWindowHandle();
		SeleniumUtil.click(driver, By.linkText("Click here"));
		Thread.sleep(2000);
		Set<String> availableWindows = driver.getWindowHandles();
		// Checking if new window has opened after clicking on 'Click Here' link
		Assert.assertTrue(availableWindows.size()==2);
		 for(String windowHandle  : availableWindows)
	       {
	       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
	          {
	    	   driver.switchTo().window(windowHandle);
	    	   driver.close();
	    	   break;
	          }
	       }
	         driver.switchTo().window(parentWindow);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		}
	
	/*
	 * Test Edit MSADS Authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditMSADSProfile(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "EditSampleMSADS");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("EditSampleMSADS"))){
			Authentication.openAddAuthentication(driver);
			Authentication.selectAuthType(driver, "Microsoft ADS");
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_msads_authName")));
			Authentication.typeMSADSAuthName(driver, "EditSampleMSADS");
			Authentication.typeMSADSURL(driver, configObj.getPropertyValue("adsUrl"));
			Authentication.typeMSADSDomainName(driver, configObj.getPropertyValue("adsDomainName"));
			Authentication.typeMSADSUserDn(driver, configObj.getPropertyValue("adsUserDn"));
			Authentication.typeMSADSPassword(driver, configObj.getPropertyValue("adsPassword"));
			Authentication.typeMSADSReferral(driver, configObj.getPropertyValue("adsDomainName"));
			Authentication.save(driver);
			Authentication.cancel(driver);
			}
		SeleniumUtil.waitForElement(driver, By.linkText("EditSampleMSADS"));
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "EditSampleMSADS");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		SeleniumUtil.click(driver, By.linkText("EditSampleMSADS"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
		Authentication.typeMSADSDomainName(driver, "sample");
		// Testing the connection using incorrect edited data
		Authentication.testMSADSConnection(driver, configObj.getPropertyValue("adsUserName"), configObj.getPropertyValue("adsUserPassword"));		
		// Checking for the test connection failure message
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_edit_testConnect_Result")), "Authentication failed"));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editProfile_Result")), "Authentication details updated successfully");
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_ADS_Domain"))), "sample");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Test Add SAP authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddSAPAuthenticationProfile() throws Exception{
		
		flag=false;
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "TestSAP");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("TestSAP"))){
			Authentication.delete(driver, "TestSAP");
		}
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SAP");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_sap_authName")));
		Authentication.typeSAPAuthName(driver, "TestSAP");
		Authentication.save(driver);
		SeleniumUtil.delay(2000);
			// Verifying the success message
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_testConnection_Result")),"Authentication profile has been added successfully"));
			Authentication.cancel(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addAuthentication")));
			// Verifying the new SAP profile added in the grid. 
			Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "TestSAP");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("TestSAP")));
			SeleniumUtil.click(driver, By.linkText("TestSAP"));
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
			Applications.navigateToApplicationsPage(driver);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.delay(2000);
			List<WebElement> authTypes = Applications.getAuthentication(driver);
			Assert.assertTrue(authTypes.size()>1, "Insufficient authentication profiles listed under authentication type drop dowm of application page.");
			for(WebElement authType:authTypes){
				if(authType.getText().equalsIgnoreCase("TestSAP")){
					flag=true;
				}
			}
			Assert.assertTrue(flag, "Added SAP profile not found under the authentication type drop down of application page.");
			driver.navigate().refresh();
			SeleniumUtil.verifySecurityAudit(driver, "ADDED_AUTH_PROFILE(TestSAP)", "Added authentication profile");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			}
		}
		
	}
	
	/*
	 * Test Edit SAP Authentication profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditSAPProfile(){
		
		try{
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "EditSampleSAP");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("EditSampleSAP"))){
			Authentication.openAddAuthentication(driver);
			Authentication.selectAuthType(driver, "SAP");
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_sap_authName")));
			Authentication.typeSAPAuthName(driver, "EditSampleSAP");
			Authentication.save(driver);
			Authentication.cancel(driver);
			}
		SeleniumUtil.waitForElement(driver, By.linkText("EditSampleSAP"));
		Authentication.searchByText(driver,By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")), "EditSampleSAP");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_authentication_searchBy_name")));
		SeleniumUtil.click(driver, By.linkText("EditSampleSAP"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editAuthentication")), "Edit Authentication");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editAuthProfile_Save")));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editProfile_Result")), "Authentication details updated successfully");
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_cancelEditAuthentication"))),"Cancel button is not present in the edit authentication page");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
		
	/*
	 * Test reset operation of SAP profile
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testResetSAPProfile(){
		
		try{
		Authentication.openAddAuthentication(driver);
		Authentication.selectAuthType(driver, "SAP");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_sap_authName")));
		Authentication.typeSAPAuthName(driver, "testSAP");
		Authentication.reset(driver);
		//Verifying if all values are reset
		Assert.assertTrue(Authentication.getSAPAuthName(driver).isEmpty(),"Authentication name field should be empty.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
