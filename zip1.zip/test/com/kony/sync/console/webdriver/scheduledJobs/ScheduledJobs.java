package com.kony.sync.console.webdriver.scheduledJobs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class ScheduledJobs extends BaseTestcase{
	
	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	public static void navigateToScheduledJobsPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_scheduledJobs_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public static void clickOnLink(WebDriver driver, String linkName){

		try{
			SeleniumUtil.findElement(driver,By.linkText(linkName)).click();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * search by application id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByApplicationID(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_applicationID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get numbers of rows present in the Scheduled Jobs table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{

			WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_scheduledJobs")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
		
	}
	
	/**
	 * search by job name
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByJobName(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_jobName")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by description
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByDescription(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_description")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by status
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByStatus(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_status")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * search by server IP
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByServerIP(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_serverIP")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
	}


	public static void addApplication(WebDriver driver) throws Exception{
		
		try{
			
		Applications.navigateToApplicationsPage(driver);
		Applications.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		String db=configObj.getPropertyValue("database");
		if(db.equalsIgnoreCase("MSSQL"))
		{
			verifyAddedApplication(driver,"TMsSQL");
			verifyAddedApplication(driver,"TMsSQL1");
			verifyAddedApplication(driver,"TMsSQL2");
			verifyAddedApplication(driver,"TMsSQL3");
			verifyAddedApplication(driver,"TMsSQL4");
			verifyAddedApplication(driver,"TMsSQL5");
			verifyAddedApplication(driver,"TMsSQL6");
		}
		if(db.equalsIgnoreCase("MYSQL"))
		{
			verifyAddedApplication(driver,"PRV55ExpFlt");
			verifyAddedApplication(driver,"PRV55ExpFlt1");
			verifyAddedApplication(driver,"PRV55ExpFlt2");
			verifyAddedApplication(driver,"PRV55ExpFlt3");
			verifyAddedApplication(driver,"PRV55ExpFlt4");
			verifyAddedApplication(driver,"PRV55ExpFlt5");
		}
		if(db.equalsIgnoreCase("ORACLE"))
		{
			verifyAddedApplication(driver,"prov");
			verifyAddedApplication(driver,"prov1");
			verifyAddedApplication(driver,"prov2");
			verifyAddedApplication(driver,"prov3");
			verifyAddedApplication(driver,"prov4");
			verifyAddedApplication(driver,"prov5");
		}
		if(db.equalsIgnoreCase("POSTGRE"))
		{
			verifyAddedApplication(driver,"PRVPOSTGRE");
			verifyAddedApplication(driver,"PRVPOSTGRE1");
			verifyAddedApplication(driver,"PRVPOSTGRE2");
			verifyAddedApplication(driver,"PRVPOSTGRE3");
			verifyAddedApplication(driver,"PRVPOSTGRE4");
			verifyAddedApplication(driver,"PRVPOSTGRE5");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
		
	}
	
	public static void verifyAddedApplication(WebDriver driver, String appID) throws Exception{
		Applications.add(driver,appID+".xml");
		SeleniumUtil.delay(2000);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), appID+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		SeleniumUtil.delay(2000);
		if(!SeleniumUtil.findElement(driver,By.xpath("//tr[2]/td[4]//span")).getText().equalsIgnoreCase(appID))
				{
				Applications.add(driver,appID+".xml");
				}
	}
	
}
