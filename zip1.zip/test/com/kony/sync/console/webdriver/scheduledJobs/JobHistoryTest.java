
package com.kony.sync.console.webdriver.scheduledJobs;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class JobHistoryTest extends BaseTestcase{
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){
		
		try{

		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Job History"));
			JobHistory.navigateToJobHistoryPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_pageHeader")), "Job History");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/* 
	 *   Verify Application Link
	 */
	 
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
		if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_appIdColumn")))){
			String parentWindow= driver.getWindowHandle();
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_jobHistory_appId")));
			SeleniumUtil.delay(1000);
			Set<String> handles=driver.getWindowHandles();
			Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
			
			 for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow);

		}else{
			Assert.fail("Application ID not found.");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	
	/*
	 *  Searching based on Application ID- with a valid search text 
	 */
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		String appId=SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_apppId")));
		JobHistory.searchByApplicationID(driver, appId);
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_jobHistory"), appId,configObj.getPropertyValue("txt_jobHistory_appIdInEachRow")),"application Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	 /*
	  *  Searching based on job name- with a valid search text
	  */   
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByJobName(){

		try{
		JobHistory.searchByJobName(driver, "merge");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_jobHistory"), "merge",configObj.getPropertyValue("txt_jobHistory_jobNameInEachRow")),"job name search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	 /*
	  *  Searching based on status- with a valid search text
	  */   
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByStatus(){

		try{
		JobHistory.searchByStatus(driver, "D");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_jobHistory"), "D",configObj.getPropertyValue("txt_jobHistory_statusInEachRow")),"status search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	 /*
	  *  Searching based on server IP- with a valid search text
	  */ 
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByServerIP(){

		try{
		JobHistory.searchByServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_jobHistory"), "0",configObj.getPropertyValue("txt_jobHistory_IPInEachRow"))," Search by server IP is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	 /*
	  *  Searching based on Application ID- with invalid search text 
	  */ 
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){

		try{
		JobHistory.searchByApplicationID(driver, "abcxyz");
		Assert.assertTrue(JobHistory.getRowCount(driver) == 0," Search by Application ID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_applicationID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	 /*
	  *  Searching based on job name- with invalid search text
	  */ 
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByJobName() {

		try{
		JobHistory.searchByJobName(driver, "abcxyz");
		Assert.assertTrue(JobHistory.getRowCount(driver) == 0," Search by job name is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_jobName"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	 /*
	  *  Searching based on status- with invalid search text
	  */  
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByStatus(){

		try{
		JobHistory.searchByStatus(driver, "abcxyz");
		Assert.assertTrue(JobHistory.getRowCount(driver) == 0," Search by status is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_status"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	
	 /* 
	  * Searching based on server IP- with invalid search text
	  */  
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByServerIP(){

		try{
		JobHistory.searchByServerIP(driver, "abcxyz");
		Assert.assertTrue(JobHistory.getRowCount(driver) == 0," Search by server IP is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_serverIP"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	 /*
	  *  Verifying refresh
	  */
	 
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_jobHistory", By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_jobName"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	 /*
	  *  Verifying calendar
	  */  
	 
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_startTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_endTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	
	
	/*
	 * DEF487:Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoDEF487()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_jobHistory"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	
/*	no. of pages changes dynamically, so commenting 
	 *Navigation to pages 
	 
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
	}
	*/
	
	/*
	 *test error details link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testErrorDetailsLink()
	{
		try{
		if(SeleniumUtil.isElementPresent(driver, By.linkText("View Error Details")))
		{
			SeleniumUtil.click(driver, By.linkText("View Error Details"));
			Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath("//span[contains(@id,'Win')]")).equalsIgnoreCase("Error Details"),"Error details pop up is not opened");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,2),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 *test size of page
	 
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "jobHistory";
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_jobHistory_searchBy_jobName");
		
	}
	

	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_jobHistory", By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_jobName"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_jobHistory"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying DataSourceElapsedTime column
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDataSourceElapsedTime() throws Exception{
		List<WebElement> rows=SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_jobHistory"))).findElements(By.tagName("tr"));
		int rowCount = rows.size()-1;
		if(rowCount > 1){
			for(int i=2; i<=rowCount; i++){
				try{
				if(Double.parseDouble(SeleniumUtil.findElement(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_dataSourceElapsedTimeInEachRow").replace("$", i+""))).getText())>0)
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_dataSourceElapsedTimeInEachRowWithSomeVal").replace("$", i+"")));
					SeleniumUtil.delay(2000);
					Assert.assertTrue(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))), "DataSourceLog Window is not opened");
					if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))))
					{
						SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close")));
					}
				}
				}
				catch(Exception e)
				{
					if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))))
					{
						SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close")));
					}
				}
			}
		}
		else {
			Assert.fail("The is no data in the table to verify DataSourceElapsedTime");
		}
	}
	
	@AfterTest
	public void tearDown(){
		try{
		JobHistory.delete(driver);
		System.out.println("tear down method called!!");
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
		finally{
		driver.close();
		driver.quit();
		}
	}

}
