package com.kony.sync.console.webdriver.scheduledJobs;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class ScheduledJobsTest extends BaseTestcase {

	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"),
					configObj.getPropertyValue("password"));
			ScheduledJobs.addApplication(driver);
			// Need to have long wait at this point
			Thread.sleep(10000);
			ScheduledJobs.navigateToScheduledJobsPage(driver);
			// Need to have long wait at this point
			Thread.sleep(40000);
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){
		
		try{
		if (!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout")))) {
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"),
					configObj.getPropertyValue("password"));
		}
		driver.manage().window().maximize();
		SeleniumUtil.waitForElement(driver, By.linkText("Scheduled Jobs"));
		ScheduledJobs.navigateToScheduledJobsPage(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj
				.getPropertyValue("txt_scheduledJobs_pageHeader")),
				"Scheduled Jobs");
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Verify Application Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){

		try{
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_applicationID")));
		if (SeleniumUtil
				.isElementPresent(
						driver,
						By.xpath(configObj.getPropertyValue("txt_scheduuledJobs_appIdColumn")))) {

			SeleniumUtil.waitForElement(driver,
					By.xpath(configObj.getPropertyValue("link_scheduledJobs_appId")));
			String parentWindow= driver.getWindowHandle();
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_scheduledJobs_appId")));
			SeleniumUtil.delay(1000);
			Set<String> s = driver.getWindowHandles();
			Assert.assertTrue(s.size() == 2,
					"Application ID link is not working");
			for(String windowHandle  : s)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow);
		} else {
			Assert.fail("Application ID not found.");
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on Application ID- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		ScheduledJobs.searchByApplicationID(driver, "1");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver,configObj.getPropertyValue("grid_scheduledJobs"), "1",configObj.getPropertyValue("txt_scheduledJobs_appIdInEachRow")),"application Id search is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on job name- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByJobName(){

		try{
		ScheduledJobs.searchByJobName(driver, "merge");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver,configObj.getPropertyValue("grid_scheduledJobs"), "merge",configObj.getPropertyValue("txt_scheduledJobs_jobNameInEachRow"))," Search by job name is not working");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on description- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByDescription(){

		try{
		ScheduledJobs.searchByDescription(driver, "replica");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver,configObj.getPropertyValue("grid_scheduledJobs"), "replica",configObj.getPropertyValue("txt_scheduledJobs_descriptionInEachRow"))," Search by description is not working");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on status- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByStatus(){

		try{
		ScheduledJobs.searchByStatus(driver, "D");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver,configObj.getPropertyValue("grid_scheduledJobs"), "D",configObj.getPropertyValue("txt_scheduledJobs_statusInEachRow"))," Search by status is not working");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on server IP- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByServerIP(){

		try{
		ScheduledJobs.searchByServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver,configObj.getPropertyValue("grid_scheduledJobs"), "0",configObj.getPropertyValue("txt_scheduledJobs_IpInEachRow"))," Search by server IP is not working");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on Application ID- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){

		try{
		ScheduledJobs.searchByApplicationID(driver, "abcxyz");
		Assert.assertTrue(ScheduledJobs.getRowCount(driver) == 0," Search by Application ID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_applicationID"))).equals("abcxyz"),"Text in the search field is not cleared after refreshing");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on job name- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByJobName(){

		try{
		ScheduledJobs.searchByJobName(driver, "abcxyz");
		Assert.assertTrue(ScheduledJobs.getRowCount(driver) == 0," Search by job name is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_jobName"))).equals("abcxyz"),"Text in the search field is not cleared after refreshing");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on description- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByDescription(){

		try{
		ScheduledJobs.searchByDescription(driver, "abcxyz");
		Assert.assertTrue(ScheduledJobs.getRowCount(driver) == 0," Search by description is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_description"))).equals("abcxyz"),"Text in the search field is not cleared after refreshing");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on status- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByStatus(){

		try{
		ScheduledJobs.searchByStatus(driver, "abcxyz");
		Assert.assertTrue(ScheduledJobs.getRowCount(driver) == 0," Search by status is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_status"))).equals("abcxyz"),"Text in the search field is not cleared after refreshing");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on server IP- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByServerIP(){

		try{
		ScheduledJobs.searchByServerIP(driver, "abcxyz");
		Assert.assertTrue(ScheduledJobs.getRowCount(driver) == 0," Search by server IP is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_serverIP"))).equals("abcxyz"),"Text in the search field is not cleared after refreshing");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo() {
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_scheduledJobs"))).findElements(By.tagName("tr")).size() - 1),"Page info is not correct");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh() {
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver,"grid_scheduledJobs",By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_jobName"))),"Refresh is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable() {
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/

	/*
	 * Navigation to pages
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages() {
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * verify sorting of data - checks whether data is changing on the click of
	 * column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData() {
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver, 2),"Data is not sorted on the click of column name");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/*
	 * test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed() {
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}


	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "scheduledjobs";
		
	}

	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_scheduledJobs_searchBy_jobName");
		
	}
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver,"grid_scheduledJobs",By.id(configObj.getPropertyValue("tbx_scheduledJobs_searchBy_jobName"))),"Refresh is not working");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_scheduledJobs"))).findElements(By.tagName("tr")).size() - 1),"Page info is not correct");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test Scheduled jobs are not displayed for OTA
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testScheduleJobsShouldNotBeDisplayedForOTA()
	{
		
		try{
		Applications.navigateToApplicationsPage(driver);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("OTA"))){
				Applications.delete(driver, "OTA");
		}
		Applications.add(driver,"OTASampleSyncConfig.xml");
		ScheduledJobs.navigateToScheduledJobsPage(driver);
		ScheduledJobs.searchByApplicationID(driver, "OTA");
		Assert.assertTrue(ScheduledJobs.getRowCount(driver) == 0,"Schedule jobs for OTA are getting created");	
		}catch(Exception e){
			e.printStackTrace();
		}
		
		}
	
	@AfterTest
	public void tearDown() {

		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}
