package com.kony.sync.console.webdriver.scheduledJobs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class JobHistory extends BaseTestcase{
	
		private static List<WebElement> rowElements = new ArrayList<WebElement>();

		public static void navigateToJobHistoryPage(WebDriver driver){
			
			try{
				SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_jobHistory_mainPage")));
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}

		public static void clickOnLink(WebDriver driver, String linkName){

			try{
				SeleniumUtil.findElement(driver,By.linkText(linkName)).click();
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		
		/**
		 * search by application id
		 * @param driver
		 * @param searchKey
		 */
		
		public static void searchByApplicationID(WebDriver driver, String searchKey){

			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_applicationID")), searchKey+Keys.RETURN);
				SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * get numbers of rows present in the job History table
		 * @param driver
		 * @return count of rows
		 */
		
		public static int getRowCount(WebDriver driver){
			
			rowElements = null;
			try{

				WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_jobHistory")));
				rowElements = table.findElements(By.tagName("tr"));

			}catch(Exception e){
				e.printStackTrace();
			}
			return rowElements.size() - 1;
			
		}
		
		/**
		 * search by job name
		 * @param driver
		 * @param searchKey
		 */
		
		public static void searchByJobName(WebDriver driver, String searchKey){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_jobName")), searchKey+Keys.RETURN);
				SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		/**
		 * search by status
		 * @param driver
		 * @param searchKey
		 */
		
		public static void searchByStatus(WebDriver driver, String searchKey){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_status")), searchKey+Keys.RETURN);
				SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		
		/**
		 * search by server IP
		 * @param driver
		 * @param searchKey
		 */
		
		public static void searchByServerIP(WebDriver driver, String searchKey){
			
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_jobHistory_searchBy_serverIP")), searchKey+Keys.RETURN);
				SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		
		public static void delete(WebDriver driver){

			try{
			Thread.sleep(1000);
			while(!SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")), "Applications"))
			{
			Applications.navigateToApplicationsPage(driver);
			Applications.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			}
			Thread.sleep(1000);
			String db=configObj.getPropertyValue("database");
			if(db.equalsIgnoreCase("MSSQL"))
			{
				Applications.delete(driver,"TMsSql");
				Applications.delete(driver,"TMsSql1");
				Applications.delete(driver,"TMsSql2");
				Applications.delete(driver,"TMsSql3");
				Applications.delete(driver,"TMsSql4");
				Applications.delete(driver,"TMsSql5");
				Applications.delete(driver,"TMsSql6");
			}
			if(db.equalsIgnoreCase("MYSQL"))
			{
				Applications.delete(driver,"PRV");
				Applications.delete(driver,"PRV1");
				Applications.delete(driver,"PRV2");
				Applications.delete(driver,"PRV3");
				Applications.delete(driver,"PRV4");
				Applications.delete(driver,"PRV5");
			}
			if(db.equalsIgnoreCase("ORACLE"))
			{
				Applications.delete(driver,"PRVORACLE");
				Applications.delete(driver,"PRVORACLE1");
				Applications.delete(driver,"PRVORACLE2");
				Applications.delete(driver,"PRVORACLE3");
				Applications.delete(driver,"PRVORACLE4");
				Applications.delete(driver,"PRVORACLE5");
			}
			if(db.equalsIgnoreCase("POSTGRE"))
			{
				Applications.delete(driver,"AppSample");
				Applications.delete(driver,"AppSample1");
				Applications.delete(driver,"AppSample2");
				Applications.delete(driver,"AppSample3");
				Applications.delete(driver,"AppSample4");
				Applications.delete(driver,"AppSample5");
			}
			
			}catch(Exception e){

				Reporter.log("ERROR: problem occurred while deleting application.");
				e.printStackTrace();
			}
		}

	}
