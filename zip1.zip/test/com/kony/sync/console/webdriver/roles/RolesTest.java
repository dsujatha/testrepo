package com.kony.sync.console.webdriver.roles;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class RolesTest extends BaseTestcase{
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){

		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Roles"));
			driver.findElement(By.linkText("Roles")).click();
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_roles_pageHeader")), "Roles");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testRolesPresent(){

		try{
		if(SeleniumUtil.isElementPresent(driver, By.id("rolegrid_name"))){
			String roles[]= {"ROLE_ADMIN","ROLE_REPORT_VIEWER","ROLE_USER"};
			List<WebElement> w= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("grid_roles")));
			for(int i=2;i<=w.size();i++)
			{
				Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("//table[@id='rolegrid']/tbody/tr["+i+"]/td[1]")).getText().equalsIgnoreCase(roles[i-2]),"Role "+roles[i-2]+" is not present");
			}
			
		}
		else{
			Assert.fail("Role table is not present");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		//Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
		if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_collapse"))))
		  {
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_collapse")));
			  ///SeleniumUtil.delay(2000);
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("txt_roleName")));
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-state-default ui-jqgrid-hdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-jqgrid-bdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  SeleniumUtil.click(driver, By.xpath("//a[contains(@class,'HeaderButton')]"));
			  SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("txt_roleName")));
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("txt_roleName"))),"Collpase button is not working");
		  }
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "roles";
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return null;
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
