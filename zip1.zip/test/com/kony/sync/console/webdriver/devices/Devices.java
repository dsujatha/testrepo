package com.kony.sync.console.webdriver.devices;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Devices extends BaseTestcase{

	private static List<WebElement> rowElements = new ArrayList<WebElement>();
	public static String fullDeviceId;  

	public static void navigateToDevicesPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_devices_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public static void clickOnLink(WebDriver driver, String linkName){

		try{
			SeleniumUtil.click(driver, By.linkText(linkName));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by user id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByUserID(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_userID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get numbers of rows present in the Devices table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{
			WebElement table = SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_devices")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
		
	}
	
	/**
	 * search by device Id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByDeviceId(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by device OS
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByDeviceOS(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceOS")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by device model
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByDeviceModel(WebDriver driver, String searchKey){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceModel")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * search by DeviceOS version
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByDeviceOSVersion(WebDriver driver, String searchKey){
		
		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceOSVersion")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by registration time
	 * @param driver
	 * @param registrationTime
	 */
	
	public static void searchByRegistrationTime(WebDriver driver, String registrationTime){
		
		try{
			// wait for registration Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_registrationTime")));
			// Type the date and time to search the record
			//driver.findElement(By.id(configObj.getPropertyValue("tbx_devices_searchBy_registrationTime"))).sendKeys(registrationTime);
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_registrationTime")), registrationTime);
			// close the calendar control
			//driver.findElement(SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_devices_calender_Done")))).click();
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_devices_calender_Done")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
		}
	
	/**
	 * search by updatedon time
	 * @param driver
	 * @param updatedOnTime
	 */
	
	public static void searchByUpdatedOnTime(WebDriver driver, String updatedOnTime){
		
		try{
			// wait for updatedOnTime text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_updatedOnTime")));
			// Type the date and time to search the record
			//driver.findElement(By.id(configObj.getPropertyValue("tbx_devices_searchBy_updatedOnTime"))).sendKeys(updatedOnTime);
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_updatedOnTime")), updatedOnTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_devices_calender_Done")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
		}
	
	/**
	 * set status
	 * @param driver
	 * @param searchKey
	 */
	
	public static void setSearchStatus(WebDriver driver, String searchKey){
		try{
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
			new Select(SeleniumUtil.findElement(driver,By.id("gs_isEnabled"))).selectByVisibleText(searchKey);
			  }
			else{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deviceStatusSearchDropDown")));
				  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_deviceStatusSearchTypes")));
				  for (WebElement option : options) {
				     if(searchKey.equalsIgnoreCase(option.getText()))
				     {
				        option.click();
				     	break;
				     }
				  }
			}
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	/**
	 * search by status
	 * @param driver
	 * @param searchKey
	 */
	
  public static boolean searchByStatus(WebDriver driver, String searchKey){
	  
	  try{
		  setSearchStatus(driver, searchKey);
		  List<WebElement> rows  = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_devices"))).findElements(By.tagName("tr"));
		  int rowCount = rows.size();
		  if(rowCount > 1){
			  for(int i=2; i<=rowCount; i++){
				  if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
				  {
					  if(!SeleniumUtil.getVisibleText(driver, By.xpath("//tr["+i+"]/td[8]//option[@selected='selected']")).equalsIgnoreCase(searchKey)){
					  return false;
				  }
				  }
				  else{
					  if(!SeleniumUtil.getVisibleText(driver, By.xpath("//tr["+i+"]/td[8]/div[@id='s2id_devc']/a/span")).equalsIgnoreCase(searchKey)){
					  return false;
				  }
			  }
		  }
			  }
		  else{
			  Assert.fail("Data might not be existing either in active/inactive in the table to perform search operation");
			  return false;
		  }
		  return true;
	  }catch(Exception e){
		  e.printStackTrace();
		  return false;
	  }
	  
  }

	/**
	 * change user status
	 * @param driver
	 * @param searchKey
	 */
  
	public static void changeDeviceStatus(WebDriver driver, String searchKey){
		
		try{
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
			new Select(SeleniumUtil.findElement(driver,By.id("devc"))).selectByVisibleText(searchKey);
			  }
			else{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deviceStatusDropDown")));
				  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_deviceStatusypes")));
				  for (WebElement option : options) {
				     if(searchKey.equalsIgnoreCase(option.getText()))
				     {
				        option.click();
				     	break;
				     }
				  }
			}
			
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * Delete the given device .
	 * @param driver
	 * @param authName
	 */
	
	public static String delete(WebDriver driver, String deviceid){
		
		try{
			select(driver, deviceid);
			SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteDevice")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
			return fullDeviceId;
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
		
	}
	
	
	/**
	 * select the device from the grid
	 * @param driver
	 * @param deviceid
	 * @return boolean flag
	 */
	
	public static boolean select(WebDriver driver, String deviceid){
		
		boolean flag=false;
		try{
			WebElement	table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_devices")));
			List<WebElement> rows  =	table.findElements(By.tagName("tr"));
			int rowCount = rows.size();
			if(rowCount > 1){
				
				for(int i=2; i<=rowCount; i++){
					
					if(table.findElement(By.xpath("//tr["+i+"]/td[3]/a/span")).getText().contains(deviceid)){
							table.findElement(By.xpath("//tr["+i+"]/td[1]/input")).click();
							fullDeviceId=table.findElement(By.xpath("//tr["+i+"]/td[3]/a/span")).getText();
							flag=true;
							break;
						}
				}
				if(!flag){
					System.out.println("Device id not found.");
				}
			}else{
				System.out.println("No record exist inside the devices grid.");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return flag;
	}
	
}
