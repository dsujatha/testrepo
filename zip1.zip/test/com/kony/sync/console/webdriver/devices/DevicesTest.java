package com.kony.sync.console.webdriver.devices;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.users.Users;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class DevicesTest extends BaseTestcase {

	@BeforeTest
	public void loadDriver() {
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeMethod
	public void setUp() {

		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Devices"));
			Devices.navigateToDevicesPage(driver);
			SeleniumUtil.waitForText(driver,
					By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")),
					"Devices");	
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verify DeviceID Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeviceIDLink(){

		try{
		Devices.searchByDeviceId(driver, "000000000000000");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId")));
		if (SeleniumUtil.isElementPresent(driver,
				By.xpath(configObj.getPropertyValue("txt_deviceIdColumn")))) {

			Devices.clickOnLink(driver, "000000000000000");
			if (SeleniumUtil.isElementPresent(driver, By.xpath(configObj
					.getPropertyValue("txt_editDevices_pageHeader")))) {
				Assert.assertTrue(SeleniumUtil.waitForText(driver,
						By.id(configObj.getPropertyValue("txt_editDevice_id")), "000000000000000"),
						"Device id is not displayed in edit device page");
				Assert.assertTrue(SeleniumUtil.getText(driver,
						By.id(configObj.getPropertyValue("txt_editDevice_os"))).equals("android"),
						"Device OS is not displayed in edit device page");
				Assert.assertTrue(SeleniumUtil.getText(driver,
						By.id(configObj.getPropertyValue("txt_editDevice_model"))).equals("google_sdk"),
						"Device model is not displayed in edit device page");
				Assert.assertTrue(
						SeleniumUtil.getText(driver,
								By.id(configObj.getPropertyValue("txt_editDevice_version"))).equals("2.2"),
						"Device version is not displayed in edit device page");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editDeviceSave")));
				Assert.assertTrue(
						SeleniumUtil.waitForText(driver,
								By.id(configObj.getPropertyValue("txt_editDeviceStatus")),
								"Device updated successfully."),
						"Device is not updated successfully");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editDeviceCancel")));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By
						.xpath(configObj
								.getPropertyValue("txt_devices_pageHeader")),
						"Devices"),
						"Click on cancel is not navigating to devices page");
			} else {
				Assert.fail("Edit device page not found.");
			}
		} else {
			Assert.fail("Device ID not found.");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/*
	 * Edit device details
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditDeviceDetails(){
		
		try{
		Devices.searchByDeviceId(driver, "000000000000000");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId")));
		Devices.clickOnLink(driver, "000000000000000");
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editDevices_pageHeader")), "Edit Device");
		if (SeleniumUtil.isElementPresent(driver, By.xpath(configObj
				.getPropertyValue("txt_editDevices_pageHeader")))) {
			try{
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_os")), "iOS");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_model")), "Ipad");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_version")), "iOS 5.0");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editDeviceSave")));
				SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_devices_mainPage")));
				Devices.searchByDeviceId(driver, "000000000000000");
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_deviceOS")), "iOS"),"OS detail is not saved");
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_deviceModel")), "Ipad"),"Device model detail is not saved");
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_deviceVersion")), "iOS 5.0"),"Device version detail is not saved");
			}
			finally{
				Devices.clickOnLink(driver, "000000000000000");
				SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editDevices_pageHeader")), "Edit Device");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_os")), "android");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_model")), "google_sdk");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_version")), "2.2");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editDeviceSave")));
				SeleniumUtil.verifySecurityAudit(driver, "UPDATED_DEVICE(000000000000000)", "Updated the device");
			}
		}
		else{
			Assert.fail("Edit device page not found.");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


/*	
	 * Searching based on User ID- with a valid search text
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidUserID() throws Exception {

		Devices.searchByUserID(driver, "s");
		//Assert.assertTrue(Devices.getRowCount(driver) == 1);
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_devices"), "s", "//table[@id='devicegrid']//tr[$]/td[3]"),"Valid Search of user ID is not working as expected.");
	}*/

	/*
	 * Searching based on Device Id- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByDeviceID(){
		
		try{
		Devices.searchByDeviceId(driver, "000000000000000");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_devices"), "000000000000000", configObj.getPropertyValue("txt_devices_deviceIdInEachRow")),"Valid Search of device ID is not working as expected.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device OS- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidDeviceOS(){

		try{
		Devices.searchByDeviceOS(driver, "android");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_devices"), "android", configObj.getPropertyValue("txt_devices_deviceOSInEachRow")),"Valid Search of device OS is not working as expected.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device model- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidDeviceModel(){

		try{
		Devices.searchByDeviceModel(driver, "google_sdk");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_devices"), "google_sdk", configObj.getPropertyValue("txt_devices_deviceModelInEachRow")),"Valid Search of device Model is not working as expected.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device OS version- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidDeviceOSVersion(){

		try{
		Devices.searchByDeviceOSVersion(driver, "2.2");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_devices"), "2.2", configObj.getPropertyValue("txt_devices_deviceVersionInEachRow")),"Valid Search of device OS version is not working as expected.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device search status
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeviceSearchStatus(){

		try{
		Assert.assertTrue(Devices.searchByStatus(driver, "Active"),"Status search is not working in devices page.");
		Devices.setSearchStatus(driver, "All");
		Assert.assertTrue(Devices.searchByStatus(driver, "Inactive"),"Status search is not working in devices page.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

/*	
	 * Searching based on registration time with a valid search text
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidRegistrationTime() throws Exception {

		Devices.searchByRegistrationTime(driver, "07/23/2013 17:47:38");
		Assert.assertTrue(Devices.getRowCount(driver) == 1);
	}*/

	/*
	 * Test based on device status
	 * DEF633 - Security Audit showing wrong info when a device is made active or inactive.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeviceStatusDEF633(){

		try{
		Devices.changeDeviceStatus(driver, "Inactive");
		Assert.assertTrue(SeleniumUtil.waitForText(driver,
				By.id(configObj.getPropertyValue("txt_devices_statusMessage")), "Device disabled successfully"));
		SeleniumUtil.verifySecurityAudit(driver, "DISABLED_DEVICE(000000000000000)", "Disabled the device");
		Devices.navigateToDevicesPage(driver);
		SeleniumUtil.waitForText(driver,By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")),"Devices");	
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Devices.changeDeviceStatus(driver, "Active");
		Assert.assertTrue(SeleniumUtil.waitForText(driver,
				By.id(configObj.getPropertyValue("txt_devices_statusMessage")), "Device enabled successfully"));
		SeleniumUtil.verifySecurityAudit(driver, "ENABLED_DEVICE(000000000000000)", "Enabled the device");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

/*	
	 * Searching based on User ID- with invalid search text
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidUserID() throws Exception {

		Devices.searchByUserID(driver, "abcxyz");
		Assert.assertTrue(Devices.getRowCount(driver) == 0);
		driver.findElement(By.xpath("//span[contains(@class,'refresh')]")).click();
		 Assert.assertFalse(driver.findElement(By.id(configObj.getPropertyValue("tbx_devices_searchBy_userID"))).getAttribute("value").equals("abcxyz"), "Text in the search field is not cleared after refreshing");
	}*/

	/*
	 * Searching based on Device Id- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidDeviceID(){

		try{
		Devices.searchByDeviceId(driver, "abcxyz");
		Assert.assertTrue(Devices.getRowCount(driver) == 0);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device OS- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidDeviceOS(){

		try{
		Devices.searchByDeviceOS(driver, "xyz");
		Assert.assertTrue(Devices.getRowCount(driver) == 0);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceOS"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device model- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidDeviceModel(){

		try{
		Devices.searchByDeviceModel(driver, "xyzabc");
		Assert.assertTrue(Devices.getRowCount(driver) == 0);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceModel"))).equals("xyzabc"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on device OS version- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidDeviceOSVersion(){

		try{
		Devices.searchByDeviceOSVersion(driver, "000000");
		Assert.assertTrue(Devices.getRowCount(driver) == 0);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceOSVersion"))).equals("000000"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

/*	
	 * Searching based on registration time with invalid search text
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidRegistrationTime() throws Exception {

		Devices.searchByRegistrationTime(driver, "07/23/2020 17:47:38");
		Assert.assertTrue(Devices.getRowCount(driver) == 0);
	}
	*/
	
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchRegistrationTime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByRegistrationTime(driver, "07/23/2012 17:47:38 +0530");	
			Assert.assertTrue(SeleniumUtil.verifyInitialDateTimeSearch(driver, "07/23/2012 17:47:38 +0530", "grid_devices", configObj.getPropertyValue("txt_devices_registrationTimeInEachRow")),"Valid search for Registration time is not working.");
	}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchRegistrationTime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByRegistrationTime(driver, "07/23/2030 17:47:38 +0530");	
			Assert.assertFalse(SeleniumUtil.verifyInitialDateTimeSearch(driver, "07/23/2030 17:47:38 +0530", "grid_devices", configObj.getPropertyValue("txt_devices_registrationTimeInEachRow")),"Invalid search for Registration time is not working.");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_devices_searchBy_registrationTime"))).contains("07/23/2030 17:47:38"), "Text in the search field is not cleared after refreshing");
		}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByUpdatedOnTime(driver, "03/23/2030 20:27:45 +0530");
			Assert.assertTrue(SeleniumUtil.verifyLaterOnDateTimeSearch(driver, "03/23/2030 20:27:45 +0530", "grid_devices", configObj.getPropertyValue("txt_devices_updatedOnTimeInEachRow")),"Valid search for updated on is not working.");
		}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByUpdatedOnTime(driver, "03/23/2001 20:27:45 +0530");
			Assert.assertFalse(SeleniumUtil.verifyLaterOnDateTimeSearch(driver, "03/23/2001 20:27:45 +0530", "grid_devices", configObj.getPropertyValue("txt_devices_updatedOnTimeInEachRow")),"Invalid search for updated on is not working.");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_devices_searchBy_updatedOnTime"))).contains("03/23/2001 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchRegistrationUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByRegistrationTime(driver, "07/23/2012 17:47:38 +0530");
			Devices.searchByUpdatedOnTime(driver, "03/23/2030 20:27:45 +0530");
			
		Assert.assertTrue(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530", "grid_devices", configObj.getPropertyValue("txt_devices_registrationTimeInEachRow"), configObj.getPropertyValue("txt_devices_updatedOnTimeInEachRow")),"Valid search for registration , updated on together is not working.");
	}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchRegistrationUpdatedOn(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByRegistrationTime(driver, "03/23/2030 20:27:45 +0530");
			Devices.searchByUpdatedOnTime(driver, "07/23/2012 17:47:38 +0530");
			
		Assert.assertFalse(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530", "grid_devices", configObj.getPropertyValue("txt_devices_registrationTimeInEachRow"), configObj.getPropertyValue("tbx_devices_searchBy_updatedOnTime")),"Valid search for registration , updated on together is not working.");
	}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/*
	 * Delete device
	 * DEF490 : Search criteria shows deleted devices also
	 * maintain the data like 11111xxxxx
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteDeviceDEF490(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")), "Devices"))
		{
			Devices.searchByDeviceId(driver, "11111");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId")));
			Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_devices"), "11111", configObj.getPropertyValue("txt_devices_deviceIdInEachRow")),"Valid Search of device ID is not working as expected.");
			String deviceId=Devices.delete(driver, "11111");
			SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteDevice")));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_deleteDevicesMessageid")), "Device(s) deleted successfully."),"Message after deleting device is not proper");
			Devices.searchByDeviceId(driver, deviceId);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText(deviceId)));
			SeleniumUtil.verifySecurityAudit(driver, "DELETED_DEVICE(1111100002)", "Deleted the device");
		}
		else {
			Assert.fail("Devices page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_devices"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_devices", By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceOS"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_registrationTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_updatedOnTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/*
	 * Verifying calendar for registration time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForRegistrationTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_devices_searchBy_registrationTime", "grid_devices", "start")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for updated on
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForUpdatedOn()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_devices_searchBy_updatedOnTime", "grid_devices", "end")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForRegistrationTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_devices_searchBy_registrationTime"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForUpdatedOnTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_devices_searchBy_updatedOnTime"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,3),"Data is not sorted on the click of column name");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	
	 * verify page title
	 
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle() throws Exception{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_devices")), "page title is not appropriate");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return "devices";
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return configObj.getPropertyValue("tbx_devices_searchBy_deviceId");
	}
	
	/*
	 *verify delete with out selecting device
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteWithOutSelectingADevice()
	{
		
		try{
		SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteDevice")));
		SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteDevice")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please select at least one device to delete."), "Error pop up is not shown when trying to delete with out selecting any device.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *verify display of single quote character while editing a device
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDisplayOfSingleQuoteCharacterOnEditDevice()
	{
		
		try{
		Devices.searchByDeviceId(driver, "1111100005");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceId")));
		Devices.clickOnLink(driver, "1111100005");
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_editDevices_pageHeader")), "Edit Device");
		if (SeleniumUtil.isElementPresent(driver, By.xpath(configObj
				.getPropertyValue("txt_editDevices_pageHeader")))) {
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_os")), "android's");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_model")), "google_sdk's");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("txt_editDevice_version")), "2.2's");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editDeviceSave")));
				SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_devices_mainPage")));
				Devices.searchByDeviceId(driver, "1111100005");
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_deviceOS")), "android's"),"OS detail is not saved properly when it contains single quote");
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_deviceModel")), "google_sdk's"),"Device model detail is not saved when it contains single quote");
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_deviceVersion")), "2.2's"),"Device version detail is not saved when it contains single quote");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_devices", By.id(configObj.getPropertyValue("tbx_devices_searchBy_deviceOS"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_devices"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verify delete operation of device when it is already assigned to a user
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteOfDeviceWhenItIsAssignedToUserAndDeAssigned(){
		
		try{
		Users.navigateToUsersHomePage(driver);
		SeleniumUtil.delay(2000);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser34");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		if(Users.isElementPresent(driver, By.linkText("SampleUser34"))){
			Users.delete(driver, "SampleUser34");
			Users.add(driver, "SampleUser34", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}else{
			Users.add(driver, "SampleUser34", "sampleuser123", "sample user", "sync@kony.com", "1234567890", "kony");
		}
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser34");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		Users.waitForElement(driver, By.linkText("SampleUser34"));
		SeleniumUtil.click(driver, By.linkText("SampleUser34"));
		Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
		Users.assignDevice(driver,"1111100018");
		Devices.navigateToDevicesPage(driver);
		SeleniumUtil.waitForText(driver,By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")),"Devices");	
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Devices.searchByDeviceId(driver, "1111100018");
		Devices.delete(driver, "1111100018");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("txt_deleteDevicesMessageid"))), "Unable to delete one or more devices, check whether any users are assigned to the device");
		Users.navigateToUsersHomePage(driver);
		SeleniumUtil.delay(2000);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser34");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		SeleniumUtil.click(driver, By.linkText("SampleUser34"));
		Users.deAssignDevice(driver, "1111100018");
		Devices.navigateToDevicesPage(driver);
		SeleniumUtil.waitForText(driver,By.xpath(configObj.getPropertyValue("txt_devices_pageHeader")),"Devices");	
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Devices.searchByDeviceId(driver, "1111100018");
		Devices.delete(driver, "1111100018");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("txt_deleteDevicesMessageid"))), "Device(s) deleted successfully.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown() {

		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
