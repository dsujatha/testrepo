package com.kony.sync.console.webdriver.groups;

import java.text.SimpleDateFormat;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Groups extends BaseTestcase {

	public static boolean flag=false;
	private static String status=null;
	private static List<WebElement> options=null;
	private static WebDriverWait wait=null;
	private static String alertText=null;
	
	public static void navigateToGroupsPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_groups")));
		waitForElement(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while navigating to the groups home page.");
			e.printStackTrace();
		}
		
	}
	
	/**
	 * create group
	 * @param groupName
	 * @param groupDetails
	 * @return status message
	 */
	
	public static String add(WebDriver driver, String groupName, String groupDetails){
		
		status=null;
		try {
		waitForElement(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
		driver.switchTo().activeElement();
		waitForElement(driver, By.id(configObj.getPropertyValue("tbx_groupName")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), groupName);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupDetails")), groupDetails);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup_Save")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("msg_createGroupStatus")));
		status=SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("msg_createGroupStatus"))).toString();
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addGroup_Cancel")));
	
		} catch (Exception e) {
			Reporter.log("ERROR: problem occurred while creating a group.");
			e.printStackTrace();
		}
		return status;
		
	}
	
	/**
	 * delete group
	 * @param groupName
	 * @return true, if group deleted successfully else false.
	 */
	
	public static boolean delete(WebDriver driver, String groupName){
		
		flag=false;
		try{
			waitForElement(driver, By.linkText(groupName));
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_searchByGroupName")), groupName+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			select(driver, groupName);
			SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteGroup")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
			flag=true;
		}catch(Exception e){
			flag=false;
			Reporter.log("ERROR: problem occurred while deleting a group.");
			e.printStackTrace();
		}
		return flag;
		
	}
	
	/**
	 * Edit existing group.
	 * @param groupName
	 * @param newGroupName
	 * @param newGroupDetails
	 * @return status message
	 */
	
	public static String edit(WebDriver driver, String groupName, String newGroupName, String newGroupDetails){
		
		status=null;
		try{
		waitForElement(driver, By.linkText(groupName));
		SeleniumUtil.click(driver, By.linkText(groupName));
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groupName")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), newGroupName);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groupDetails")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupDetails")), newGroupDetails);
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("msg_editGroupStatus")));
		status = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editGroupStatus"))).toString();
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
		
	}
	
	/**
	 * Assign role to a group
	 * @param groupName
	 * @param role
	 * @return status message
	 */
	
	public static String assignRolesToGroup(WebDriver driver, String groupName, String role){
		
		status=null;
		try{
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), groupName);
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
		waitForElement(driver, By.linkText(groupName));
		SeleniumUtil.click(driver, By.linkText(groupName));
		waitForElement(driver, By.id(configObj.getPropertyValue("tbx_groupName")));
		new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_availableRoles")))).selectByVisibleText(role);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_attachRole")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("msg_editGroupStatus")));
		status = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editGroupStatus"))).toString();
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
		
	}
	
	
	/**
	 * Assign application to a group.
	 * @param driver
	 * @param groupName
	 * @param appName
	 * @return status message
	 */
	
	public static String assignApplicationToGroup(WebDriver driver, String groupName, String appName){
		
		status=null;
		try{
			Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), groupName);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			waitForElement(driver, By.linkText(groupName));
			SeleniumUtil.click(driver, By.linkText(groupName));
			waitForElement(driver, By.id(configObj.getPropertyValue("tbx_groupName")));
			new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_availableApplications")))).selectByVisibleText(appName);
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_attachApplication")));
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
			SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("msg_editGroupStatus")));
			status = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_editGroupStatus"))).toString();
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
		
	}
	
	public static List<WebElement> getRolesAssignedToGroup(WebDriver driver, String groupName){
		
		options=null;
		try{
			Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), groupName);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
		waitForElement(driver, By.linkText(groupName));
		SeleniumUtil.click(driver, By.linkText(groupName));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("list_attachedRoles")));
		options = new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_attachedRoles")))).getOptions();
		}catch(Exception e){
			e.printStackTrace();
		}
		return options;
		
	}
	
	public static List<WebElement> getApplicationsAssignedToGroup(WebDriver driver, String groupName){
		
		options=null;
		try{
			Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), groupName);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
		waitForElement(driver, By.linkText(groupName));
		SeleniumUtil.click(driver, By.linkText(groupName));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("list_attachedApplications")));
		options = new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_attachedApplications")))).getOptions();
		}catch(Exception e){
			e.printStackTrace();
		}
		return options;
		
	}
	
	
	 /**
	   * wait for an element until it displayed on the page otherwise timeout after 10 seconds.
	   * @param driver
	   * @param byElement
	   * @return byElement
	   */
	
	  public static By waitForElement(WebDriver driver, By byElement){
		  
		  wait = new WebDriverWait(driver, 10L);
		  try{
		  wait.until(ExpectedConditions.visibilityOfElementLocated(byElement));
		  
		  }catch(Exception e){
			  Reporter.log("FAILURE: waitForElement, "+byElement+" has not found. TIMED OUT AFTER 10 SECONDS. \n"+e);
		  }
		return byElement;
		
	  }
	  
	  /**
		  * close the alert and return the text present on the alert box
		  * @return text
		  */
	  
		  public static String closeAlertAndGetItsText(WebDriver driver, boolean acceptAlert) {
			  
			  	alertText=null;
			    try {
			      Alert alert = driver.switchTo().alert();
			       alertText = alert.getText();
			      if (acceptAlert) {
			        alert.accept();
			      } else {
			        alert.dismiss();
			      }
			      return alertText;
			    }finally{
			    	acceptAlert=false;
			    }
			    
			  }

		  /**
		   * check if element is present on the page
		   * @param by
		   * @return true or false
		   */
		  
		  public static boolean isElementPresent(WebDriver driver, By by) {
			  
			  boolean flag=false;
			    try {
			      driver.findElement(by);
			      return true;
			    } catch (NoSuchElementException e) {
			      flag = false;
			    }
			    return flag;
			    
			  }
		  
		  /**
			 * select the group name from the grid
			 * @param driver
			 * @param groupName
			 * @return boolean flag
			 */
		  
			public static boolean select(WebDriver driver, String groupName){
				
				boolean flag=false;
				try{
					WebElement	table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_row")));
					List<WebElement> rows  =	table.findElements(By.tagName("tr"));
					int rowCount = rows.size();
					if(rowCount > 1){
						
						for(int i=2; i<=rowCount; i++){
							
							if(table.findElement(By.xpath("//tr["+i+"]/td[3]/a/span")).getText().equals(groupName)){
									table.findElement(By.xpath("//tr["+i+"]/td[1]/input")).click();
									flag=true;
									break;
								}
						}
						if(!flag){
							System.out.println("Group name not found.");
						}
					}else{
						System.out.println("No record exist inside the Group grid.");
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}
				return flag;
				
			}
			
			/**
			 * search by text
			 * @param driver
			 * @param searchKey
			 */
			
			public static void searchByText(WebDriver driver , By by , String searchKey){

				try{
					SeleniumUtil.setText(driver, by, searchKey+Keys.RETURN);
					SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

				}catch(Exception e){
					e.printStackTrace();
				}
				
			}
			
			/**
			   * check if search of insertedOnDate displays correct data
			   * @param driver
			   * @param insertedOnDate
			   * @return true or false
			   */
			
			  public static boolean verifyInsertedOnSearch(WebDriver driver, String insertedOnDate)
			  {
				  
				  try{
					  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
					  List<WebElement> rows = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_groups"))).findElements(By.tagName("tr"));
						int rowCount = rows.size();
					  if(rowCount>1)
					  {
						  for(int i=2; i<=rowCount; i++){
							  SeleniumUtil.waitForElement(driver, By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[7]"));
							  if(!(fmt.parse(SeleniumUtil.findElement(driver,By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[7]")).getText()).getTime()>=fmt.parse(insertedOnDate).getTime())){
								  return false;
							  }
						  }
					  }
					  else{
						  return false;
					  }
					  return true;
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
					  return false;
				  }
				  
			  }
			  
			  /**
			   * check if search of updatedOnDate displays correct data
			   * @param driver
			   * @param updatedOnDate
			   * @return true or false
			   */
			  
			  public static boolean verifyUpdatedOnSearch(WebDriver driver, String updatedOnDate)
			  {
				  
				  try{
					  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
					  List<WebElement> rows = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_groups"))).findElements(By.tagName("tr"));
					  int rowCount = rows.size();
					  if(rowCount>1)
					  {
						  for(int i=2; i<=rowCount; i++){
							  SeleniumUtil.waitForElement(driver, By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[8]"));
							  if(!(fmt.parse(SeleniumUtil.findElement(driver,By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[8]")).getText()).getTime()<=fmt.parse(updatedOnDate).getTime())){
								  return false;
							  }
						  }
					  }
					  else{
						  return false;
					  }
					  return true;
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
					  return false;
				  }
				  
			  }
			  
			  /**
			   * check if search of insertedOnDate and updatedOnDate together displays correct data
			   * @param driver
			   * @param insertedOnDate
			   * @param updatedOnDate
			   * @return true or false
			   */
			  
			  public static boolean verifyInsertedOnUpdatedOnSearch(WebDriver driver,String insertedOnDate, String updatedOnDate)
			  {
				  
				  try{

					  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
					  List<WebElement> rows = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_groups"))).findElements(By.tagName("tr"));
					  int rowCount = rows.size();
					  if(rowCount>1)
					  {
						for (int i = 2; i <= rowCount; i++) {
							SeleniumUtil.waitForElement(driver,
									By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[8]"));
							if (!((fmt.parse(
									SeleniumUtil.findElement(driver,
											By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[7]"))
											.getText()).getTime() >= fmt.parse(
									insertedOnDate).getTime()) && (fmt.parse(
											SeleniumUtil.findElement(driver,
											By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[7]"))
											.getText()).getTime() <= fmt.parse(
									updatedOnDate).getTime())))
							{
								return false;
							}
									
							if (!((fmt.parse(
									SeleniumUtil.findElement(driver,
													By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[8]"))
													.getText()).getTime() >= fmt.parse(
											insertedOnDate).getTime()) && (fmt.parse(
													SeleniumUtil.findElement(driver,
													By.xpath("//table[@id='groupgrid']//tr["+i+"]/td[8]"))
													.getText()).getTime() <= fmt.parse(
											updatedOnDate).getTime()))) {
								return false;
							}
						  }
					  }
					  else{
						  return false;
					  }
					  return true;
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
					  return false;
				  }
				  
			  }
			  
			  /**
			   * DeAssigns the role from that group
			   * @param driver
			   * @param role
			   */
			  
			  public static void deAssignRole(WebDriver driver, String role){
				  
				  try{
					  selectRoleFromAssignedRoles(driver, role);
					  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_detachRole")));
					  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
					  }catch(Exception e){
						  e.printStackTrace();
					  }
				  
			  }
			  
			  /**
			   * select the role which is assigned to a group.
			   * @param driver
			   * @param role
			   */
			  
			  public static void selectRoleFromAssignedRoles(WebDriver driver, String role){
				  
				  try{
					  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectedRoles")))).selectByVisibleText(role);
					  }catch(Exception e){
						  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
						  e.printStackTrace();
					  }
				  
			  }
			  
			  /**
			   * DeAssigns the application from that group
			   * @param driver
			   * @param application
			   */
			  
			  public static void deAssignApplication(WebDriver driver, String application){
				  
				  try{
					  selectApplicationFromAssignedApplications(driver, application);
					  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_detachApplication")));
					  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
					  }catch(Exception e){
						  e.printStackTrace();
					  }
				  
			  }
			  
			  /**
			   * select the application which is assigned to a group.
			   * @param driver
			   * @param application
			   */
			  
			  public static void selectApplicationFromAssignedApplications(WebDriver driver, String application){
				  
				  try{
					  new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_selectedApplications")))).selectByVisibleText(application);
					  }catch(Exception e){
						  Reporter.log("ERROR: Problem occurred while selecting the given option in the drop down.");
						  e.printStackTrace();
					  }
				  
			  }
			  
}
