
package com.kony.sync.console.webdriver.groups;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.users.Users;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;


public class GroupsTest extends BaseTestcase{

		List<WebElement> options=null;
		
		@BeforeTest
		public void loadDriver() {
			
			try {
				super.setUp();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@BeforeMethod
		public void setUp(){
			
			try{
			if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
			{
				driver.get(configObj.getPropertyValue("baseUrl"));
				driver.manage().window().maximize();
				Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
			}
				driver.manage().window().maximize();
				SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_groups")));
				SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Sync-238:Add New Group
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testAddGroup(){
			
			try{
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			if(Groups.isElementPresent(driver, By.linkText("TestGroup"))){
				Groups.delete(driver, "TestGroup");
			}
			Assert.assertEquals(Groups.add(driver, "TestGroup","Group added for testing purpose."), "Group TestGroup added successfully.");
			Groups.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
			Assert.assertTrue(Groups.isElementPresent(driver, By.linkText("TestGroup")),"Group is not added");
			SeleniumUtil.verifySecurityAudit(driver, "ADDED_GROUP(TestGroup)", "Created new group");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
		
		/*
		 * Sync-242:Delete Group
		 * DEF491: Logged in user is able to delete the 'Groups' and as a result the user not able to login anymore
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testDeleteGroupDEF491(){
			
			try{
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			if(!Groups.isElementPresent(driver, By.linkText("TestGroup"))){
				Groups.add(driver, "TestGroup", "Group added for testing purpose");
			}
			
			Assert.assertTrue(Groups.delete(driver, "TestGroup"),"Group is not deleted.");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.linkText("TestGroup"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_deleteGroupsMessageid")), "Group(s) deleted successfully."),"Message after deleting group is not proper");
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
			Assert.assertFalse(Groups.isElementPresent(driver, By.linkText("TestGroup")),"Group is not deleted.");
			
			Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "Administrator");
			Groups.delete(driver, "Administrator");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_deleteGroupsMessageid")), "One or more of the groups cannot be deleted, because they are assigned to one or more users."),"Error message for deleting logged in user group is not proper");
			Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "Administrator");
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Administrator")),"Logged in user group is deleted");
			SeleniumUtil.verifySecurityAudit(driver, "DELETED_GROUP(TestGroup)", "Deleted the group");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Sync-239:Edit Group
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testEditGroup(){
			
			try{
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			if(!Groups.isElementPresent(driver, By.linkText("TestGroup"))){
				Groups.add(driver, "TestGroup", "Group added for testing purpose");
			}
			if(Groups.isElementPresent(driver, By.linkText("EditedTestGroup"))){
				Groups.delete(driver, "EditedTestGroup");
				Groups.navigateToGroupsPage(driver);
			}
			
			Assert.assertEquals(Groups.edit(driver, "TestGroup","EditedTestGroup","Group edited for testing purpose"), "Group updated successfully.");
			SeleniumUtil.verifySecurityAudit(driver, "UPDATED_GROUP(EditedTestGroup)", "Updated the group");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Sync-240:Assign/DeAssign Role to Group
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testAssignDeAssignRoleToGroup(){
			
			try{
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			if(Groups.isElementPresent(driver, By.linkText("TestGroup"))){
				Groups.delete(driver, "TestGroup");
				Groups.add(driver, "TestGroup", "Test group added for testing purpose.");
			}else{
				Groups.add(driver, "TestGroup", "Test group added for testing purpose.");
			}
			/*
			 * Different existing roles are: ROLE_ADMIN, ROLE_USER, ROLE_REPORT_VIEWER
			 */
			Assert.assertEquals(Groups.assignRolesToGroup(driver, "TestGroup", "ROLE_ADMIN"), "Group updated successfully.");
			Groups.navigateToGroupsPage(driver);
			Groups.assignRolesToGroup(driver, "TestGroup", "ROLE_REPORT_VIEWER");
			Groups.navigateToGroupsPage(driver);
			options = Groups.getRolesAssignedToGroup(driver, "TestGroup");
			Assert.assertTrue(options.size()==2);
			Assert.assertEquals(options.get(0).getText(),"ROLE_ADMIN");
			Assert.assertEquals(options.get(1).getText(),"ROLE_REPORT_VIEWER");
			Groups.deAssignRole(driver, "ROLE_REPORT_VIEWER");
			Groups.navigateToGroupsPage(driver);
			options = Groups.getRolesAssignedToGroup(driver, "TestGroup");
			Assert.assertTrue(options.size()==1);
			SeleniumUtil.verifySecurityAudit(driver, "UPDATED_GROUP(TestGroup)", "Updated the group");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		/*
		 *   Sync-241:Assign Application to Group
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testAssignApplicationToGroup(){
			
			try{
		 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup");
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			if(Groups.isElementPresent(driver, By.linkText("TestGroup"))){
				Groups.delete(driver, "TestGroup");
				Applications.navigateToApplicationsPage(driver);
				Applications.add(driver,"OTASampleSyncConfig.xml");
				Groups.navigateToGroupsPage(driver);
				Groups.add(driver, "TestGroup", "Test group added for testing purpose.");
			}else{
				Applications.navigateToApplicationsPage(driver);
				Applications.add(driver,"OTASampleSyncConfig.xml");
				Groups.navigateToGroupsPage(driver);
				Groups.add(driver, "TestGroup", "Test group added for testing purpose.");
			}
			Assert.assertEquals(Groups.assignApplicationToGroup(driver, "TestGroup", "OTA"), "Group updated successfully.");
			Groups.navigateToGroupsPage(driver);
			Groups.assignApplicationToGroup(driver, "TestGroup", "TestOTA10");
			Groups.navigateToGroupsPage(driver);
			options = Groups.getApplicationsAssignedToGroup(driver, "TestGroup");
			Assert.assertTrue(options.size()==2);
			Assert.assertEquals(options.get(0).getText(),"OTA");
			Assert.assertEquals(options.get(1).getText(),"TestOTA10");
			Groups.deAssignApplication(driver, "TestOTA10");
			Groups.navigateToGroupsPage(driver);
			options = Groups.getApplicationsAssignedToGroup(driver, "TestGroup");
			Assert.assertTrue(options.size()==1);
			SeleniumUtil.verifySecurityAudit(driver, "UPDATED_GROUP(TestGroup)", "Updated the group");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}

		@Test(enabled=true, timeOut=300000)
		public void testValidSearchByGroupName(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "Administrator");
					Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "Administrator", configObj.getPropertyValue("txt_groups_groupNameInEachRow")),"Valid Search of group name is not working as expected.");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchByGroupName(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "xyz");
					Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "xyz", configObj.getPropertyValue("txt_groups_groupNameInEachRow")),"Invalid Search of group name is not working as expected.");
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
					Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		@Test(enabled=true, timeOut=300000)
		public void testValidSearchByDescription(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_description")), "group");
				 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "group", configObj.getPropertyValue("txt_groups_DescriptionInEachRow")),"Valid Search of description is not working as expected.");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchByDescription(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_description")), "xyz");
				 Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "xyz", configObj.getPropertyValue("txt_groups_DescriptionInEachRow")),"Invalid Search of description is not working as expected.");
				 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
				 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_description"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testValidSearchByInsertID(){
			
		try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedid")), "syncadmin");
				 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "syncadmin", configObj.getPropertyValue("txt_groups_InsertIdInEachRow")),"Valid Search of insert ID is not working as expected.");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchByInsertID(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedid")), "xyz");
				 Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "xyz", configObj.getPropertyValue("txt_groups_InsertIdInEachRow")),"Invalid Search of insert ID is not working as expected.");
				 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
				 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedid"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testValidSearchByUpdatedID(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedid")), "syncadmin");
				 Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "syncadmin", configObj.getPropertyValue("txt_groups_UpdatedIdInEachRow")),"Valid Search of updated ID is not working as expected.");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchByUpdatedID(){
			
			try{
			 if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
				{
				 Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedid")), "xyz");
				 Assert.assertFalse(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_groups"), "xyz", configObj.getPropertyValue("txt_groups_UpdatedIdInEachRow")),"Invalid Search of updated ID is not working as expected.");
				 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
				 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedid"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
				}
				else {
					Assert.fail("Groups page is not obtained");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		@Test(enabled=true, timeOut=300000)
		public void testValidSearchInsertedOn(){
			
			try{
			if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
			{
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedon")), "03/23/2012 20:27:45 +0530");	
			Assert.assertTrue(Groups.verifyInsertedOnSearch(driver,"03/23/2012 20:27:45 +0530"),"Valid search for inserted on is not working.");
		}
			else {
				Assert.fail("Groups page is not obtained");
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchInsertedOn(){
			
			try{
			if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
			{
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedon")), "03/23/2030 20:27:45 +0530");
			Assert.assertFalse(Groups.verifyInsertedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Invalid search for inserted on is not working.");
			 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedon"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
		}
			else {
				Assert.fail("Groups page is not obtained");
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testValidSearchUpdatedOn(){
			
		try{
			if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
			{
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedon")), "03/23/2030 20:27:45 +0530");
			Assert.assertTrue(Groups.verifyUpdatedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Valid search for updated on is not working.");
		}
			else {
				Assert.fail("Groups page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchUpdatedOn(){
			
			try{
			if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
			{
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedon")), "03/23/2001 20:27:45 +0530");
			Assert.assertFalse(Groups.verifyUpdatedOnSearch(driver,"03/23/2001 20:27:45 +0530"),"Invalid search for updated on is not working.");
			 SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedon"))).contains("03/23/2001 20:27:45"), "Text in the search field is not cleared after refreshing");
		}
			else {
				Assert.fail("Groups page is not obtained");
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
			
		@Test(enabled=true, timeOut=300000)
		public void testValidSearchInsertedOnUpdatedOn(){
			
			try{
			if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
			{
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedon")), "03/23/2012 20:27:45 +0530");
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedon")), "03/23/2030 20:27:45 +0530");
				
			Assert.assertTrue(Groups.verifyInsertedOnUpdatedOnSearch(driver,"03/23/2012 20:27:45 +0530", "03/23/2030 20:27:45 +0530"),"Valid search for inserted on, updated on together is not working.");
		}
			else {
				Assert.fail("Groups page is not obtained");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		}
		
		@Test(enabled=true, timeOut=300000)
		public void testInValidSearchInsertedOnUpdatedOn(){
			
			try{
			if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups"))
			{
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedon")), "03/23/2030 20:27:45 +0530");
				Groups.searchByText(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedon")), "03/23/2001 20:27:45 +0530");
			Assert.assertFalse(Groups.verifyInsertedOnUpdatedOnSearch(driver,"03/23/2030 20:27:45 +0530", "03/23/2012 20:27:45 +0530"),"InValid search for inserted on, updated on together is not working.");
			}
			else {
				Assert.fail("Groups page is not obtained");
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Verifying page info
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testPageInfo()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_groups"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		/*
		 * Verifying refresh
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testRefresh()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_groups", By.id(configObj.getPropertyValue("tbx_groups_searchBy_description"))),"Refresh is not working");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
/*		
		 * Verifying calendar
		 
		@Test(enabled=true, timeOut=300000)
		public void testCalendar() throws InterruptedException
		{
			driver.findElement(By.id(configObj.getPropertyValue("tbx_groups_searchBy_insertedon"))).click();
			Thread.sleep(1000);
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@id='ui-datepicker-div' and contains(@style,'display: block')]")),"Calendar is not present");
			driver.findElement(By.id(configObj.getPropertyValue("tbx_groups_searchBy_updatedon"))).click();
			Thread.sleep(1000);
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@id='ui-datepicker-div' and contains(@style,'display: block')]")),"Calendar is not present");
		}*/
		
		
		
		/*
		 * Verifying calendar for inserted time
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testCalendarForInsertedOn()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_groups_searchBy_insertedon", "grid_groups", "start")," Time search through calendar is not working");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		/*
		 * Verifying calendar for updated on
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testCalendarForUpdatedOn()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_groups_searchBy_updatedon", "grid_groups", "end")," Time search through calendar is not working");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		
		/*
		 * Verifying alternative clicks on inserted on time field to check the presence of calendar
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void verifyAlternativeClicksForInsertedOnTimeField()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_groups_searchBy_insertedon"), "Calendar is not visible on alternate clicks");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		/*
		 * Verifying alternative clicks on updated on time field to check the presence of calendar
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void verifyAlternativeClicksForUpdatedOnTimeField()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_groups_searchBy_updatedon"), "Calendar is not visible on alternate clicks");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
/*		
		 * Verifying Collapse button to minimize and expand the table
		 
		@Test(enabled=true, timeOut=300000)
		public void testCollapseOfTable()
		{
			Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
		}*/
		
		
		/*
		 *Navigation to pages 
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testNavigationOfPages()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 * verify sorting of data - checks whether data is changing on the click of column name
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testSortingOfData()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,3),"Data is not sorted on the click of column name");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 *test size of page
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testNoOfRecordsToBeDisplayed()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		/*
		 * verify edit profile
		 */
		
		@Test(enabled=true, timeOut=300000)
		 public void testEditProfile(){
			
			try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_users")));	
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SyncSampleUser");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
			if(Users.isElementPresent(driver, By.linkText("SyncSampleUser"))){
				Users.delete(driver, "SyncSampleUser");
				Users.add(driver, "SyncSampleUser", "syncsampleuser123", "sync sample user", "sync@kony.com", "1234567890", "kony");
			}else{
				Users.add(driver, "SyncSampleUser", "syncsampleuser123", "sync sample user", "sync@kony.com", "1234567890", "kony");
			}
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SyncSampleUser");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
			Users.waitForElement(driver, By.linkText("SyncSampleUser"));
			SeleniumUtil.click(driver, By.linkText("SyncSampleUser"));
			Users.waitForElement(driver, By.id(configObj.getPropertyValue("btn_changePassword")));
			Users.assignGroup(driver, "SyncSampleUser", "Administrator");
			SeleniumUtil.click(driver, By.linkText("Logout"));
			Login.login(driver, "SyncSampleUser", "syncsampleuser123");
			
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_groups")));
			Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup9");
		 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			if(Groups.isElementPresent(driver, By.linkText("TestGroup9"))){
				Groups.delete(driver, "TestGroup9");
			}
			Groups.add(driver, "TestGroup9","Group added for testing purpose.");
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
			driver.switchTo().activeElement();
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup_Save")));
			SeleniumUtil.closeAlertBoxAndGetItsText(driver);
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addUserCancel")));
			SeleniumUtil.click(driver, By.linkText("Edit Profile"));
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cancel_editProfile")));
			  Groups.delete(driver, "TestGroup9");
			  SeleniumUtil.click(driver, By.linkText("Logout"));
				Login.login(driver, "SyncSampleUser", "syncsampleuser123");
			  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("btn_login"))), "User is not able to login after editing his profile and deleting a group");
			}
			finally{
				if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				} 
				Login.logout(driver);
			}
			
		}
		
/*		@Test(enabled=true, timeOut=300000)
		public void testPageTitle() throws Exception{
			Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_groups")), "page title is not appropriate");
		}*/
		
		
		/*
		 * verify page title
		 */
		
		@Override
		protected String getPageId() {
			return "groups";
		}
		
		/*
		 * verify affect of event on calendar field on other fields of the page
		 */

		protected String getSearchId() {
			return configObj.getPropertyValue("tbx_groups_searchBy_groupname");
		}
		
		/*
		 *verify delete with out selecting a group
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testDeleteWithOutSelectingAGroup()
		{
			
			try{
			SeleniumUtil.waitForElement(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteGroup")));
			SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteGroup")));
			Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please select at least one Group to delete."), "Error pop up is not shown when trying to delete with out selecting any group.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 *verify display of single quote character while adding a new group
		 */
		@Test(enabled=true, timeOut=300000)
		public void testDisplayOfSingleQuoteCharacterOnNewGroup()
		{
			
			try{
			 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup'10");
			 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
				if(Groups.isElementPresent(driver, By.linkText("TestGroup'10"))){
					Groups.delete(driver, "TestGroup'10");
				}
				Assert.assertEquals(Groups.add(driver, "TestGroup'10","Group added' for testing purpose."), "Group TestGroup'10 added successfully.");
				Groups.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
			 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup'10");
				Assert.assertTrue(Groups.isElementPresent(driver, By.linkText("TestGroup'10")),"Group is not added");
				String description= SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_groups_description")));
			    Assert.assertFalse(description.contains("&#039;"), "Single quote is displayed as '&#039;' in group description");
			    Assert.assertTrue(description.equalsIgnoreCase("Group added' for testing purpose."), "Description is not saved as expected");
			    String name= SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("txt_groups_groupName")));
			    Assert.assertFalse(name.contains("&#039;"), "Single quote is displayed as '&#039;' in group name");
			    Assert.assertTrue(name.equalsIgnoreCase("TestGroup'10"), "name is not saved as expected");
				}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		/*
		 *verify display of single quote character while editing a group
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testDisplayOfSingleQuoteCharacterOnEditGroup()
		{
			
			try{
			 	Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "8");
			 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
			 	if(Groups.isElementPresent(driver, By.linkText("TestGroup'8"))){
					Groups.select(driver, "TestGroup'8");
					SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("btn_deleteGroup")));
					SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
				}
				if(!Groups.isElementPresent(driver, By.linkText("TestGroup8"))){
					Groups.add(driver, "TestGroup8","Group added for testing purpose.");
				}
			    Assert.assertEquals(Groups.edit(driver, "TestGroup8","TestGroup'8","Group' edited for testing purpose"),"Group updated successfully.");
				SeleniumUtil.click(driver, SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_editGroup_Cancel"))));
			    SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
			    
			    Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_addGroup"))),"Cancel button is not working in Edit Group page");
			    Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup'8");
			 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));

				String description= SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("txt_groups_description")));
			    Assert.assertFalse(description.contains("&#039;"), "Single quote is displayed as '&#039;' in group description");
			    Assert.assertTrue(description.equalsIgnoreCase("Group' edited for testing purpose"), "Description is not saved as expected");
			    String name= SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("txt_groups_groupName")));
			    Assert.assertFalse(name.contains("&#039;"), "Single quote is displayed as '&#039;' in group name");
			    Assert.assertTrue(name.equalsIgnoreCase("TestGroup'8"), "name is not saved as expected");
				}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		
		/*
		 * Verify group name and details fields in add group dialog
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testInputFieldsInAddGroup(){
			
			try{
				SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup")));
				driver.switchTo().activeElement();
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Name must not be blank.");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), "s");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Name must be between 3 to 1000 characters.");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), "sampleg");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Details must not be blank.");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupDetails")), "d");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Details must be between 3 to 2000 characters.");
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_addGroup_Cancel")));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Verify group name and details fields in edit group page
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testInputFieldsInEditGroup(){
			
			try{
				Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup7");
			 	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")));
				if(!Groups.isElementPresent(driver, By.linkText("TestGroup7"))){
					Groups.add(driver, "TestGroup7", "Group added for testing purpose");
					Groups.searchByText(driver,By.id(configObj.getPropertyValue("tbx_groups_searchBy_groupname")), "TestGroup7");
				}
				SeleniumUtil.waitForElement(driver, By.linkText("TestGroup7"));
				SeleniumUtil.click(driver, By.linkText("TestGroup7"));
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), "");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Name must not be blank.");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), "T");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Name must be between 3 to 1000 characters.");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupName")), "TestGroup7");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupDetails")), "");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Details must not be blank.");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_groupDetails")), "d");
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_editGroup_Save")));
				Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Details must be between 3 to 2000 characters.");
				SeleniumUtil.click(driver, SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_editGroup_Cancel"))));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		
		
		/*
		 * Verifying bottom refresh button
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testRefreshBottom()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_groups", By.id(configObj.getPropertyValue("tbx_groups_searchBy_description"))),"Refresh is not working");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Verifying page info bottom
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testPageInfoBottom()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_groups"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 *Navigation to pages at bottom
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testNavigationOfPagesBottom()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		/*
		 *Test size of page at bottom
		 */
		
		@Test(enabled=true, timeOut=300000)
		public void testNoOfRecordsToBeDisplayedBottom()
		{
			
			try{
			Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@AfterTest
		public void tearDown(){
			
			try{
			System.out.println("tear down method called!!");
			driver.close();
			driver.quit();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
}
