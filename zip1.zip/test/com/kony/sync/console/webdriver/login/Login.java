package com.kony.sync.console.webdriver.login;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Login extends BaseTestcase{
	private static String alertText;
	
	/**
	 * Login to the application using given username and password
	 * @param username
	 * @param password
	 */
	
	public static void login(WebDriver driver, String username, String password){
		
		try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_userID")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_userID")), username);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_password")), password);
		
		SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("btn_login")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while login to the application with given credentials.");
			e.printStackTrace();
		}
		
	}
	
	 /**
	   * Logout from the application.
	   */
	
	  public static void logout(WebDriver driver){
		  
		  try{
			  SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_logout")));
		  }catch(Exception e){
			  Reporter.log("ERROR: Logout failed.");
			  e.printStackTrace();
		  }
		  
	  }
	
	
	/**
	 * returns title of the web page 
	 * @return title
	 */
	  
	public static String getTitle(WebDriver driver){
		
		String title = driver.getTitle();
		return title;
		
	}
	
	/**
	  * close the alert and return the text present on the alert box
	  * @return text
	  */
	
	  public static String closeAlertAndGetItsText(WebDriver driver, boolean acceptAlert) {
		  
		  	alertText=null;
		    try {
		      Alert alert = driver.switchTo().alert();
		       alertText = alert.getText();
		      if (acceptAlert) {
		        alert.accept();
		      } else {
		        alert.dismiss();
		      }
		      return alertText;
		    }finally{
		    	acceptAlert=false;
		    }
		    
		  }

}
