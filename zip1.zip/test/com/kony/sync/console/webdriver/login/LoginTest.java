
package com.kony.sync.console.webdriver.login;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.users.Users;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class LoginTest extends BaseTestcase {
	
	@BeforeTest	
	public void loadDriver() {
		
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){
		
		try{
		System.out.println("set up method called!!");
		driver.get(configObj.getPropertyValue("baseUrl"));
		driver.manage().window().maximize();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * Sync-220:Login without User ID and Password
	 */

	@Test(enabled=true, timeOut=300000)
	public void testEmptyLogin(){

		try{
		Login.login(driver, "", "");
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter the User ID", "Either empty login is accepted or pop up message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-220:Login with blank user name and given password
	 * 
	 */

	@Test(enabled=true, timeOut=300000)
	public void testLoginWithEmptyUsername(){
		
		try{
		Login.login(driver, "", "SyncAdmin123");
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter the User ID", "Either empty username is accepted or pop up message is not as expected.");
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		
	}

	/*
	 * Sync-220:Login with given user name and blank password
	 * 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithEmptyPassword(){
		
		try{
		Login.login(driver, configObj.getPropertyValue("username"), "");
		Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver), "Please enter the Password", "Either empty password is accepted or pop up message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-28:Login with Invalid User name and password
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithInValidCredentials(){
		
		try{
		Login.login(driver, "test", "test");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_loginError"))).toString(),"Your login attempt was not successful, try again."+"\nReason : Bad credentials", "Either invalid username/password is accepted or error message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/*
	 * Sync-28:Login with Invalid User name and correct password
	 */

	@Test(enabled=true, timeOut=300000)
	public void testLoginWithInValidUsername(){
		
		try{
		Login.login(driver, "test", configObj.getPropertyValue("password"));
		SeleniumUtil.waitForElement(driver, By.linkText("Login"));
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_loginError"))).toString(),"Your login attempt was not successful, try again."+"\nReason : Bad credentials" , "Either invalid username is accepted or error message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-28:Login with valid User name and invalid password
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithInValidPassword(){

		try{
		Login.login(driver, configObj.getPropertyValue("username"), "test");
		SeleniumUtil.waitForElement(driver, By.linkText("Login"));
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_loginError"))).toString(),"Your login attempt was not successful, try again."+"\nReason : Bad credentials", "Either invalid password is accepted or error message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * 
	 * Sync-218:Login with User who is not assigned to any group
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginUserWithNoRole(){

		try{
		Login.login(driver, "consoleuser", "consoleuser123");
		Assert.assertEquals(Login.getTitle(driver), "Kony Sync Management Console - Access Denied" , "For user with no role either access denied page is not shown or page title is not as expected.");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_accessDenied"))).toString(), "You do not have permission to view this page." , "For user with no role error message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-219:Login with inactive/disable user
	 * 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithInactiveUser(){

		try{
		Login.login(driver, "inactiveuser", "inactiveuser123");
		SeleniumUtil.waitForElement(driver, By.linkText("Login"));
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_loginError"))).toString(),"Your login attempt was not successful, try again."+"\nReason : User is disabled", "Either Inactive user is able to login or error message is not as expected.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-4:General Login with Admin Role
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithValidCredentials(){

		try{
		Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		SeleniumUtil.waitForElement(driver, By.linkText("Logout"));
		Assert.assertEquals(Login.getTitle(driver),"Analytics Dashboard" , "Login as Admin is failed or page title is not as expected."); 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-221:Login with Report Viewer Role
	 * DEF489 : Report Viewers should only be allowed to view the information related to the apps which are assigned to him
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithUserAsReportViewerDEF489(){

		try{
		Login.login(driver, "reportviewer", "reportviewer123");
		SeleniumUtil.waitForElement(driver, By.linkText("Logout"));
		Assert.assertEquals(Login.getTitle(driver),"Analytics Dashboard" , "Login as ReportViewer is failed or page title is not as expected.");

		List<WebElement> elements = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("lbl_leftNavigations_Headings")));
		Assert.assertTrue(elements.size() == 2, "The no. of operations given to Report Viewer is not as expected");
		Assert.assertEquals(elements.get(0).getText(),"Analytics Dashboard", "Analytics Dashboard is not available for report viewer");
		Assert.assertEquals(elements.get(1).getText(),"Monitoring", "Monitoring is not available for report viewer");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-Sync-222:Login with User Role
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLoginWithRoleUser(){

		try{
		Login.login(driver, "roleuser", "roleuser123");
		Assert.assertEquals(Login.getTitle(driver), "Kony Sync Management Console - Access Denied" , "Login with role user is failed or page title is not as expected.");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_accessDenied"))).toString(), "You do not have permission to view this page." , "Error message is not as expected for login with user role.");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Logout from console
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLogout(){

		try{
		Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		if(SeleniumUtil.waitForText(driver, By.linkText("Logout"), "Logout"))
		{
			SeleniumUtil.click(driver, By.linkText("Logout"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.linkText(configObj.getPropertyValue("btn_login")), "Login"), "Log out is not successful");
		}
		else{
			Assert.fail("LogOut is not available");	
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Check Edit profile link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditProfileLink(){

		try{
		Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		SeleniumUtil.delay(2000);
		Users.navigateToUsersHomePage(driver);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		SeleniumUtil.delay(1000);
		Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "SampleUser56");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
		SeleniumUtil.click(driver, By.linkText("SampleUser56"));
		Users.assignGroup(driver, "SampleUser56", "Administrator");
		SeleniumUtil.delay(2000);
		Login.logout(driver);
		SeleniumUtil.delay(3000);
		Login.login(driver, "SampleUser56", "sampleuser123");
		SeleniumUtil.delay(1000);
		if(SeleniumUtil.waitForText(driver, By.linkText("Edit Profile"), "Edit Profile"))
		{
			SeleniumUtil.click(driver, By.linkText("Edit Profile"));
			driver.switchTo().activeElement();
			SeleniumUtil.delay(1000);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("win_editProfile")),"Edit Profile"),"Edit profile window/layout is not opened");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_editProfile_userId")), "SampleUser56"), "User Id is not displayed");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbox_editProfileUserName")));
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbox_editProfileEmail")));
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
			SeleniumUtil.delay(1000);
			Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("User Name must not be blank."),"Error message is not obtained while saving with out entering user id");

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbox_editProfileUserName")), "e");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
			SeleniumUtil.delay(2000);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_editProfile_Status")), "User edited successfully."), "profile is not updated successfully");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbox_editProfileEmail")), "testing");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
			SeleniumUtil.delay(1000);
			Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please enter valid email ID."),"Error message is not obtained while entering invalid email id");
			SeleniumUtil.delay(1000);
			
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbox_editProfileEmail")), "testing@kony.com");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
			SeleniumUtil.delay(1000);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_editProfile_Status")), "User edited successfully."), "profile is not updated successfully");
			SeleniumUtil.delay(1000);
			
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cancel_editProfile")));
			Assert.assertFalse(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("win_editProfile"))),"Cancel button is not working");
			SeleniumUtil.click(driver, By.linkText("Edit Profile"));
			driver.switchTo().activeElement();
			SeleniumUtil.delay(2000);
			
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbox_editProfileEmail")), "");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_save_editProfile")));
			SeleniumUtil.delay(6000);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_editProfile_Status")), "User edited successfully."), "profile is not updated successfully");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			SeleniumUtil.delay(1000);
			Assert.assertFalse(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("win_editProfile"))),"Pop up cross button is not working");
		}
		else{
			Assert.fail("Edit Profile is not available");	
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Check Edit profile link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testChangePassword(){
		
		try{
		Login.login(driver, "editprofileuser", "editprofileuser123");
		SeleniumUtil.delay(2000);
		if(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("tbx_userID"))))
		{
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
			SeleniumUtil.delay(2000);
			Users.navigateToUsersHomePage(driver);
			SeleniumUtil.delay(2000);
			Users.search(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")), "editprofileuser");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_searchByUserID")));
			if(Users.isElementPresent(driver, By.linkText("editprofileuser"))){

				Users.delete(driver, "editprofileuser");
			}

			Users.add(driver, "editprofileuser", "editprofileuser123", "editprofileuser", "sync@kony.com", "1234567890", "kony");
			SeleniumUtil.click(driver, By.linkText("editprofileuser"));
			Users.assignGroup(driver, "editprofileuser", "Administrator");
			SeleniumUtil.delay(2000);
			Login.logout(driver);
			SeleniumUtil.delay(3000);
			Login.login(driver, "editprofileuser", "editprofileuser123");
		}
		SeleniumUtil.delay(2000);
		if(SeleniumUtil.waitForText(driver, By.linkText("Edit Profile"), "Edit Profile"))
		{
			SeleniumUtil.clickAndWait(driver, By.linkText("Edit Profile"),4000);
			SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_editProfile")),2000);
			SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("win_changePassword")));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("win_changePassword")),"Change Password"),"Change Password window/layout is not opened");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_changePassword_userId")), "editprofileuser"), "User Id is not displayed");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")), "Change Password"), "Change password button is not available");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_cancel")), "Cancel"), "Cancel button is not available");
			SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")),2000);
			Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Password must not be blank."), "Proper message is not displayed while giving blank password");

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_oldPwd")), "e");
			SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")),2000);
			Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Password must not be blank."), "Password must not be blank.");
		}
		else{
			Assert.fail("Edit Profile is not available");	
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Test(enabled=true, timeOut=300000)
	public void testNewAndConfirmPassword(){

		Login.login(driver, "editprofileuser", "editprofileuser123");
		try{
			if(SeleniumUtil.waitForText(driver, By.linkText("Edit Profile"), "Edit Profile"))
			{
				SeleniumUtil.click(driver, By.linkText("Edit Profile"));
				SeleniumUtil.delay(2000);
				driver.switchTo().activeElement();
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_editProfile")));
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_oldPwd")), "editprofileuser123");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_newPwd")), "pwd");
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")));
				Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Password should match with Confirm Password"), "Proper message is not displayed while giving blank confirm password");

				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_newPwd")), "");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_confPwd")), "edit");
				
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")));
				Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Password must not be blank."), "Proper message is not displayed while giving blank new password");

				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_newPwd")), "pwd");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_confPwd")), "pwds");
				
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")));
				Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Password should match with Confirm Password"), "Proper message is not displayed while giving wrong confirm password");

				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_confPwd")), "pwd");
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_changePassword_Status")), "Password changed successfully."),"Password is not changed successfully");

				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_oldPwd")), "pwd");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_newPwd")), "editprofileuser123");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changePassword_confPwd")), "editprofileuser123");
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_changePassword")));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_changePassword_Status")), "Password changed successfully."),"Password is not changed successfully");

				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changePassword_cancel")));
				Assert.assertFalse(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("win_changePassword"))),"Cancel button is not working");
			}
			else{
				Assert.fail("Edit Profile is not available");	
			}
		}
		catch(Exception e){
			e.printStackTrace();	
		}
		
	}	

	/*
	 * verify page title
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle(){
		
		try{
		Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_login")), "page title is not appropriate");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * DEF492:verify place holders
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPlaceHoldersDEF492(){
		
		try{
		Assert.assertTrue(SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("tbx_userID"))).getAttribute("placeholder").equalsIgnoreCase("User ID"), "Place holder value is not User ID for user Id field");
		Assert.assertTrue(SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("tbx_password"))).getAttribute("placeholder").equalsIgnoreCase("Password"), "Place holder value is not Password for password field");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying version at footer of the page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testVersionAtFooter()
	{
		try{
		Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("footer_version"))).contains("VERSION: Sync"), "Sync Version is not displayed");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return null;
		
	}

	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return null;
		
	}

	@AfterTest
	public void tearDown(){

		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
