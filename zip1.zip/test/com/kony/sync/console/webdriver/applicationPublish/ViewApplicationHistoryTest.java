package com.kony.sync.console.webdriver.applicationPublish;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumConfigProperties;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class ViewApplicationHistoryTest extends BaseTestcase{

/*
 * Adds required data for verifying application history window	
 */
	
@BeforeTest
public void addDataForApplicationHistory()
{
	
	try {
	super.setUp();
	SeleniumUtil.delay(5000);
	driver.get(configObj.getPropertyValue("baseUrl"));
	SeleniumUtil.delay(2000);
	driver.manage().window().maximize();
	Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
	SeleniumUtil.delay(2000);
	Applications.navigateToApplicationsPage(driver);
	SeleniumUtil.delay(2000);
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
	SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	SeleniumUtil.delay(2000);
	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
	if(Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.delete(driver, "OTA");
	}
	Assert.assertEquals(Applications.add(driver,"OTASampleSyncConfig.xml"), "Sync Configuration uploaded successfully.","Either application configuration is not uploaded successfully or the displayed message is not as expected.");
	
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
	SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	SeleniumUtil.delay(2000);
	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
	if(!Applications.isElementPresent(driver, By.linkText("OTA"))){
		Applications.add(driver, "OTASampleSyncConfig"+".xml");
	}
	for(int i=0;i<=6;i++)
	{
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTASampleSyncConfig"+".xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTAModified"+".xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
	}
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
	SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	SeleniumUtil.delay(2000);
	SeleniumUtil.click(driver, By.linkText("View History"));
	SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("layout_historyModelWin_header")), "Application History for OTA");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

@BeforeMethod
public void setUp() {
	
	try{
	if(!SeleniumUtil.isElementDisplayed(driver, By.xpath(configObj.getPropertyValue("win_viewAppHistory"))))
	{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("View History"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("layout_historyModelWin_header")), "Application History for OTA");
		SeleniumUtil.delay(2000);
	}
	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
	SeleniumUtil.delay(2000);
	SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	
}

/*
 * Searching based on application version- with a valid search text
 * DEF629-search is not working in the window View History
 */

@Test(enabled=true, timeOut=300000)
public void testValidSearchByAppVersionDEF629(){
	
	try{
	ViewApplicationHistory.searchByAppVersion(driver, "1");
	Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_viewAppHistory"), "1", configObj.getPropertyValue("txt_viewAppHistory_appVersionInEachRow")),"App version search is not working");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Searching based on application version- with a invalid search text
 */

@Test(enabled=true, timeOut=300000)
public void testInValidSearchByAppVersion(){
	
	try{
	ViewApplicationHistory.searchByAppVersion(driver, "abcxyz");
	Assert.assertTrue(ViewApplicationHistory.getRowCount(driver) == 0,"Invalid app version search is not working");
	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
	Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_viewAppHistory_searchBy_appVersion"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying page info
 */

@Test(enabled=true, timeOut=300000)
public void testPageInfo()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_viewAppHistory"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 *   Verify View Configuration link 
 */

@Test(enabled=true, timeOut=300000)
public void testViewConfigurationLink(){
	
	try{
	if(SeleniumUtil.isElementPresent(driver, By.linkText("View Configuration"))){
		String parentWindow= driver.getWindowHandle();
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_ViewAppHistory_viewConfiguration")));
		SeleniumUtil.delay(1000);
		Set<String> handles=driver.getWindowHandles();
		Assert.assertTrue(handles.size() == 2,"View configuration link is not working");
		 for(String windowHandle : handles)
	       {
	       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
	          {
	    	   driver.switchTo().window(windowHandle);
	    	   Assert.assertTrue(driver.getPageSource().contains("AppID=\"OTA\""),"config details are not shown");
	    	   driver.close();
	    	   break;
	          }
	       }
	         driver.switchTo().window(parentWindow);
	}else{
		Assert.fail("View configuration link is not found.");
	}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verify Device Schema changes link
 */

@Test(enabled=true, timeOut=300000)
public void testDeviceSchemaChangesLink(){
	
	try{
		if(SeleniumUtil.isElementPresent(driver, By.linkText("View Device Schema Changes"))){
			SeleniumUtil.click(driver, By.linkText("View Device Schema Changes"));
			driver.switchTo().activeElement();
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_deviceSchemaChange"))).isEmpty(),"View device schema changes link doesn't contain information about changes");
		}else{
			Assert.fail("View Device Schema Changes link not found");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally{
		if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close"))))
		{
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close")));
		}
	}
	
}

/*
 * Verifying refresh
 */

@Test(enabled=true, timeOut=300000)
public void testRefresh()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyRefresh(driver, "grid_viewAppHistory", By.id(configObj.getPropertyValue("tbx_viewAppHistory_searchBy_appVersion"))),"Refresh is not working");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying calendar
 */

@Test(enabled=true, timeOut=300000)
public void testCalendar()
{
	
	try{
	SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_ViewAppHistory_searchBy_updateTime")),1000);
	SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
	Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying calendar for last update time
 */

@Test(enabled=true, timeOut=300000)
public void testCalendarForLastUpdateTime()
{
	
	try{
	Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_ViewAppHistory_searchBy_updateTime", "grid_viewAppHistory", "start")," Time search through calendar is not working");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying valid time search for Last Update time field
 */

@Test(enabled=true, timeOut=300000)
public void testValidSearchLastUpdatedTime(){
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyInsertedOnSearch(driver,"03/23/2012 20:27:45 +0530"),"Valid search for inserted on is not working.");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying invalid time search for Last Update time field
 */

@Test(enabled=true, timeOut=300000)
public void testInValidSearchInsertedOn(){
	
	try{
	Assert.assertFalse(ViewApplicationHistory.verifyInsertedOnSearch(driver,"03/23/2030 20:27:45 +0530"),"Invalid search for inserted on is not working.");
	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
	Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_ViewAppHistory_searchBy_updateTime"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifies deletion of versions in application history window
 */

@Test(enabled=true, timeOut=300000)
public void testDeleteVersion(){
	
	try{
	ViewApplicationHistory.searchByAppVersion(driver, "13");
	SeleniumUtil.delay(2000);
	SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_delete_appHistory")));
	SeleniumUtil.delay(1000);
	Assert.assertEquals(SeleniumUtil.closeAlertBoxAndGetItsText(driver),"Please select at least one Application history to delete.");
	SeleniumUtil.delay(1000);
	SeleniumUtil.click(driver, By.xpath("//table[@id='applicationgrid1']//tr[2]/td[1]/input"));
	SeleniumUtil.delay(1000);
	SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_delete_appHistory")));
	SeleniumUtil.delay(1000);
	Assert.assertEquals(ViewApplicationHistory.closeConfirmationBoxAndGetItsText(driver, true),"Are you sure you want to delete selected Application history?");
	SeleniumUtil.delay(2000);
	SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_viewAppHistory_statusMsg")), "Application History(s) deleted successfully.");
    Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("txt_viewAppHistory_statusMsg"))), "Application History(s) deleted successfully.");
	ViewApplicationHistory.searchByAppVersion(driver, "13");
	SeleniumUtil.delay(2000);
	Assert.assertTrue(ViewApplicationHistory.getRowCount(driver) == 0,"Application version is not deleted");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verify alternative clicks for last update time field
 */

@Test(enabled=true, timeOut=300000)
public void verifyAlternativeClicksForLastUpdateTime()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyAlternativeClicksForTimeField(driver, "tbx_ViewAppHistory_searchBy_updateTime"), "Calendar is not visible on alternate clicks");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying Collapse button to minimize and expand the table
 
@Test(enabled=true, timeOut=300000)
public void testCollapseOfTable()
{
	Assert.assertTrue(ViewApplicationHistory.verifyCollapseOfTable(driver),"Collapse of the table is not working");
}*/

/*
 *Navigation to pages 
 */

@Test(enabled=true, timeOut=300000)
public void testNavigationOfPages()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * verify sorting of data - checks whether data is changing on the click of column name
 */

@Test(enabled=true, timeOut=300000)
public void testSortingOfData()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifySortingOfData(driver,3),"Data is not sorted on the click of column name");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 *test size of page
 */

@Test(enabled=true, timeOut=300000)
public void testNoOfRecordsToBeDisplayed()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

@Override
protected String getPageId() {
	return null;
}

/*
 * verify affect of event on calendar field on other fields of the page
 */

@Override
protected String getSearchId() {
	return null;
}


/*
 * Verifying refresh
 */

@Test(enabled=true, timeOut=300000)
public void testRefreshtop()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyRefreshTop(driver, "grid_viewAppHistory", By.id(configObj.getPropertyValue("tbx_viewAppHistory_searchBy_appVersion"))),"Refresh is not working");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 * Verifying page info
 */

@Test(enabled=true, timeOut=300000)
public void testPageInfoTop()
{
	
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyPagingInfoTop(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_viewAppHistory"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 *Navigation to pages 
 */

@Test(enabled=true, timeOut=300000)
public void testNavigationOfPagesTop()
{
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyNavigationOfPagesTop(driver),"Navigation of pages is not working as expected");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

/*
 *test size of page
 */

@Test(enabled=true, timeOut=300000)
public void testNoOfRecordsToBeDisplayedTop()
{
	try{
	Assert.assertTrue(ViewApplicationHistory.verifyNoOfRecordsToBeDisplayedTop(driver),"No. of records to be diplayed in a page is not working as expected");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

@AfterTest
public void tearDown(){
	
	try{
	System.out.println("tear down method called!!");
	driver.close();
	driver.quit();
} catch (Exception e) {
	e.printStackTrace();
}
}

}
