
package com.kony.sync.console.webdriver.applicationPublish;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.groups.Groups;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumConfigProperties;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;


/**
 * This file contains the test scripts of 'application publish' and 'sync config validations' test cases. 
 * @author KH1456
 *
 */

public class ApplicationPublishTest extends BaseTestcase{
	
	List<WebElement> options=null;
	byte[] buffer = new byte[1024];
	String zipFilePath;
	String destDirectory;
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			Applications.navigateToApplicationsPage(driver);
			Applications.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * APPLICATION PUBLISH TEST SCRIPTS
	 */
	
	/*
	 * Sync-336:Uploading of OTA sync config file
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidateConfigFile(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.delete(driver, "OTA");
		}
		ApplicationPublish.chooseFile(driver, "OTASampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "No SyncScope found with PersistentSync strategy to generate scripts");
		//Should throw an appropriate error message as the uploaded config file is not of Persistent.
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "No SyncScope found with PersistentSync strategy to generate scripts");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Test duplicate file upload
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDuplicateFileUpload(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		ApplicationPublish.chooseFile(driver, "OTASampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application with Application ID [OTA] already exists.");
		//Should throw an appropriate error message as the application is already exist.
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "Application with Application ID [OTA] already exists.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Test DriverClassField prepopulated text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDriverClassFieldPrepopulatedText(){
		
		try{
		String db=configObj.getPropertyValue("database");
		if(db.equalsIgnoreCase("MSSQL"))
		{
			testDriverClassFieldPrepopulatedTextMSSQL();
		}
		if(db.equalsIgnoreCase("MYSQL"))
		{
			testDriverClassFieldPrepopulatedTextForMySQl();
		}
		if(db.equalsIgnoreCase("ORACLE"))
		{
			testDriverClassFieldPrepopulatedTextForOracle();
		}
		if(db.equalsIgnoreCase("POSTGRE"))
		{
			testDriverClassFieldPrepopulatedTextForPostGre();
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	

	private void testDriverClassFieldPrepopulatedTextMSSQL() throws Exception{
		
		  try{
		   SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		   SeleniumUtil.delay(2000);
		   SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		   if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
		    Applications.delete(driver, "Persistent");
		   }
		   SeleniumUtil.delay(2000);
		   SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		   ApplicationPublish.chooseFile(driver, "PersistentSampleSyncConfig.xml");
		   SeleniumUtil.delay(2000);
		   ApplicationPublish.generatePersistentDBScripts(driver);
		   SeleniumUtil.delay(2000);
		   ApplicationPublish.upload(driver);
		   SeleniumUtil.delay(2000);
		   driver.switchTo().activeElement();
		   SeleniumUtil.delay(6000);
		   SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass")), "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		   // Verifying the driver class field is populating with the text from config file.
		   Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass"))), "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		   }
		   finally{
		    if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
		    {
		     SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
		     if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
		    }
		   }
		  
		 }
	
	private void testDriverClassFieldPrepopulatedTextForMySQl(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PRV"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRV"))){
			Applications.delete(driver, "PRV");
		}
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "PRV55ExpFlt.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass")), "com.mysql.jdbc.Driver");
		// Verifying the driver class field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass"))), "com.mysql.jdbc.Driver");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	private void testDriverClassFieldPrepopulatedTextForOracle(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PRVORACLE"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRVORACLE"))){
			Applications.delete(driver, "PRVORACLE");
		}
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "prov.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass")), "com.kony.sync.services.datasource.jdbc.JDBCDatasource");
		// Verifying the driver class field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass"))), "com.kony.sync.services.datasource.jdbc.JDBCDatasource");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	private void testDriverClassFieldPrepopulatedTextForPostGre(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "AppSample"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("AppSample"))){
			Applications.delete(driver, "AppSample");
		}
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "PRVPOSTGRE.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass")), "com.kony.sync.services.datasource.jdbc.JDBCDatasource");
		// Verifying the driver class field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass"))), "com.kony.sync.services.datasource.jdbc.JDBCDatasource");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	
	/*
	 * Test DatabaseUrlField Prepopulated text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDatabaseUrlFieldPrepopulatedText(){
		
		try{
		String db=configObj.getPropertyValue("database");
		if(db.equalsIgnoreCase("MSSQL"))
		{
			testDatabaseUrlFieldPrepopulatedTextMSSQL();
		}
		if(db.equalsIgnoreCase("MYSQL"))
		{
			testDatabaseUrlFieldPrepopulatedTextMySQL();
		}
		if(db.equalsIgnoreCase("ORACLE"))
		{
			testDatabaseUrlFieldPrepopulatedTextOracle();
		}
		if(db.equalsIgnoreCase("POSTGRE"))
		{
			testDatabaseUrlFieldPrepopulatedTextPostGre();
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	private void testDatabaseUrlFieldPrepopulatedTextMSSQL() throws Exception{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			Applications.delete(driver, "Persistent");
		}
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "PersistentSampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.delay(4000);
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url")), "jdbc:sqlserver://localhost:1433;databaseName=KonySyncSample;user=sa;password=kony123!");
		// Verifying the database URL field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url"))), "jdbc:sqlserver://localhost:1433;databaseName=KonySyncSample;user=sa;password=kony123!");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	

	private void testDatabaseUrlFieldPrepopulatedTextMySQL(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PRV"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRV"))){
			Applications.delete(driver, "PRV");
		}
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "PRV55ExpFlt.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url")), "jdbc:mysql://localhost:3306/KonySyncSample?user=root&password=kony123!");
		// Verifying the database URL field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url"))), "jdbc:mysql://localhost:3306/KonySyncSample?user=root&password=kony123!");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	
	private void testDatabaseUrlFieldPrepopulatedTextOracle(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PRVORACLE"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRVORACLE"))){
			Applications.delete(driver, "PRVORACLE");
		}
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "prov.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url")), "jdbc:oracle:thin:syncsample/kony123@localhost:1521:xe");
		// Verifying the database URL field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url"))), "jdbc:oracle:thin:syncsample/kony123@localhost:1521:xe");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
			
		}
		
	}
	
	private void testDatabaseUrlFieldPrepopulatedTextPostGre(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "AppSample"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("AppSample"))){
			Applications.delete(driver, "AppSample");
		}
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		ApplicationPublish.chooseFile(driver, "PRVPOSTGRE.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url")), "jdbc:postgresql://localhost:5432/KonySyncSample?user=postgres&amp;password=kony123!");
		// Verifying the database URL field is populating with the text from config file.
		Assert.assertEquals(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DB_Url"))), "jdbc:postgresql://localhost:5432/KonySyncSample?user=postgres&amp;password=kony123!");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	
	 /*
	  *  Sync-342.a:Downloading of DDL scripts
	  */
	
	@Test(enabled=true, timeOut=300000)
	public void testDownloadFileForOTA(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_download")));
		ApplicationPublish.select(driver, "OTA");
		SeleniumUtil.delay(2000);
		
        driver.manage().window().maximize();
		ApplicationPublish.download(driver);
		SeleniumUtil.delay(8000);
		
		zipFilePath = configObj.getPropertyValue("downloads_path")+"\\OTA_SyncTool.zip";
		destDirectory = configObj.getPropertyValue("downloads_path")+"\\OTA_SyncTool"; 
		unzip(zipFilePath, destDirectory);
		
		File jsFiles = new File(configObj.getPropertyValue("downloads_path")+"\\OTA_SyncTool\\client\\js");
		for(String fname : jsFiles.list())
		{
			if(!fname.contains(".js"))
			{
				Assert.fail("Client JS files are not successfully downloaded");
			}
		}
		
		File serverDDLFiles = new File(configObj.getPropertyValue("downloads_path")+"\\OTA_SyncTool\\server");
		
		Assert.assertFalse(serverDDLFiles.exists(), "Server DDL files are downloaded even for OTA");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			File f1 = new File(zipFilePath);
			if(f1.exists()){
				f1.delete();
			}
			File f2 = new File(destDirectory);
			if(f2.exists()){
				f2.delete();
			}
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testDownloadFileForPersistent(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			addPersistentApplicationWithDbScripts();
		}
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_download")));
		ApplicationPublish.select(driver, "Persistent");
		SeleniumUtil.delay(2000);
		
        driver.manage().window().maximize();
		ApplicationPublish.download(driver);
		SeleniumUtil.delay(8000);
		
		zipFilePath = configObj.getPropertyValue("downloads_path")+"\\Persistent_SyncTool.zip";
		destDirectory = configObj.getPropertyValue("downloads_path")+"\\Persistent_SyncTool"; 
		unzip(zipFilePath, destDirectory);
		
		File jsFiles = new File(configObj.getPropertyValue("downloads_path")+"\\Persistent_SyncTool\\client\\js");
		for(String fname : jsFiles.list())
		{
			if(!fname.contains(".js"))
			{
				Assert.fail("Client JS files are not successfully downloaded");
			}
		}
		
		File serverDDLFiles = new File(configObj.getPropertyValue("downloads_path")+"\\Persistent_SyncTool\\server\\ddl");
		
		for(String fname : serverDDLFiles.list())
		{
			if(!fname.contains(".sql"))
			{
				Assert.fail("Server ddl files are not successfully downloaded");
			}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			File f1 = new File(zipFilePath);
			if(f1.exists()){
				f1.delete();
			}
			File f2 = new File(destDirectory);
			if(f2.exists()){
				f2.delete();
			}
		}
		
	}
	
/*	 
	 * Sync-338:Schema creation
	 * Sync-339:Publishing of Schema
	 
	@Test(enabled=true, timeOut=300000)
	public void testPublishSchema() throws Exception{
		String db=configObj.getPropertyValue("database");
		if(db.equalsIgnoreCase("MSSQL"))
		{
			testPublishSchemaMSSQL();
		}
		if(db.equalsIgnoreCase("MYSQL"))
		{
			testPublishSchemaForMySQL();
		}
		if(db.equalsIgnoreCase("ORACLE"))
		{
			testPublishSchemaForOracle();
		}
		if(db.equalsIgnoreCase("POSTGRE"))
		{
			testPublishSchemaForPostGre();
		}
		
	}
	*/
	
	/*private void testPublishSchemaMSSQL() throws Exception{
		try{
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).sendKeys("Persistent"+Keys.RETURN);
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).clear();
		if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			Applications.delete(driver, "Persistent");
		}
		ApplicationPublish.chooseFile(driver, "PersistentSampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Thread.sleep(5000L);
		Thread.sleep(2000L);
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		//Thread.sleep(2000L);
		Thread.sleep(1000L);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
		//Thread.sleep(2000L);
		Thread.sleep(1000L);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		//Thread.sleep(5000L);
		Thread.sleep(2000L);
		//Execute DDL scripts for Upload schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
		//Thread.sleep(5000L);
		Thread.sleep(2000L);
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
		
		//Click on the Done button.
		//Thread.sleep(1000L);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
		
		// Verify the application created successfully.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).sendKeys("Persistent"+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath("//div[contains(@class,'loading')]"));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent")),"application is not created successfully");
		
		SeleniumUtil.waitForElement(driver, By.linkText("Persistent"));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			//cannot avoid as we must wait for some time for the status to update
			SeleniumUtil.delay(30000);
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			
				String mergeStatus=ApplicationPublish.getScheduledJobsStatus(driver, "MergeService", "Persistent");
				String replicaStatus=ApplicationPublish.getScheduledJobsStatus(driver, "ReplicaService", "Persistent");
				
			int flag=0; 
			if(mergeStatus.equalsIgnoreCase("COMPLETED"))
			{
				if(replicaStatus.equalsIgnoreCase("COMPLETED"))
				{
					flag = 1;
				}
				else{
					SeleniumUtil.delay(15000);
					driver.navigate().refresh();
					SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
					if(replicaStatus.equalsIgnoreCase("COMPLETED"))
					{
						flag = 1;
					}
				}
			}
			else if (replicaStatus.equalsIgnoreCase("COMPLETED")) {
				if(mergeStatus.equalsIgnoreCase("COMPLETED"))
				{
					flag = 1;
				}
				else{
					SeleniumUtil.delay(15000);
					driver.navigate().refresh();
					SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
					if(mergeStatus.equalsIgnoreCase("COMPLETED"))
					{
						flag = 1;
					}
				}
			}
			else{
				SeleniumUtil.delay(25000);
				SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
				if(replicaStatus.equalsIgnoreCase("COMPLETED"))
				{
					flag = 2;
				}
				if(mergeStatus.equalsIgnoreCase("COMPLETED"))
				{
					flag = flag+1;
				}
			}
			
			
			SeleniumUtil.delay(30000);
			driver.navigate().refresh();
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
			SeleniumUtil.delay(10000);
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "MergeService", "Persistent"), "COMPLETED");
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "ReplicaService", "Persistent"), "COMPLETED");
			
			Assert.assertTrue(flag==1 || flag==3, "Status is not updated to completed");

		}else{
			Assert.fail();
		}
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
		}
	}
	

	private void testPublishSchemaForMySQL() throws Exception{
		try{
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).sendKeys("PRV"+Keys.RETURN);
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).clear();
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRV"))){
			Applications.delete(driver, "PRV");
		}
		ApplicationPublish.chooseFile(driver, "PRV55ExpFlt.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Thread.sleep(5000L);
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		//Thread.sleep(2000L);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "root");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
		//Thread.sleep(2000L);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		//Thread.sleep(5000L);
		
		//Execute DDL scripts for Upload schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "root");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
		//Thread.sleep(5000L);
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
		
		//Click on the Done button.
		//Thread.sleep(1000L);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
		
		// Verify the application created successfully.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("PRV")),"application is not created successfully");
		//Thread.sleep(30000L);
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRV"))){
			//cannot avoid as we must wait for some time for the status to update
			SeleniumUtil.delay(30000);
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.delay(30000);
			driver.navigate().refresh();
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
			SeleniumUtil.delay(10000);
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "MergeService", "PRV"), "COMPLETED");
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "ReplicaService", "PRV"), "COMPLETED");

		}else{
			Assert.fail();
		}
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
		}
	}
	
	 
	private void testPublishSchemaForOracle() throws Exception{
		try{
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).sendKeys("PRVORACLE"+Keys.RETURN);
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).clear();
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRVORACLE"))){
			Applications.delete(driver, "PRVORACLE");
		}
		ApplicationPublish.chooseFile(driver, "prov.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Thread.sleep(5000L);
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		//Thread.sleep(2000L);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "system");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
		//Thread.sleep(2000L);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		//Thread.sleep(5000L);
		
		//Execute DDL scripts for Upload schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "system");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
		//Thread.sleep(5000L);
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
		
		//Click on the Done button.
		//Thread.sleep(1000L);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
		
		// Verify the application created successfully.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("PRVORACLE")),"application is not created successfully");
		//Thread.sleep(30000L);
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRVORACLE"))){
			//cannot avoid as we must wait for some time for the status to update
			SeleniumUtil.delay(30000);
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.delay(30000);
			driver.navigate().refresh();
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
			SeleniumUtil.delay(10000);
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "MergeService", "PRVORACLE"), "COMPLETED");
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "ReplicaService", "PRVORACLE"), "COMPLETED");

		}else{
			Assert.fail();
		}
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
		}
	}
	
	private void testPublishSchemaForPostGre() throws Exception{
		try{
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).sendKeys("AppSample"+Keys.RETURN);
		driver.findElement(By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).clear();
		if(SeleniumUtil.isElementPresent(driver, By.linkText("AppSample"))){
			Applications.delete(driver, "AppSample");
		}
		ApplicationPublish.chooseFile(driver, "PRVPOSTGRE.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Thread.sleep(5000L);
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		//Thread.sleep(2000L);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "postgres");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
		//Thread.sleep(2000L);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		//Thread.sleep(5000L);
		
		//Execute DDL scripts for Upload schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "postgres");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
		//Thread.sleep(5000L);
		
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
		
		//Click on the Done button.
		//Thread.sleep(1000L);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
		
		// Verify the application created successfully.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("AppSample")),"application is not created successfully");
		//Thread.sleep(30000L);
		if(SeleniumUtil.isElementPresent(driver, By.linkText("AppSample"))){
			//cannot avoid as we must wait for some time for the status to update
			SeleniumUtil.delay(30000);
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_ScheduledJobs")));
			SeleniumUtil.delay(30000);
			driver.navigate().refresh();
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_schedulesJobsHeader")), "Scheduled Jobs");
			SeleniumUtil.delay(10000);
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "MergeService", "AppSample"), "COMPLETED");
			driver.navigate().refresh();
			Assert.assertEquals(ApplicationPublish.getScheduledJobsStatus(driver, "ReplicaService", "AppSample"), "COMPLETED");

		}else{
			Assert.fail();
		}
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
		}
	}
*/
	
	/*
	 * Sync-340:Publishing of Schema with Invalid Database details
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPublishSchemaUsingInvalidDBCredentials(){
		
		try{
		String db=configObj.getPropertyValue("database");
		if(db.equalsIgnoreCase("MSSQL"))
		{
			testPublishSchemaUsingInvalidDBCredentialsMSSQL();
		}
		if(db.equalsIgnoreCase("MYSQL"))
		{
			testPublishSchemaUsingInvalidDBCredentialsForMySQL();
		}
		if(db.equalsIgnoreCase("ORACLE"))
		{
			testPublishSchemaUsingInvalidDBCredentialsForOracle();
		}
		if(db.equalsIgnoreCase("POSTGRE"))
		{
			testPublishSchemaUsingInvalidDBCredentialsForPostGRE();
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	private void testPublishSchemaUsingInvalidDBCredentialsMSSQL(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			Applications.delete(driver, "Persistent");
		}
		ApplicationPublish.chooseFile(driver, "PersistentSampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		SeleniumUtil.waitForTextValue(driver, By.id(configObj.getPropertyValue("tbx_dbConfig_DriverClass")), "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		// Passing invalid password
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_dbConfig_dbExecuteStatus")), "Unable to execute DbScripts.");
		// Verify the upload and replica database scripts execution status
		Assert.assertEquals(ApplicationPublish.getDBExecuteStatus(driver), "Unable to execute DbScripts.");
		// Verify the 'Click Here' link is present to open and view the logs
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")),"click Here link is not present");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	
	private void testPublishSchemaUsingInvalidDBCredentialsForMySQL(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PRV"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRV"))){
			Applications.delete(driver, "PRV");
		}
		ApplicationPublish.chooseFile(driver, "PRV55ExpFlt.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "root");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		// Passing invalid password
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_dbConfig_dbExecuteStatus")), "Unable to execute DbScripts.");

		// Verify the upload and replica database scripts execution status
		Assert.assertEquals(ApplicationPublish.getDBExecuteStatus(driver), "Unable to execute DbScripts.");
		// Verify the 'Click Here' link is present to open and view the logs
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")),"click Here link is not present");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	

	private void testPublishSchemaUsingInvalidDBCredentialsForOracle(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PRVORACLE"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PRVORACLE"))){
			Applications.delete(driver, "PRVORACLE");
		}
		ApplicationPublish.chooseFile(driver, "prov.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "system");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		// Passing invalid password
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_dbConfig_dbExecuteStatus")), "Unable to execute DbScripts.");

		// Verify the upload and replica database scripts execution status
		Assert.assertEquals(ApplicationPublish.getDBExecuteStatus(driver), "Unable to execute DbScripts.");
		// Verify the 'Click Here' link is present to open and view the logs
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")),"click Here link is not present");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	
	
	private void testPublishSchemaUsingInvalidDBCredentialsForPostGRE(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "AppSample"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("AppSample"))){
			Applications.delete(driver, "AppSample");
		}
		ApplicationPublish.chooseFile(driver, "PRVPOSTGRE.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "postgres");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		// Passing invalid password
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_dbConfig_dbExecuteStatus")), "Unable to execute DbScripts.");

		// Verify the upload and replica database scripts execution status
		Assert.assertEquals(ApplicationPublish.getDBExecuteStatus(driver), "Unable to execute DbScripts.");
		// Verify the 'Click Here' link is present to open and view the logs
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Click here")),"click Here link is not present");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_generateDbScriptsExitConfirmYes")));
				}
			}
		}
		
	}
	

	/*
	 * SYNC CONFIG VALIDATION TEST SCRIPTS
	 * 
	 */
	
	/*
	 *   Sync-360:SyncScope Name Uniqueness
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSyncScopeNameUniqueness(){
		
		try{
		ApplicationPublish.chooseFile(driver, "Sync-360_SampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error :  [  SyncScope with Duplicate Name \"PersistentSyncScope\" Detected] ");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-361:SyncObject GlobalName Uniqueness
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSyncObjGlobalNameUniqueness(){
		
		try{
		ApplicationPublish.chooseFile(driver, "Sync-361_SampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error : [ SyncObject with Duplicate GlobalName \"Categories\" has been Detected] ");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-362:SyncAttribute GlobalName and SourceName Uniqueness across the SyncObject
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSyncAttributeGlobalNameUniqueness(){
		
		try{
		ApplicationPublish.chooseFile(driver, "Sync-362_SampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error :  [  SyncObject with SourceName Categories has duplicate SyncAttribute with GlobalName CategoryID,   SyncObject with SourceName Categories has duplicate SyncAttribute with SourceName CategoryID]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-363a:SyncObject GlobalNames should not start with konysync
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSyncObjNameMustNotStartWithKonySync() throws Exception{
		
		try{
		ApplicationPublish.chooseFile(driver, "Sync-363a_SampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error : [ NOT ALLOWED-konysyncCat starts with Reserved GlobalName prefix : konysync]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-363b:SyncAttribute GlobalNames should not start with konysync
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSyncAttributeNameMustNotStartWithKonySync(){
		
		try{
		ApplicationPublish.chooseFile(driver, "Sync-363b_SampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error :  [  NOT ALLOWED-Categories has SyncAttribute konysyncCat which starts with Reserved GlobalName prefix : konysync,   Invalid SourceObjectAttribute CategoryID defined for relationship in SyncObject Categories to Products]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-365:Relationships should be defined among SyncObjects within the same scope
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSyncObjRelationship(){
		
		try{
		ApplicationPublish.chooseFile(driver, "Sync-365_SampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error : [ Invalid relationship defined for SyncObject Categories to Products, Invalid relationship defined for SyncObject Suppliers to Products]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-366:If ProvisioningColumnsSupported are enabled at scope,then they should be defined for all the SyncObjects
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testProvisioningColumns(){
		
		try{
			ApplicationPublish.chooseFile(driver, "Sync-366_SampleSyncConfig.xml");
			ApplicationPublish.generatePersistentDBScripts(driver);
			ApplicationPublish.upload(driver);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
			appUploadErrorMessage("Validation Error : [ ChangeTrackingColumn 'LastUpdateTimeStamp' is not defined properly for SyncObject with GlobalName Categories, ChangeTrackingColumn 'SoftDeleteFlag' is not defined properly for SyncObject with GlobalName Categories]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-364:If a ConflictPolicy is given as custom then the corresponding conflictInterceptor should be defined
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCustomConflictPolicy(){
		
		try{
		ApplicationPublish.chooseFile(driver, "OTA_Error.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again."),"Appropriate error message is not obtained");
		appUploadErrorMessage("Validation Error : [ No conflictInterceptor is defined for scope ProcOTASync]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifies presence of error details when invalid config xml file is uploaded
	 */
	
	private void appUploadErrorMessage(String expectedErrMsg)
	{
		
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp")));
		if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp"))))
		{
		Assert.assertTrue(SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp"))).equalsIgnoreCase("Show Error Details"),"'Show error details' text is not shown on the button");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp")));
		}
		else{
		Assert.fail("'Show Error Details' button is not shown");	
		}
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status")));
		
		String errMsg = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status")));
		String commonErrMsg="Validation Rules :  [  The length limitations for AppID and GlobalNames of SynObject,SyncAttribute are as follows correspondingly   MSSQLSERVER-[112,120,114]ORACLE-[18,22,15]MYSQL-[52,56,50]POSTGRESQL-[51,55,49],   SyncScope Name should be unique across the application ,   SyncObject GlobalName should be unique across the application,   SyncAttribute GlobalName and SourceName should be unique across the SyncObject,   SyncObject or SyncAttribute GlobalNames should not start with konysync,   If a ConflictPolicy is given as custom then the corresponding conflictInterceptor should be defined,   Relationships should be defined among SyncObjects within the same scope,   If ProvisioningColumnsSupported are enabled at scope,then they should be defined for all the SyncObjects,  ]";
		
		Assert.assertTrue(errMsg.replaceAll("[\\n\\t ]", "").contains(expectedErrMsg.replaceAll("[\\n\\t ]", "")), "Validation error is not appropriate");
		Assert.assertTrue(errMsg.replaceAll("[\\n\\t ]", "").contains(commonErrMsg.replaceAll("[\\n\\t ]", "")), "Validation rules are not appropriate");
		
		Assert.assertTrue(SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp"))).equalsIgnoreCase("Hide Error Details"),"'Hide Error Details' text is not shown on the button after exception is shown");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status")));
		Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status"))), "Exception details are not hidden on click of 'Hide Error Details' button");
		
	}
	
	/*
	 * Sync-342.b:Downloading of DDL scripts
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDownloadApplicationDialogs(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "TESTOTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("TestOTA1"))){
			Applications.add(driver, "TestOTA1.xml");
		}
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("TestOTA2"))){
			Applications.add(driver, "TestOTA2.xml");
		}
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_download")));
		ApplicationPublish.download(driver);
		String alert=SeleniumUtil.closeAlertBoxAndGetItsText(driver);
		Assert.assertEquals(alert, "Please select atleast one Application to download scripts");
		ApplicationPublish.select(driver, "TestOTA1"); 
		ApplicationPublish.select(driver, "TestOTA2"); 	
		ApplicationPublish.download(driver);
		alert=SeleniumUtil.closeAlertBoxAndGetItsText(driver);
		Assert.assertEquals(alert, "Please select only one Application to download scripts");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	 /*
	  *  Sync-342.c:Downloading of DDL scripts after 'Add New Application' form is rendered on the page 
	  */
	
	@Test(enabled=true, timeOut=300000)
	public void testDownloadFileAfterAddNewApplication(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_cancelAddNewApp")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_download")));
		ApplicationPublish.select(driver, "OTA");
		
		driver.manage().window().maximize();
		ApplicationPublish.download(driver);
		SeleniumUtil.delay(8000);
		Keys.chord(Keys.ALT,"s");
		
		File f = new File(configObj.getPropertyValue("downloads_path")+"\\OTA_SyncTool.zip");
		Assert.assertTrue(f.exists(), "App is successfully downloaded");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			File f = new File(configObj.getPropertyValue("downloads_path")+"\\OTA_SyncTool.zip");
			if(f.exists()){
				f.delete();
			}
		}
		
	}
	
	/*
	 * Sync-342.d:Downloading of DDL scripts after 'Upload Application' form is rendered on the page 
	 */

	/*@Test(enabled=true, timeOut=300000)
	public void testDownloadFileAfterUploadApplication() throws Exception{
		try{
			SeleniumUtil.delay(2000);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.delay(2000);
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.delay(2000);
		////ApplicationPublish.select(driver, "OTA");
		SeleniumUtil.clickAndWait(driver, By.linkText("OTA"),1000);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_cancelAddNewApp")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_download")));
		SeleniumUtil.delay(2000);
		ApplicationPublish.download(driver);
		SeleniumUtil.delay(4000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Generated script files does not exist to download for this application");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "Generated script files does not exist to download for this application");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}*/
	
	/*
	 * Uploading an application which is existing
	 */

	@Test(enabled=true, timeOut=300000)
	public void testUploadExistingApplication(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTASampleSyncConfig.xml");
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertEquals(ApplicationPublish.getSuccessMessage(driver), "Sync Configuration uploaded successfully.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Uploading different application on the existing application
	 */

	@Test(enabled=true, timeOut=300000)
	public void testUploadDifferentAppOnExistingApp(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"TestOTA1.xml");
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID does not match with existing Application ID.");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "Application ID does not match with existing Application ID.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	public void addPersistentApplicationWithDbScripts() throws InterruptedException
	
	{
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
	SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
	if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
		Applications.delete(driver, "Persistent");
	}
	ApplicationPublish.chooseFile(driver, "PersistentSampleSyncConfig.xml");
	ApplicationPublish.generatePersistentDBScripts(driver);
	ApplicationPublish.upload(driver);
	driver.switchTo().activeElement();
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
	SeleniumUtil.delay(6000);
	//Execute DDL scripts for Replica schema.
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
	SeleniumUtil.delay(1000);
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "sa");
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
	SeleniumUtil.delay(1000);
	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
	SeleniumUtil.delay(8000);
	//Execute DDL scripts for Upload schema.
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
	SeleniumUtil.delay(1000);
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "sa");
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
	SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
	SeleniumUtil.delay(1000);
	SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
	SeleniumUtil.delay(2000);
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
	SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
	SeleniumUtil.delay(1000);
	//Click on the Done button.
	SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
	
}
	
	
	/*
	 * Adding persistent application
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddPersistentApplicationWithDbScripts() throws Exception{
		
		if(configObj.getPropertyValue("database").equalsIgnoreCase("MSSQL"))
		{
		try{
			addPersistentApplicationWithDbScripts();
		// Verify the application created successfully.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent")),"Persistent application with db scripts is not created successfully");
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
			Applications.delete(driver, "Persistent");
		      }
		}
		
	}
	
	/*
	 * Uploading an OTA application which is existing by selecting Generate Upload/Replica db scripts check box. 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadOTADBExistingApplication(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTASampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "No SyncScope found with PersistentSync strategy to generate scripts");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "No SyncScope found with PersistentSync strategy to generate scripts");
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTASampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "No SyncScope found with PersistentSync strategy to generate scripts");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "No SyncScope found with PersistentSync strategy to generate scripts");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Uploading different OTA application on the existing application by selecting Generate Upload/Replica db scripts check box. 
	 */

	@Test(enabled=true, timeOut=300000)
	public void testUploadOTADBDifferentAppOnExistingApp(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"TestOTA1.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID does not match with existing Application ID.");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "Application ID does not match with existing Application ID.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	

	/*
	 * Uploading a persistent application which is existing by selecting Generate Upload/Replica db scripts check box. 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadPersistentDBExistingApplication(){
		
		if(configObj.getPropertyValue("database").equalsIgnoreCase("MSSQL"))
		{
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			addPersistentApplicationWithDbScripts();
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.click(driver, By.linkText("Persistent"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"PersistentSampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		
		driver.switchTo().activeElement();
		SeleniumUtil.delay(6000);
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		SeleniumUtil.delay(1000);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
		SeleniumUtil.delay(1000);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		SeleniumUtil.delay(8000);
		//Execute DDL scripts for Upload schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
		SeleniumUtil.delay(1000);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
		SeleniumUtil.delay(1000);
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_dbConfig_dbExecuteStatus")), "Uploaded the Application successfully.");
		Assert.assertEquals(ApplicationPublish.getDBExecuteStatus(driver), "Uploaded the Application successfully.");
		
		String genScripts[]={"Executing DDL scripts for Replica.","Executing DDL scripts for Upload Queue.","Uploading the Application to Sync Console."};
		List<WebElement> listGenScripts = SeleniumUtil.findElements(driver, By.xpath(configObj.getPropertyValue("list_genScripts")));
		int i=0;
		for(WebElement element:listGenScripts)
		{
			Assert.assertEquals(element.getText(), genScripts[i]);
			i++;
		}
		//Click on the Done button.
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
			Applications.delete(driver, "Persistent");
		      }
		}
		
	}
	
	

	/*
	 * Uploading a persistent application which is existing with out selecting Generate Upload/Replica db scripts check box. 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadPersistentAppOnExistingApplication() throws Exception{
		
		if(configObj.getPropertyValue("database").equalsIgnoreCase("MSSQL"))
		{
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			addPersistentApplicationWithDbScripts();
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.click(driver, By.linkText("Persistent"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"PersistentSampleSyncConfig.xml");
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertEquals(ApplicationPublish.getSuccessMessage(driver), "Sync Configuration uploaded successfully.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
			Applications.delete(driver, "Persistent");
		      }
		}
		
	}
	
	
	/*
	 * Uploading a different persistent application which is existing with out selecting Generate Upload/Replica db scripts check box. 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadPersistentDiffAppOnExistingApplication(){
		
		if(configObj.getPropertyValue("database").equalsIgnoreCase("MSSQL"))
		{
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			addPersistentApplicationWithDbScripts();
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.click(driver, By.linkText("Persistent"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"TMsSQL.xml");
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID does not match with existing Application ID.");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "Application ID does not match with existing Application ID.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
			Applications.delete(driver, "Persistent");
		      }
		}
		
	}
	
	
	/*
	 * Uploading different persistent application on the existing application by selecting Generate Upload/Replica db scripts check box. 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadPersistentDBDifferentAppOnExistingApp() throws Exception{
		
		if(configObj.getPropertyValue("database").equalsIgnoreCase("MSSQL"))
		{
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			addPersistentApplicationWithDbScripts();
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.click(driver, By.linkText("Persistent"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"TMsSQL.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID does not match with existing Application ID.");
		Assert.assertEquals(ApplicationPublish.getErrorMessage(driver), "Application ID does not match with existing Application ID.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
			Applications.delete(driver, "Persistent");
		      }
		}
		
	}
	
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return null;
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return null;
	}
	
	/*
	 * DEF511:Test application Id length validation
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIdLengthDEF511(){
		
		try{
			/*ApplicationPublish.chooseFile(driver, "OTA123456789012345.xml");
			ApplicationPublish.upload(driver);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID length must be between 3 to 15 characters."),"Appropriate error message is not obtained");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA123456789012345"+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText("OTA123456789012345")), "Invalid config file with app id length more than 15 is added");*/
			
			ApplicationPublish.chooseFile(driver, "OT.xml");
			ApplicationPublish.upload(driver);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID length must be between 3 to 100 characters."),"Appropriate error message is not obtained");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OT"+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText("OT")), "Invalid config file with app id length less than 3 is added");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		
	}
	
	/*
	 * DEF502:Test application Id length validation by uploading with generate�Schema�option
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIdLengthDEF502(){
		
		try{
			/*ApplicationPublish.chooseFile(driver, "PT123456789012345.xml");
			ApplicationPublish.generatePersistentDBScripts(driver);
			ApplicationPublish.upload(driver);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID length must be between 3 to 15 characters."),"Appropriate error message is not obtained");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PT123456789012345"+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText("PT123456789012345")), "Invalid config file with app id length more than 15 is added");*/
			
			ApplicationPublish.chooseFile(driver, "PT.xml");
			ApplicationPublish.generatePersistentDBScripts(driver);
			ApplicationPublish.upload(driver);
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")), "Application ID length must be between 3 to 100 characters."),"Appropriate error message is not obtained");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "PT"+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.linkText("PT")), "Invalid config file with app id length less than 3 is added");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		
	}
	
	/*
	 * Verify latest version column after adding OTA config file.
	 * DEF630-Version number is not changed when an updated sync-config is uploaded
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLatestVersionOnOTADEF630()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.delete(driver, "OTA");
		}
		Applications.add(driver, "OTASampleSyncConfig.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==1, "Version is not generated in the latest version column");
		
		SeleniumUtil.click(driver, By.linkText("OTA"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTAModified.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertEquals(ApplicationPublish.getSuccessMessage(driver), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==2, "Version is not generated in the latest version column");
		
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		ApplicationPublish.select(driver, "OTA");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
		Assert.assertTrue(SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true).equalsIgnoreCase("Are you sure you want to delete selected Application with history?"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verify latest version column after adding Persistent config file.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLatestVersionOnPersistent()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("Persistent"))){
			Applications.delete(driver, "Persistent");
		}
		Applications.add(driver, "PersistentSampleSyncConfig.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==1, "Version is not generated in the latest version column");
		
		SeleniumUtil.click(driver, By.linkText("Persistent"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"PersistentModified.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertEquals(ApplicationPublish.getSuccessMessage(driver), "Sync Configuration uploaded successfully.");
		
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.delay(2000);
		
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==2, "Version is not generated in the latest version column");
		
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		ApplicationPublish.select(driver, "Persistent");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
		Assert.assertTrue(SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true).equalsIgnoreCase("Are you sure you want to delete selected Application with history?"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verify latest version column after adding new attribute in the config file.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationHistoryAfterAddingNewAttribute()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("ConfChange"))){
			Applications.delete(driver, "ConfChange");
		}
		Applications.add(driver, "ConfChange.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("ConfChange"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"ConfChangeAddAttr.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==2, "Version is not generated in the latest version column when a new attribute is added in the config file");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("View History"));
		SeleniumUtil.click(driver, By.linkText("View Device Schema Changes"));
		SeleniumUtil.delay(1000);
		driver.switchTo().activeElement();

		Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath("//table[@id='altrscrpts']//tr[4]/td")).contains("SampleNAME"),"New Attribute changes are not displayed in 'View History' window");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close")));
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, "ConfChange");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}
		
	}
	
	
	/*
	 * Verify latest version column after adding new object in the config file.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationHistoryAfterAddingNewObject()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("ConfChange"))){
			Applications.delete(driver, "ConfChange");
		}
		Applications.add(driver, "ConfChange.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("ConfChange"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"ConfChangeAddObj.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==2, "Version is not generated in the latest version column when a new object is added in the config file");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("View History"));
		SeleniumUtil.click(driver, By.linkText("View Device Schema Changes"));
		SeleniumUtil.delay(1000);
		driver.switchTo().activeElement();
		Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_deviceSchemaChange"))).contains("CATEGORIESA"),"New object changes are not displayed in 'View History window");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close")));
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, "ConfChange");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}
		
	}
	
	
	/*
	 * Verify latest version column after Deleting object in the config file.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationHistoryAfterDeletingObject()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("ConfChange"))){
			Applications.delete(driver, "ConfChange");
		}
		Applications.add(driver, "ConfChange.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("ConfChange"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"ConfChangeDelObj.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==2, "Version is not generated in the latest version column when an object is deleted in the config file");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("View History"));
		SeleniumUtil.click(driver, By.linkText("View Device Schema Changes"));
		SeleniumUtil.delay(1000);
		driver.switchTo().activeElement();
		Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_deviceSchemaChange"))).contains("drop table CATEGORIES"),"Delete object changes are not displayed in 'View History window");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close")));
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, "ConfChange");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}
		
	}
	
	
	/*
	 * Verify latest version column after adding same config file.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationHistorySameConfigFile()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("ConfChange"))){
			Applications.delete(driver, "ConfChange");
		}
		Applications.add(driver, "ConfChange.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("ConfChange"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"ConfChange.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==1, "Version is generated in the latest version column when a same config file is added");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, "ConfChange");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}
		
	}
	
	/*
	 * Verify latest version column after Changes OtherThan Attr and Obj in ConfigFile.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationHistoryforChangesOtherThanAttrObjInConfigFile()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("ConfChange"))){
			Applications.delete(driver, "ConfChange");
		}
		Applications.add(driver, "ConfChange.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("ConfChange"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"ConfChangeOth.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==1, "Version is generated in the latest version column when a config file with changes other than attr and obj is added");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, "ConfChange");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}
		
	}
	
	/*
	 * Validation of availability of group after updating the application 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadApplicationGroupValidation(){
		
		try{
			
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			if(Applications.isElementPresent(driver, By.linkText("OTA"))){
				Applications.delete(driver, "OTA");
			}
			Applications.add(driver, "OTASampleSyncConfig.xml");
			Groups.navigateToGroupsPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups");
			Groups.assignApplicationToGroup(driver, "Administrator", "OTA");
			Applications.navigateToApplicationsPage(driver);
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			SeleniumUtil.click(driver, By.linkText("OTA"));
			SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"OTAModified.xml");
			ApplicationPublish.keepExistingConfigInHistory(driver);
			ApplicationPublish.upload(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
			Groups.navigateToGroupsPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_groups_pageHeader")), "Groups");
			options = Groups.getApplicationsAssignedToGroup(driver, "Administrator");
			Assert.assertEquals(options.get(0).getText(),"OTA");		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			Applications.navigateToApplicationsPage(driver);
			if(Applications.isElementPresent(driver, By.linkText("OTA"))){
				Applications.delete(driver, "OTA");
			}
		}
		
	}
	
	/*
	 * Verify latest version column after deleting attribute in the config file.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationHistoryAfterDeletingAttribute()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("ConfChange"))){
			Applications.delete(driver, "ConfChange");
		}
		Applications.add(driver, "ConfChange.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("ConfChange"));
		SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+"ConfChangeDeleteAttr.xml");
		ApplicationPublish.keepExistingConfigInHistory(driver);
		ApplicationPublish.upload(driver);
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
		Assert.assertTrue(Double.parseDouble(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_firstRowLatestVersion"))))==2, "Version is not generated in the latest version column when a new attribute is added in the config file");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_deviceSchemaChange_close")));
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_win_viewAppHistory_close")));
			}
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "ConfChange"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, "ConfChange");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		}
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
    /**
     * Extracts a zip file specified by the zipFilePath to a directory specified by
     * destDirectory (will be created if does not exists)
     * @param zipFilePath
     * @param destDirectory
     */
	
    public void unzip(String zipFilePath, String destDirectory){
    	
		try{
		File folder = new File(destDirectory);
    	if(!folder.exists()){
    		folder.mkdir();
    	}
    	//get the zip file content
    	ZipInputStream zis = 
    		new ZipInputStream(new FileInputStream(zipFilePath));
    	//get the zipped file list entry
    	ZipEntry ze = zis.getNextEntry();
 
    	while(ze!=null){
 
    	   String fileName = ze.getName();
           File newFile = new File(destDirectory + File.separator + fileName);
 
            //create all non existing folders
            new File(newFile.getParent()).mkdirs();
 
            FileOutputStream fos = new FileOutputStream(newFile);             
 
            int len;
            while ((len = zis.read(buffer)) > 0) {
       		fos.write(buffer, 0, len);
            }
            fos.close();   
            ze = zis.getNextEntry();
    	}
        zis.closeEntry();
    	zis.close();
 
    }catch(IOException ex){
       ex.printStackTrace(); 
    }
    	
    }
    
}
