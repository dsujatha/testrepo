package com.kony.sync.console.webdriver.applicationPublish;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumConfigProperties;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class ApplicationPublish extends BaseTestcase {
	private static String msg;
	
	/**
	 * Load the config file from the resource directory.
	 * @param driver
	 * @param fileName
	 */
	
	public static void chooseFile(WebDriver driver, String fileName){
		
		try{
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+fileName);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * select to generate upload and replica database scripts.
	 * @param driver
	 */
	
	public static void generatePersistentDBScripts(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.name(configObj.getPropertyValue("cbox_appUpload_GenerateDBScripts")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * select 'keep existing sync config in app history'
	 * @param driver
	 */
	
	public static void keepExistingConfigInHistory(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.name(configObj.getPropertyValue("cbox_keepExistingConfigInHistory")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Upload the config file.
	 * @param driver
	 */
	
	public static void upload(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_upload")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Download the config file.
	 * @param driver
	 */
	
	public static void download(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_download")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Get the message if adding an application was successful.
	 * @param driver
	 * @return
	 */
	
	public static String getSuccessMessage(WebDriver driver){
		
		msg=null;
		try{
			msg = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return msg;
		
	}
	
	/**
	 * Get the message if adding an application was unsuccessful.
	 * @param driver
	 * @return
	 */
	
	public static String getErrorMessage(WebDriver driver){
		
		msg=null;
		try{
			msg = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status")));
		}catch(Exception e){
			e.printStackTrace();
		}
		return msg;
		
	}
	
	/**
	 * Get the status of the replica and upload database creation with an invalid DB credentials. 
	 * @param driver
	 * @return msg
	 */
	
	public static String getDBExecuteStatus(WebDriver driver){
		
		msg=null;
			try{
				msg = SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("txt_dbConfig_dbExecuteStatus")));
			}catch(Exception e){
				e.printStackTrace();
			}
		return msg;
		
	}
	
	/**
	 * select the application from the grid
	 * @param driver
	 * @param applicationid
	 * @return boolean flag
	 */
	
	public static boolean select(WebDriver driver, String appID){
		
		boolean flag=false;
		try{
			WebElement	table=SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_application")));
			List<WebElement> rows  =	table.findElements(By.tagName("tr"));
			int rowCount = rows.size();
			if(rowCount > 1){
				
				for(int i=2; i<=rowCount; i++){
					SeleniumUtil.waitForElement(driver, By.xpath("//tr["+i+"]/td[4]/a/span"));
					if(table.findElement(By.xpath("//tr["+i+"]/td[4]/a/span")).getText().equals(appID)){
						//table.findElement(By.xpath("//tr["+i+"]/td[1]/input")).click();
						//driver.findElement(By.xpath("//table[@id='applicationgrid']/tbody/tr["+i+"]/td[1]/input")).click();
						SeleniumUtil.click(driver, By.xpath("//table[@id='applicationgrid']/tbody/tr["+i+"]/td[1]/input"));
							flag=true;
							break;
						}
				}
				if(!flag){
					Assert.fail("application name not found");
				}
			}else{
				Assert.fail("No record exist inside the application grid.");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	
		return flag;
		
	}
	
	/**
	 * get the status of a job.
	 * @param driver
	 * @param jobName
	 * @param appID
	 * @return status
	 */
	
	public static String getScheduledJobsStatus(WebDriver driver, String jobName, String appID){
		
		String status = null;
		WebElement grid=SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_scheduledJobs")));
		List<WebElement> rows = grid.findElements(By.tagName("tr"));
		
		int rowCount = rows.size();
		if(rowCount > 1){
			for(int i=2; i<=rowCount; i++){
				
				if(grid.findElement(By.xpath("//tr["+i+"]/td[2]")).getText().equalsIgnoreCase(jobName) && grid.findElement(By.xpath("//tr["+i+"]/td[3]/a/span")).getText().equalsIgnoreCase(appID)){
					status = grid.findElement(By.xpath("//tr["+i+"]/td[5]")).getText();
					break;
				}
			}
			}else{
				System.out.println("No record exist inside the Scheduled jobs grid.");
			
		}
		
		return status;
		
	}



}
