package com.kony.sync.console.webdriver.applicationPublish;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class ViewApplicationHistory extends BaseTestcase{

	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	/**
	 * search by app version
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByAppVersion(WebDriver driver, String searchKey){
	
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_viewAppHistory_searchBy_appVersion")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			SeleniumUtil.delay(2000);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get numbers of rows present in the view app history table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{
			WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_viewAppHistory")));
			rowElements = table.findElements(By.tagName("tr"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
		
	}
	
	/**
	 * Verifies refresh functionality
	 * @param driver
	 * @param gridID
	 * @param by
	 * @return
	 */
	
	public static boolean verifyRefresh(WebDriver driver, String gridID, By by) {

		try {
			  SeleniumUtil.delay(2000);
			  List<WebElement> first = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  int initialCount = first.size()-1;
			  if(initialCount!=0)
			  {
				  SeleniumUtil.setText(driver, by, "xyzabcd"+Keys.RETURN);
				  SeleniumUtil. waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
			  List<WebElement> afterSearch = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  if(afterSearch.size()-1==0)
			  {
				  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  SeleniumUtil.delay(2000);
			  List<WebElement> last = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  int finalCount = last.size()-1;
			  if(initialCount==finalCount)
			  {
				  if(SeleniumUtil.getText(driver, by).equals(""))
				  {
				  return true;
				  }
				  else{
					  Assert.fail("The searched string is not cleared even after clicking on refresh");
					  return false;
				  }
			  }
			  else{
				  return false;
			  }
			  }
			  else{
				  Assert.fail("The invalid search string is showing results while trying to test refresh");
				  return false;
			  }
			  }
			  else{
				  Assert.fail("The row is empty so refresh cannot be tested");
				  return false;
			  }
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			  return false;
		}
		
		}
	
	 /*
	   * Verify collapseOfTable
	   */
	
	  public static boolean verifyCollapseOfTable(WebDriver driver)
	  
	  {
		  try{
		  if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_viewAppHistory_collapse"))))
		  {
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_viewAppHistory_collapse")));
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
			  
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-state-default ui-jqgrid-hdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-jqgrid-bdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  SeleniumUtil.click(driver, By.xpath("//div[@id='gview_applicationgrid1']//a[contains(@class,'HeaderButton')]"));
			  SeleniumUtil. waitForElement(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-state-default ui-jqgrid-hdiv' and contains(@style,'display: block')]")), "Collpase button is not working");
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-jqgrid-bdiv' and contains(@style,'display: block')]")), "Collpase button is not working");
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  return true;
		  }
		  else{
			  Assert.fail("Collapse button is not present");
			  return false;
		  }
	  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /*
	   * verify navigation of pages
	   */
	  
	  public static boolean verifyNavigationOfPages(WebDriver driver)
	  
	  {
		  try{
			  int totalNoOfPages=(Integer.parseInt(SeleniumUtil.getVisibleText(driver, By.xpath("("+configObj.getPropertyValue("txt_totalNoOfPages")+")[4]"))));
		  if(totalNoOfPages>1)
		  {
			  SeleniumUtil.delay(2000);
			  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_lastPage")+")[4]"));
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  SeleniumUtil.delay(6000);
			 String pageInfo = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).trim().replaceAll("\\,+", "");
		  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
		  int noOfRecords=result.get(2);
		  Assert.assertTrue(noOfRecords==result.get(1), "All the records are not fetched even after moving to the last page");
		  Assert.assertTrue(totalNoOfPages==(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[4]")))),"Page is not able to navigate to the last page");

		  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath("("+configObj.getPropertyValue("btn_nextPage")+")[4]")), "Next button is not disabled even after reaching the final page");
		  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath("("+configObj.getPropertyValue("btn_lastPage")+")[4]")), "Last button is not disabled even after reaching the final page");
		  
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_firstPage")));
		  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  SeleniumUtil.delay(2000);
		  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_previousPage"))), "Previous button is not disabled even after reaching the first page");
		  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_firstPage"))), "First button is not disabled even after reaching the first page");

		  for(int i=2;i<=totalNoOfPages;i++)
		  {
			  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_nextPage")+")[4]"));
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  SeleniumUtil.delay(1000);
			  Assert.assertTrue(i==(Integer.parseInt(SeleniumUtil.getText(driver,By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[4]")))),"Page is not able to navigate to" +i+ "page in performing next");
			  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
		  }
		  
		  for(int i=2;i<=totalNoOfPages;i++)
		  {
			  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_previousPage")));
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  SeleniumUtil.delay(1000);
			  Assert.assertTrue(i==(totalNoOfPages-(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[4]"))))+1),"Page is not able to navigate to" +i+ "page in performing prev");

			  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
		  }
		  
		  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_lastPage")+")[4]"));
		  SeleniumUtil.delay(1000);
		  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_firstPage")));
		  SeleniumUtil.delay(1000);
		  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  Assert.assertTrue(1==(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[4]")))),"Page is not able to navigate to the first page");
		 String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
		 SeleniumUtil.setText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[4]"), (totalNoOfPages)+""+Keys.RETURN);
		 SeleniumUtil.delay(1000);
		 SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
		  
		  
		  SeleniumUtil.setText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[4]"), 100000000+""+Keys.RETURN);
		  SeleniumUtil.delay(1000);
		  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")),"Page search with invalid text is not working");
		  Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).equalsIgnoreCase("Empty records"),"Empty Records text is not shown");
		  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
		 
		  }
		  else{
			  Assert.fail("Enough no. of records are not there, so navigation of pages cannot be tested");
			  return false;
		  }
		  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
		 * Checking page info - verifies the no. of rows displayed and the page info shown in the page  
		 * @param driver
		 * @param noOfRows
		 * @return true or false
		 */
	  
		public static boolean verifyPagingInfo(WebDriver driver, int noOfRows) {
			
			try {
				String pageInfo = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).trim().replaceAll("\\,+", "");
				Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
				List<Integer> result = new ArrayList<Integer>();
				if (matcher.find()) {
					do {
						result.add(Integer.parseInt(matcher.group(0)));
					} while (matcher.find());
				}
				if (result.get(2) < 10) {
					if (result.get(1) == result.get(2) && result.get(1) == noOfRows) {
						return true;
					} else {
						return false;
					}
				} else {
					if (result.get(2) >= 10 && result.get(1) == 10) {
						return true;
					} else {
						return false;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			
		}
		
		/*
		   * Sorting data in all the fields
		   * trNum is the number in the table grid from where the data starts
		   * It checks only the changing of row id after clicking on the sort button
		   */
		
		  @SuppressWarnings(value = { "unchecked","rawtypes" })
		  public static boolean verifySortingOfData(WebDriver driver,int trNum)
		  
		  {
			  try{
				List<String> exceptionColumns = new ArrayList(Arrays.asList("View Configuration","Device Schema Changes"));
				  if((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>1)
				  {
					  int noOfColumns=SeleniumUtil.findElements(driver,By.xpath("//thead/tr[1]/th[not(contains(@style,'none')) and contains(@id,'applicationgrid1')]")).size();
					  int count=0,noOfIterations=0;
					  if(trNum==3)
					  {
						  count=3;
						  noOfIterations=(noOfColumns+2);
					  }
					  if(trNum==2)
					  {
						  count=2;
						  noOfIterations=(noOfColumns+2);
					  }
					  if(trNum==1)
					  {
						  count=1;
						  noOfIterations=(noOfColumns+1);
					  }
					  String columnName;
					  for(int i=count;i<noOfIterations;i++)
					  {
						  columnName=SeleniumUtil.findElement(driver,By.xpath("//table[@aria-labelledby='gbox_applicationgrid1']/thead/tr[1]/th["+i+"]")).getText().trim();
						  if(!exceptionColumns.contains(columnName))
						  {
						  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][2]")).getAttribute("id");
						  SeleniumUtil.clickAndWait(driver,By.xpath("//table[@aria-labelledby='gbox_applicationgrid1']/thead/tr[1]/th["+i+"]/div"),1000);
						  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
						  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][2]")).getAttribute("id");
						  SeleniumUtil.clickAndWait(driver,By.xpath("//table[@aria-labelledby='gbox_applicationgrid1']/thead/tr[1]/th["+i+"]/div"),1000);
						  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
						  String anotherId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][2]")).getAttribute("id");
						  Assert.assertFalse(beforeId.equals(afterId) && beforeId.equals(anotherId),"Column " + columnName + " is not sorted");
						  SeleniumUtil.delay(1000);
						  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
						  }
					  }
					  return true;
				  }
				  else{
					  Assert.fail("Enough data is not there to check the sort functionality ");
					  return false;
				  }
			  }
			  catch(Exception e)
			  {
				  e.printStackTrace();
				  return false;
			  }
			  
		  }
		  
		  /*
		   * verify size of the page
		   */
		  
		  public static boolean verifyNoOfRecordsToBeDisplayed(WebDriver driver)
		  
		  {
			  try{
				  SeleniumUtil.delay(1000);
			  int no[]={10,20,40,60};
			  for(int i=1;i<=4;i++)
			  {
				Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("//td[@id='applicationpager1_center']//select[@class='ui-pg-selbox']/option["+i+"]")).getText().equals(no[i-1]+""),"The criteria to get page size is not matched");
			  }
			  String pageInfo = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).trim().replaceAll("\\,+", "");

			  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
				List<Integer> result = new ArrayList<Integer>();
				if (matcher.find()) {
					do {
						result.add(Integer.parseInt(matcher.group(0)));
					} while (matcher.find());
				}
			  int noOfRecords=result.get(2);
			  int beforeRows=(int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size();
			  
			  int totalNoOfPages=(Integer.parseInt(SeleniumUtil.getVisibleText(driver, By.xpath("("+configObj.getPropertyValue("txt_totalNoOfPages")+")[4]"))));
			  if(totalNoOfPages>1)
			  {
			  if(noOfRecords>10 && noOfRecords<20)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 20 is not working");
			  }
			  if(noOfRecords==20)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(beforeRows+10),"No.of records changed to 20 is not working");
			  }
			  if(noOfRecords>20 && noOfRecords<40)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
				  beforeRows=(int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size();
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("40");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 40 is not working");
			  }
			  if(noOfRecords==40)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("40");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(beforeRows+30),"No.of records changed to 40 is not working");
			  }
			  if(noOfRecords>40 && noOfRecords<60)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("40");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
				  beforeRows=(int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size();
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("60");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 60 is not working");
			  }
			  if(noOfRecords==60)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("40");
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(40),"No.of records changed to 40 is not working");
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("60");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(beforeRows+50),"No.of records changed to 60 is not working");
			  }
			  if(noOfRecords>60)
			  {
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("20");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("40");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText("60");
				  SeleniumUtil.delay(2000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==60,"No.of records changed to 60 is not working");
			  }
			  
			  verifyNavigationWithMoreNoOfPages(driver, noOfRecords);
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			  SeleniumUtil.click(driver, By.linkText("View History"));
			  
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  SeleniumUtil.delay(2000);
			  
			  if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
			  Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("("+"//div[contains(@id,'gview')]/div[4]"+")[2]")).getAttribute("style").contains("height: 100%"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
			  return true;
			  }
			  else{
				  Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("("+"//div[contains(@id,'gview')]/div[4]"+")[2]")).getAttribute("style").contains("height: auto"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
				  return true;

			  }
			  }
			  else{
				  Assert.fail("Enough records are not there to check the functionality of no. of records to be displayed");
				  return false;
			  }
		  }
			  catch(Exception e){
			  e.printStackTrace();
			  return false;
		  }
			  
		  }
		  
		  /*
		   * navigation With More No Of Pages
		   * support method for verifyNoOfRecordsToBeDisplayed
		   */
		  
		  public static void verifyNavigationWithMoreNoOfPages(WebDriver driver, int noOfRecords) throws InterruptedException
		  
		  {
			  if(noOfRecords>20 && noOfRecords<=40){
				  
				  Assert.assertFalse(noOfPages(driver,"20"),"Not navigated to next page with 20 as page size");
			  }
			  if(noOfRecords>40 && noOfRecords<=60){
				  Assert.assertFalse(noOfPages(driver,"20"),"Not navigated to next page with 20 as page size");
				  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				  SeleniumUtil.click(driver, By.linkText("View History"));
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertFalse(noOfPages(driver,"40"),"Not navigated to next page with 40 as page size");
			  }
			  if(noOfRecords>60){
				  Assert.assertFalse(noOfPages(driver,"20"),"Not navigated to next page with 20 as page size");
				  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				  SeleniumUtil.click(driver, By.linkText("View History"));
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertFalse(noOfPages(driver,"40"),"Not navigated to next page with 40 as page size");
				  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				  SeleniumUtil.click(driver, By.linkText("View History"));
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertFalse(noOfPages(driver,"60"),"Not navigated to next page with 60 as page size");
			  }
			  
		  }
		  
		  /*
		   * support method for verifyNavigationWithMoreNoOfPages
		   */
		  
		  public static boolean noOfPages(WebDriver driver,String num) throws InterruptedException 
		  
		  {
			  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[4]"))).selectByVisibleText(num);
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_nextPage")+")[4]"));
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  return beforeId.equals(afterId);
			  
		  }

		  /**
		   * check if search of lastUpdated time displays correct data
		   * @param driver
		   * @param insertedOnDate
		   * @return true or false
		   */
		  
		  public static boolean verifyInsertedOnSearch(WebDriver driver, String lastUpdatedTime)
		  
		  {
			  try{

				  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				  int rowCount=search(driver, By.id(configObj.getPropertyValue("tbx_ViewAppHistory_searchBy_updateTime")), lastUpdatedTime);
				  if(rowCount>0)
				  {
					  for(int i=2; i<=rowCount+1; i++){
						  SeleniumUtil.waitForElement(driver, By.xpath("//table[@id='applicationgrid1']//tr["+i+"]/td[6]"));
						  if(!(fmt.parse(SeleniumUtil.findElement(driver,By.xpath("//table[@id='applicationgrid1']//tr["+i+"]/td[6]")).getText()).getTime()>=fmt.parse(lastUpdatedTime).getTime())){
							  return false;
						  }
					  }
				  }
				  else{
					  return false;
				  }
				  return true;
			  }
			  catch(Exception e)
			  {
				  e.printStackTrace();
				  return false;
			  }
			  
		  }
		  
			/**
		   * search for a record in a grid
		   * @param by
		   * @param searchText
		   * @return number of rows
		   */
		  
		  public static int search(WebDriver driver, By by,String searchText){
			  
			  try { 
				  SeleniumUtil.setText(driver, by, searchText+Keys.RETURN);  
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  SeleniumUtil.delay(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			  return getRowCount(driver);
			  
		  }
		  
			 /**
			 * close the confirmation box
			 * @return text
			 */
			public static String closeConfirmationBoxAndGetItsText(WebDriver driver, boolean accept) {
				
				String confirmationText=null;
				try {
					WebElement element=SeleniumUtil.findElement(driver, By.xpath(configObj.getPropertyValue("dialog_confirm")));
					confirmationText = element.findElement(By.xpath(configObj.getPropertyValue("txt_appHistoryConfirmDialog"))).getText();
					if (accept) {
						SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_yes_viewAppHistoryConfirm")));
						SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_yes_viewAppHistoryConfirm")));
					} else {
						SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_no_viewAppHistoryConfirm")));
						SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_no_viewAppHistoryConfirm")));
					}
					return confirmationText;
				}finally{
					accept=false;
				}
				

			}
			
			
			public static boolean verifyRefreshTop(WebDriver driver, String gridID, By by) {
				
				try {
					  List<WebElement> first = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
					  int initialCount = first.size()-1;
					  if(initialCount!=0)
					  {
						  SeleniumUtil.setText(driver, by, "xyzabcd"+Keys.RETURN);
						  SeleniumUtil. waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
						  SeleniumUtil.delay(2000);
					  List<WebElement> afterSearch = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
					  if(afterSearch.size()-1==0)
					  {
						  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory_top")));
						  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
						  SeleniumUtil.delay(2000);
					  List<WebElement> last = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
					  int finalCount = last.size()-1;
					  if(initialCount==finalCount)
					  {
						  if(SeleniumUtil.getText(driver, by).equals(""))
						  {
						  return true;
						  }
						  else{
							  Assert.fail("The searched string is not cleared even after clicking on refresh");
							  return false;
						  }
					  }
					  else{
						  return false;
					  }
					  }
					  else{
						  Assert.fail("The invalid search string is showing results while trying to test refresh");
						  return false;
					  }
					  }
					  else{
						  Assert.fail("The row is empty so refresh cannot be tested");
						  return false;
					  }
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
					  return false;
				}
				
				}
			
			public static boolean verifyPagingInfoTop(WebDriver driver, int noOfRows) {
				
				try {
					String pageInfo = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo_top"))).trim().replaceAll("\\,+", "");
					Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
					List<Integer> result = new ArrayList<Integer>();
					if (matcher.find()) {
						do {
							result.add(Integer.parseInt(matcher.group(0)));
						} while (matcher.find());
					}
					if (result.get(2) < 10) {
						if (result.get(1) == result.get(2) && result.get(1) == noOfRows) {
							return true;
						} else {
							return false;
						}
					} else {
						if (result.get(2) >= 10 && result.get(1) == 10) {
							return true;
						} else {
							return false;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				
			}
			
			public static boolean verifyNavigationOfPagesTop(WebDriver driver)
			  {
				
				  try{
					  int totalNoOfPages=(Integer.parseInt(SeleniumUtil.getVisibleText(driver, By.xpath("("+configObj.getPropertyValue("txt_totalNoOfPages")+")[3]"))));
				  if(totalNoOfPages>1)
				  {
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_lastPage")+")[3]"));
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(6000);
					 String pageInfo = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).trim().replaceAll("\\,+", "");
				  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
					List<Integer> result = new ArrayList<Integer>();
					if (matcher.find()) {
						do {
							result.add(Integer.parseInt(matcher.group(0)));
						} while (matcher.find());
					}
				  int noOfRecords=result.get(2);
				  Assert.assertTrue(noOfRecords==result.get(1), "All the records are not fetched even after moving to the last page");
				  Assert.assertTrue(totalNoOfPages==(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[3]")))),"Page is not able to navigate to the last page");

				  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath("("+configObj.getPropertyValue("btn_nextPage")+")[3]")), "Next button is not disabled even after reaching the final page");
				  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath("("+configObj.getPropertyValue("btn_lastPage")+")[3]")), "Last button is not disabled even after reaching the final page");
				  
				  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_firstPage")));
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_previousPage"))), "Previous button is not disabled even after reaching the first page");
				  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_firstPage"))), "First button is not disabled even after reaching the first page");

				  for(int i=2;i<=totalNoOfPages;i++)
				  {
					  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
					  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_nextPage")+")[3]"));
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(1000);
					  Assert.assertTrue(i==(Integer.parseInt(SeleniumUtil.getText(driver,By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[3]")))),"Page is not able to navigate to" +i+ "page in performing next");
					  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
					  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
				  }
				  
				  for(int i=2;i<=totalNoOfPages;i++)
				  {
					  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
					  SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_previousPage")));
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(1000);
					  Assert.assertTrue(i==(totalNoOfPages-(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[3]"))))+1),"Page is not able to navigate to" +i+ "page in performing prev");

					  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
					  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
				  }
				  
				  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_lastPage")+")[3]"));
				  SeleniumUtil.delay(1000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("btn_firstPage")));
				  SeleniumUtil.delay(1000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  Assert.assertTrue(1==(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[3]")))),"Page is not able to navigate to the first page");
				 String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
				 SeleniumUtil.setText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[3]"), (totalNoOfPages)+""+Keys.RETURN);
				 SeleniumUtil.delay(1000);
				 SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
				  
				  
				  SeleniumUtil.setText(driver, By.xpath("("+configObj.getPropertyValue("tbx_pageNo")+")[3]"), 100000000+""+Keys.RETURN);
				  SeleniumUtil.delay(1000);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")),"Page search with invalid text is not working");
				  Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).equalsIgnoreCase("Empty records"),"Empty Records text is not shown");
				  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
				 
				  }
				  else{
					  Assert.fail("Enough no. of records are not there, so navigation of pages cannot be tested");
					  return false;
				  }
				  return true;
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
					  return false;
				  }
				  
			  }
			
			public static boolean verifyNoOfRecordsToBeDisplayedTop(WebDriver driver)
			  {
				
				  try{
					  SeleniumUtil.delay(1000);
				  int no[]={10,20,40,60};
				  for(int i=1;i<=4;i++)
				  {
					Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("//td[@id='applicationpager1_center']//select[@class='ui-pg-selbox']/option["+i+"]")).getText().equals(no[i-1]+""),"The criteria to get page size is not matched");
				  }
				  String pageInfo = SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_viewAppHistory_pageInfo"))).trim().replaceAll("\\,+", "");

				  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
					List<Integer> result = new ArrayList<Integer>();
					if (matcher.find()) {
						do {
							result.add(Integer.parseInt(matcher.group(0)));
						} while (matcher.find());
					}
				  int noOfRecords=result.get(2);
				  int beforeRows=(int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size();
				  
				  int totalNoOfPages=(Integer.parseInt(SeleniumUtil.getVisibleText(driver, By.xpath("("+configObj.getPropertyValue("txt_totalNoOfPages")+")[3]"))));
				  if(totalNoOfPages>1)
				  {
				  if(noOfRecords>10 && noOfRecords<20)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 20 is not working");
				  }
				  if(noOfRecords==20)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(beforeRows+10),"No.of records changed to 20 is not working");
				  }
				  if(noOfRecords>20 && noOfRecords<40)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
					  beforeRows=(int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size();
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("40");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 40 is not working");
				  }
				  if(noOfRecords==40)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("40");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(beforeRows+30),"No.of records changed to 40 is not working");
				  }
				  if(noOfRecords>40 && noOfRecords<60)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("40");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
					  beforeRows=(int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size();
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("60");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 60 is not working");
				  }
				  if(noOfRecords==60)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("40");
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(40),"No.of records changed to 40 is not working");
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("60");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==(beforeRows+50),"No.of records changed to 60 is not working");
				  }
				  if(noOfRecords>60)
				  {
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("20");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("40");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
					  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText("60");
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  Assert.assertTrue((int)SeleniumUtil.findElements(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1]")).size()==60,"No.of records changed to 60 is not working");
				  }
				  
				  verifyNavigationWithMoreNoOfPagesTop(driver, noOfRecords);
				  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				  SeleniumUtil.click(driver, By.linkText("View History"));
				  
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  SeleniumUtil.delay(2000);
				  
				  if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
				  {
				  Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("("+"//div[contains(@id,'gview')]/div[4]"+")[2]")).getAttribute("style").contains("height: 100%"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
				  return true;
				  }
				  else{
					  Assert.assertTrue(SeleniumUtil.findElement(driver,By.xpath("("+"//div[contains(@id,'gview')]/div[4]"+")[2]")).getAttribute("style").contains("height: auto"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
					  return true;

				  }
				  }
				  else{
					  Assert.fail("Enough records are not there to check the functionality of no. of records to be displayed");
					  return false;
				  }
			  }
				  catch(Exception e){
				  e.printStackTrace();
				  return false;
			  }
				  
			  }
			  
			  /*
			   * navigation With More No Of Pages
			   * support method for verifyNoOfRecordsToBeDisplayedTop
			   */
			
			  public static void verifyNavigationWithMoreNoOfPagesTop(WebDriver driver, int noOfRecords) throws InterruptedException
			  {
				  
				  if(noOfRecords>20 && noOfRecords<=40){
					  
					  Assert.assertFalse(noOfPagesTop(driver,"20"),"Not navigated to next page with 20 as page size");
				  }
				  if(noOfRecords>40 && noOfRecords<=60){
					  Assert.assertFalse(noOfPagesTop(driver,"20"),"Not navigated to next page with 20 as page size");
					  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
					  SeleniumUtil.click(driver, By.linkText("View History"));
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertFalse(noOfPagesTop(driver,"40"),"Not navigated to next page with 40 as page size");
				  }
				  if(noOfRecords>60){
					  Assert.assertFalse(noOfPagesTop(driver,"20"),"Not navigated to next page with 20 as page size");
					  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
					  SeleniumUtil.click(driver, By.linkText("View History"));
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertFalse(noOfPagesTop(driver,"40"),"Not navigated to next page with 40 as page size");
					  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
					  SeleniumUtil.click(driver, By.linkText("View History"));
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.delay(2000);
					  Assert.assertFalse(noOfPagesTop(driver,"60"),"Not navigated to next page with 60 as page size");
				  }
				  
			  }
			  
			  /*
			   * Verify alternative clicks for time field
			   * @param driver
			   * @param searchBox
			   * @param grid Id
			   */
			  
			  public static boolean verifyAlternativeClicksForTimeField(WebDriver driver, String searchBox)
			  {
				  
				  try{
					  SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue(searchBox)));
					  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue(searchBox)));
					  SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_viewAppHistory")));
					  SeleniumUtil.delay(2000);
					  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue(searchBox)),1000);
					  SeleniumUtil.delay(1000);
					  SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
					  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present for alternative clicks");
					  return true;
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
					  return false;
				  }
				  
			  }
			  
			  /*
			   * support method for verifyNavigationWithMoreNoOfPagesTop
			   */
			  
			  public static boolean noOfPagesTop(WebDriver driver,String num) throws InterruptedException 
			  {
				  
				  new Select(SeleniumUtil.findElement(driver,By.xpath("("+configObj.getPropertyValue("pgNo_dropDown")+")[3]"))).selectByVisibleText(num);
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  String beforeId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  SeleniumUtil.click(driver,By.xpath("("+configObj.getPropertyValue("btn_nextPage")+")[3]"));
				  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  String afterId=SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'applicationgrid1')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  return beforeId.equals(afterId);
				  
			  }
			  
}
