package com.kony.sync.console.webdriver;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.logs.Logs;
import com.kony.sync.console.webdriver.scheduledJobs.JobHistory;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class DataSourceLogTest extends BaseTestcase{

	String pageName;
	
    @Parameters("pageName")
	@BeforeTest
 	public void loadDriver(String pageName) {
 //	public void loadDriver() { //comment
		try {
	//		pageName="tracelogs"; //comment
			this.pageName=pageName; 
			super.setUp();
			SeleniumUtil.delay(5000);
			driver.get(configObj.getPropertyValue("baseUrl"));
			SeleniumUtil.delay(2000);
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
			SeleniumUtil.delay(2000);
			if(pageName.equalsIgnoreCase("jobhistory"))
			{
				Applications.navigateToApplicationsPage(driver);
				SeleniumUtil.delay(2000);
				Applications.add(driver,"PersistentSampleSyncConfig.xml");
				SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
				SeleniumUtil.delay(2000);
				SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
				if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
					Applications.delete(driver, "Persistent");
				}
				Applications.add(driver,"PersistentSampleSyncConfig.xml");
				SeleniumUtil.delay(120000);
				
				JobHistory.navigateToJobHistoryPage(driver);
				/*JobHistory.searchByStatus(driver, "COMPLETED");
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_jobHistory_viewLog")));*/
				
				List<WebElement> rows=SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_jobHistory"))).findElements(By.tagName("tr"));
				int rowCount = rows.size()-1;
				if(rowCount > 1){
					for(int i=2; i<=rowCount; i++){
						if(Double.parseDouble(SeleniumUtil.findElement(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_dataSourceElapsedTimeInEachRow").replace("$", i+""))).getText())>0)
						{
							SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_dataSourceElapsedTimeInEachRowWithSomeVal").replace("$", i+"")));
							SeleniumUtil.delay(2000);
							break;
						}
					}
				}
				
			}
			else if (pageName.equalsIgnoreCase("tracelogs")) {
				Logs.navigateToTraceLogsPage(driver);
				SeleniumUtil.delay(2000);
				SeleniumUtil.click(driver, By.linkText("0.209"));
				SeleniumUtil.delay(2000);
			}
			else{
				logger.info("Please give valid parameter as page name");
			}
			driver.switchTo().activeElement();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.findElement(driver, By.xpath(configObj.getPropertyValue("win_dataSourceLog"))).isDisplayed())
		{
			driver.navigate().refresh();
			if(pageName.equalsIgnoreCase("jobhistory"))
			{
				JobHistory.navigateToJobHistoryPage(driver);
				/*JobHistory.searchByStatus(driver, "COMPLETED");
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_jobHistory_viewLog")));*/
				
				List<WebElement> rows=SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_jobHistory"))).findElements(By.tagName("tr"));
				int rowCount = rows.size()-1;
				if(rowCount > 1){
					for(int i=2; i<=rowCount; i++){
						if(Double.parseDouble(SeleniumUtil.findElement(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_dataSourceElapsedTimeInEachRow").replace("$", i+""))).getText())>0)
						{
							SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("txt_jobHistory_dataSourceElapsedTimeInEachRowWithSomeVal").replace("$", i+"")));
							SeleniumUtil.delay(2000);
							break;
						}
					}
				}
			}
			else{
				Logs.navigateToTraceLogsPage(driver);
				SeleniumUtil.click(driver, By.linkText("0.209"));
			}
		}
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verify Request Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRequestLink(){
		
		try{
			if(SeleniumUtil.isElementPresent(driver, By.linkText("View Details"))){
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_dsLog_request_viewDetails")));
				SeleniumUtil.delay(2000);
				driver.switchTo().activeElement();
				Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.className(configObj.getPropertyValue("txt_requestData"))).isEmpty(),"View details doesn't contain information about request");
			}else{
				Assert.fail("Request link not found.");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("modelWin_dataSourceLog_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_dataSourceLog_close")));
			}
		}
		
	}

	/*
	 * Verify Response Link
	 *
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testResponseLink(){
		
		try{
			if(SeleniumUtil.isElementPresent(driver, By.linkText("View Details"))){
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_dsLog_response_viewDetails")));
				SeleniumUtil.delay(2000);
				driver.switchTo().activeElement();
				Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.className(configObj.getPropertyValue("txt_requestData"))).isEmpty(),"View details doesn't contain information about response");
			}else{
				Assert.fail("Response link not found.");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("modelWin_dataSourceLog_close"))))
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("modelWin_dataSourceLog_close")));
			}
		}
		
	}

	/*
	 * Searching based on Sync object with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncObject(){
		
		try{
		DataSourceLog.searchBySyncObject(driver, "emp");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_dsLog"), "emp", configObj.getPropertyValue("txt_dsLog_syncObjectInEachRow")),"sync object search is not working");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	}

	/*
	 * Searching based on Sync object with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchBySyncObject(){

		try{
		DataSourceLog.searchBySyncObject(driver, "abcxyz");
		SeleniumUtil.delay(2000);
		Assert.assertTrue(DataSourceLog.getRowCount(driver) == 0,"Search by sync object is not working");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_dsLog_searchBy_syncObject"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on sync operation - with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncOperation(){
		
		try{
		String text;
		if(pageName.equalsIgnoreCase("jobhistory"))
			text="m";
		else
			text="select";
		DataSourceLog.searchBysyncOperation(driver, text);
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_dsLog"), text, configObj.getPropertyValue("txt_dsLog_syncOperationInEachRow")),"Sync operation search is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on sync operation - with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchBySyncOperation(){

		try{
		DataSourceLog.searchBysyncOperation(driver, "abcxyz");
		SeleniumUtil.delay(1000);
		Assert.assertTrue(DataSourceLog.getRowCount(driver) == 0,"Search by sync operation is not working");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_dsLog_searchBy_syncOperation"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on Target- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByTarget(){
		
		try{
		DataSourceLog.searchByTarget(driver, "emp");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_dsLog"), "emp",configObj.getPropertyValue("txt_dsLog_targetInEachRow")),"Search by target is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on Target- with invalid search text
	 */
	
	@Test(enabled = true)
	public void testInvalidSearchByTarget(){

		try{
		DataSourceLog.searchByTarget(driver, "abcxyz");
		Assert.assertTrue(DataSourceLog.getRowCount(driver) == 0,"Search by target is not working");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_dsLog_searchBy_target"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on status- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByStatus(){
		
		try{
		DataSourceLog.searchByStatus(driver, "e");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_dsLog"), "e", configObj.getPropertyValue("txt_dsLog_statusInEachRow")),"Status search is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on status- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchByStatus(){

		try{
		DataSourceLog.searchByStatus(driver, "abcxyz");
		SeleniumUtil.delay(1000);
		Assert.assertTrue(DataSourceLog.getRowCount(driver) == 0,"Invalid Status search is not working");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.xpath(configObj.getPropertyValue("tbx_dsLog_searchBy_status"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}	

	@Test(enabled=true, timeOut=300000)
	public void testValidSearchStartAndEndtime(){

		try{
		DataSourceLog.searchByStartAndEndTime(driver, "07/23/2013 17:53:10 +0530", "07/23/2030 18:07:30 +0530");
		Assert.assertTrue(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2013 17:53:10 +0530", "07/23/2030 18:07:30 +0530", "grid_dsLog", configObj.getPropertyValue("txt_dsLog_startTimeInEachRow"), configObj.getPropertyValue("txt_dsLog_endTimeInEachRow")),"Valid search for start and end time together is not working.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchStartAndEndtime(){
		
		try{
		DataSourceLog.searchByStartAndEndTime(driver, "07/23/2013 18:05:00 +0530", "07/23/2013 18:00:00 +0530");
		SeleniumUtil.delay(1000);
		Assert.assertFalse(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2013 18:05:00 +0530", "07/23/2013 18:00:00 +0530", "grid_dsLog",configObj.getPropertyValue("txt_dsLog_startTimeInEachRow"), configObj.getPropertyValue("txt_dsLog_endTimeInEachRow")),"Valid search for start and end time together is not working.");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.xpath(configObj.getPropertyValue("tbx_dsLog_searchBy_startTime"))).contains("07/23/2013 18:05:00"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_dsLog"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyRefresh(driver, "grid_dsLog", By.id(configObj.getPropertyValue("tbx_dsLog_searchBy_syncObject"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		try{
		SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("tbx_dsLog_searchBy_startTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("tbx_dsLog_searchBy_endTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/*
	 * Verifying calendar for start time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForStartTime()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyTimeThroughCalendarAndSearch(driver,"tbx_dsLog_searchBy_startTime", "grid_dsLog", "start")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/*
	 * Verifying calendar for end time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForEndtime()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyTimeThroughCalendarAndSearch(driver,"tbx_dsLog_searchBy_endTime", "grid_dsLog", "end")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForStartTimeField()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyAlternativeClicksForTimeField(driver, "tbx_dsLog_searchBy_startTime"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForEndTimeField()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyAlternativeClicksForTimeField(driver, "tbx_dsLog_searchBy_endTime"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(DataSourceLog.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/

	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		try{
		Assert.assertTrue(DataSourceLog.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifySortingOfData(driver,2),"Data is not sorted on the click of column name");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyNoOfRecordsToBeDisplayed(driver, pageName),"No. of records to be displayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@AfterMethod
	public void afterMethod()
	{
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_refresh_dsLog")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	protected String getPageId() {
		return null;
	}

	@Override
	protected String getSearchId() {
		return configObj.getPropertyValue("tbx_dsLog_searchBy_syncObject");
	}

	@AfterTest
	public void tearDown(){
		
		try{
		if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))))
		{
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close")));
		}
		if(pageName.equalsIgnoreCase("jobhistory"))
		{
		Applications.navigateToApplicationsPage(driver);
		Applications.delete(driver,"Persistent");
		}
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshTop()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyRefreshTop(driver, "grid_dsLog", By.id(configObj.getPropertyValue("tbx_dsLog_searchBy_syncObject"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info Top
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoTop()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyPagingInfoTop(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_dsLog"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at Top
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesTop()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyNavigationOfPagesTop(driver),"Navigation of pages is not working as expected");} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page at Top
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedTop()
	{
		
		try{
		Assert.assertTrue(DataSourceLog.verifyNoOfRecordsToBeDisplayedTop(driver,pageName),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
