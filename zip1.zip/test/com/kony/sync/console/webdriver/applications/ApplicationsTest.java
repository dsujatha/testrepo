
package com.kony.sync.console.webdriver.applications;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applicationPublish.ApplicationPublish;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class ApplicationsTest extends BaseTestcase{
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void setUp(){
		
		try{
			
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			Applications.navigateToApplicationsPage(driver);
			Applications.waitForElement(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-223:Add application or sync config file
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddApplication(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("OTA"))){
		
				Applications.delete(driver, "OTA");
		
		}
		Assert.assertEquals(Applications.add(driver,"OTASampleSyncConfig.xml"), "Sync Configuration uploaded successfully.","Either application configuration is not uploaded successfully or the displayed message is not as expected.");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		Assert.assertTrue(Applications.isElementPresent(driver, By.linkText("OTA")),"Application is not added");
		SeleniumUtil.verifySecurityAudit(driver, "ADDED_APPLICATION(OTA)", "Created new application");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-226:Edit Application
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditApplication(){
	
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		
		Assert.assertEquals(Applications.edit(driver, "OTASampleSyncConfig.xml","OTA"), "Sync Configuration uploaded successfully.", "Either Application is not edited successfully or the displayed message is not as expected.");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		Assert.assertTrue(Applications.isElementPresent(driver, By.linkText("OTA")), "Application is not available after editing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-225:View added Configuration File.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testViewAddedConfigFile(){
		
		try{
		if(!SeleniumUtil.isElementDisplayed(driver, By.linkText(configObj.getPropertyValue("link_viewConfiguration")))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		String parentWindow= driver.getWindowHandle();
		SeleniumUtil.clickAndWait(driver, Applications.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_viewConfiguration"))), 1000);
		Set<String> availableWindows = driver.getWindowHandles();
		Assert.assertTrue(availableWindows.size() == 2,"Added configuration file is not displayed");
		
		for(String windowHandle  : availableWindows)
	       {
	       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
	          {
	    	   driver.switchTo().window(windowHandle);
	    	   driver.close();
	    	   break;
	          }
	       }
	         driver.switchTo().window(parentWindow);
	         
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-226:Delete Application
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteApplication(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		
		Applications.delete(driver, "OTA");
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.linkText("OTA"));
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_deleteApplicationsMessageId")), "Application(s) deleted successfully."),"Message after deleting application is not proper");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		Assert.assertFalse(Applications.isElementPresent(driver, By.linkText("OTA")),"Application is not deleted");
		SeleniumUtil.verifySecurityAudit(driver, "DELETED_APPLICATION(OTA)", "Deleted the application");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-226:Cancel delete application
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCancelDeleteApplication(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}

		Applications.cancelDelete(driver, "OTA");
		SeleniumUtil.waitForElement(driver, By.linkText("OTA"));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		Assert.assertTrue(Applications.isElementPresent(driver, By.linkText("OTA")),"Not able to cancel the delete application operation");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Sync-227:Upload invalid Configuration File
	 * DEF470 :No option is available to clear the displayed error log while adding invalid xml file in the Application Screen.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUploadInvalidApplicationDEF470(){
				
		try{
		Applications.add(driver, "TextFile.txt");
	    Assert.assertEquals(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("msg_addInvalidApp_Status"))),"The uploaded file does not appear to be a valid Sync Configuration. Please provide a valid Sync Configuration and try again.", "Proper error message is not displayed when uploading an invalid file");
	    Assert.assertFalse(Applications.isElementPresent(driver, By.linkText("InvalidOTA")),"Invalid configuration file is uploaded");
	    SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp")));
		if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp"))))
		{
		Assert.assertTrue(SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp"))).equalsIgnoreCase("Show Error Details"),"'Show error details' text is not shown on the button");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp")));
		}
		else{
		Assert.fail("'Show Error Details' button is not shown");	
		}
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status"))), "Exception details are not shown on click of 'Show Error Details' button");
		Assert.assertTrue(SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp"))).equalsIgnoreCase("Hide Error Details"),"'Hide Error Details' text is not shown on the button after exception is shown");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_showHideErrorInvalidApp")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status")));
		Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("exception_addInvalidApp_Status"))), "Exception details are not hidden on click of 'Hide Error Details' button");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * DEF230:Testing authentication - Need to have the ApplicationName on the pop-up when the user tries to assign the authentication class to the application.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAuthenticationDEF230(){
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		Applications.clickAuthentication(driver, "OTA");
		SeleniumUtil.delay(1000);
		driver.switchTo().activeElement();
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("win_assignAuthentication"))), "Assign Authentication", "Either Assign authentication layout is not opened or the title is wrong");
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_assignAuthDialog_AppId"))), "OTA");
		SeleniumUtil.clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_assignAuthentication_save")),2000);
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_assignAuthStatus")), "Assigned authentication profile successfully");
	    Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("msg_assignAuthStatus"))),"Assigned authentication profile successfully" , "Authentication is not successful");
	    SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_assignAuthentication_cancel")));
	    Assert.assertFalse(Applications.isElementPresent(driver, By.xpath(configObj.getPropertyValue("win_assignAuthentication"))),"Cancel button is not working");
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * DEF473,DEF472,DEF288:Testing Edit data source 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditDataSourceDEF473_DEF472_DEF288(){
				
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.delete(driver, "OTA");
		}
			Applications.add(driver, "OTASampleSyncConfig.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);	
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, Applications.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_editDataSource"))));
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")));
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader"))), "Edit Datasource", "Edit Datasource page is not opened");

		List<WebElement> ls= SeleniumUtil.findElements(driver, By.xpath(configObj.getPropertyValue("list_editDataSourceDatabaseType")));
		String database[]={"MSSQLSERVER","ORACLE","MYSQL","POSTGRESQL"};
		for(int i=0;i<ls.size();i++)
		{
			Assert.assertTrue(ls.get(i).getText().equalsIgnoreCase(database[i]),"All the databases are not available");
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceDbUserName")+"0"), "sa");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceDbPassword")+"0"), "kony123!");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_update")));
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("msg_editDataSource")), "Datasource updated successfully"), "Datasource is not edited successfully");
		Assert.assertTrue(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceDbUserName")+"0")).equalsIgnoreCase("sa"), "Changed data is not reflecting after updating the data");
		
		String resetDataSourceName=SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceName")+"0"))+"1";
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceName")+"0"), resetDataSourceName);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_reset")));
		Assert.assertFalse(resetDataSourceName.equalsIgnoreCase(SeleniumUtil.getVisibleText(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceName")+"0"))), "Datasource name is not reset to actual name");

		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_arrowListMenu")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("arrowListMenu_minimizedState")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("arrowListMenu_minimizedState"))),"Content is not minimized");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_arrowListMenu")));
		Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("arrowListMenu_minimizedState"))),"Content is not maximized");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_cancel")));
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")), "Applications"),"Cancel is not working");
		SeleniumUtil.verifySecurityAudit(driver, "UPDATED_DATASOURCE(OTA)", "Updated Datasource details");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Search application ID with valid text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSearchValidApplicationID(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")), "Applications"))
		{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "test"+Keys.RETURN);
			Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_application"), "test", configObj.getPropertyValue("txt_applicationIdInEachRow")),"Valid search of application Id is not working as expected.");
		}
		else {
			Assert.fail("Applications page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Search application ID with invalid text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSearchInValidApplicationID(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")), "Applications"))
		{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "xyz"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			Assert.assertTrue(Applications.getRowCount(driver)==0,"Invalid Search of application ID is not working as expected.");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			Assert.assertFalse(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
		}
		else {
			Assert.fail("Applications page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		
	/*
	 * Search application name with valid text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSearchValidApplicationName(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")), "Applications"))
		{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationname")), "Sa"+Keys.RETURN);
			Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_application"), "Sa", configObj.getPropertyValue("txt_applicationNameInEachRow")),"Valid Search of application name is not working as expected.");
		}
		else {
			Assert.fail("Applications page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Search application name with invalid text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSearchInValidApplicationName(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")), "Applications"))
		{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationname")), "xyz"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			Assert.assertTrue(Applications.getRowCount(driver)==0,"Invalid Search of application name is not working as expected.");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			Assert.assertFalse(SeleniumUtil.getText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationname"))).equals("xyz"), "Text in the search field is not cleared after refreshing");

		}
		else {
			Assert.fail("Applications page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,Applications.getRowCount(driver)),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_application", By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationname"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,4),"Data is not sorted on the click of column name");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return "applications";
	}
	
	/*
	 * verify add new application frame
	 * DEF462 : Upload application pop-up not closed upon click on cancel in this scenario.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testAddApplicationFrameDEF462(){
		
		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
		Assert.assertTrue(SeleniumUtil.isElementDisplayed(driver, By.id(configObj.getPropertyValue("txt_addNewAppHeader"))), "Add application frame is not opened after clicking on add application button");
		ApplicationPublish.generatePersistentDBScripts(driver);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_cancelAddNewApp")));
		Assert.assertFalse(SeleniumUtil.isElementDisplayed(driver, By.id(configObj.getPropertyValue("txt_addNewAppHeader"))), "Add application frame is not closed even after clicking on cancel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *verify change authentication type
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testChangeAuthenticationType()
	{
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "TestOTA6"+Keys.RETURN);
		SeleniumUtil.waitForElement(driver, By.linkText("TestOTA6"));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("link_assignAuthentication")));
		driver.switchTo().activeElement();
		if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
		  {
			new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("list_assignAuthenticationToApp")))).selectByVisibleText("CUSTOM");
		  }
		else{
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_authenticationTypeDropDown")));
			  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_authenticationTypes")));
			  for (WebElement option : options) {
			     if("CUSTOM".equalsIgnoreCase(option.getText()))
			     {
			        option.click();
			     	break;
			     }
			  }
		}
		
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_assignAuthentication_save")));
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_assignAuthStatus")), "Assigned authentication profile successfully");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("link_assignAuthentication")),"CUSTOM"), "Authentication type is not changed after saving and closing the authentication pop-up");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return null;
	}
	
	/*
	 *verify delete with out selecting an application
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeleteWithOutSelectingAnApplication()
	{
		try{
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Please select at least one application to delete."), "Error pop up is not shown when trying to delete with out selecting any application.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verify 'View History' link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testViewApplicationHistoryLink()
	{
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(!Applications.isElementPresent(driver, By.linkText("OTA"))){
			Applications.add(driver, "OTASampleSyncConfig.xml");
		}
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "OTA"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.click(driver, By.linkText("View History"));
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("win_modelWin"))), "View History");
		Assert.assertTrue(SeleniumUtil.verifyContainsText(driver, By.xpath(configObj.getPropertyValue("layout_historyModelWin_header")),"OTA"), "The app Id is not shown on the view history window");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying bottom refresh button
	 */
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_application", By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationname"))),"Refresh at bottom is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,Applications.getRowCount(driver)),"Page info at bottom is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Testing Edit data source name field
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditDataSourceDataSourceName(){
				
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "testDef2DB"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("testDef2DB"))){
			Applications.delete(driver, "testDef2DB");
		}
			Applications.add(driver, "testDef2DB.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "testDef2DB"+Keys.RETURN);	
		SeleniumUtil.click(driver, Applications.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_editDataSource"))));
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")));
		
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceName")+"0"));
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_update")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Datasource Name must not be blank."),"Alert is not shown when trying to update with empty datasourcename");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_reset")));
		
		SeleniumUtil.clickAndWait(driver, By.xpath("//*[contains(text(),'test2 : DATABASE')]"), 1000);
		
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_editDataSourceName")+"1"));
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_update")));
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).equalsIgnoreCase("Datasource Name must not be blank."),"Alert is not shown when trying to update with empty datasourcename");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_reset")));
		
		SeleniumUtil.clickAndWait(driver, By.xpath("//*[contains(text(),'tet : DATABASE')]"), 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Testing Edit data source name field
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditDataSourceIsJNDIDataSource(){
				
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "testDef2DB"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("testDef2DB"))){
			Applications.delete(driver, "testDef2DB");
		}
			Applications.add(driver, "testDef2DB.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "testDef2DB"+Keys.RETURN);	
		SeleniumUtil.click(driver, Applications.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_editDataSource"))));
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")));
		SeleniumUtil.delay(1000);
		new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("select_isJNDIDataSource")+"0"))).selectByVisibleText("true");
		Assert.assertTrue(SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("tbx_JNDIOrJDBCUrl")+"0")).getAttribute("value").equals(""), "JNDC/JDBC Url field is not empty even after the JNDI data source is true");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_reset")));
		
		SeleniumUtil.clickAndWait(driver, By.xpath("//*[contains(text(),'test2 : DATABASE')]"), 1000);
		
		new Select(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("select_isJNDIDataSource")+"1"))).selectByVisibleText("true");
		Assert.assertTrue(SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("tbx_JNDIOrJDBCUrl")+"1")).getAttribute("value").equals(""), "JNDC/JDBC Url field is not empty even after the JNDI data source is true");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_editDataSource_reset")));
		
		SeleniumUtil.clickAndWait(driver, By.xpath("//*[contains(text(),'tet : DATABASE')]"), 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Testing Edit data source password field
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testEditDataSourcePasswordField(){
				
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "SAPNW"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
		if(Applications.isElementPresent(driver, By.linkText("SAPNW"))){
			Applications.delete(driver, "SAPNW");
		}
			Applications.add(driver, "SAPNW.xml");
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "SAPNW"+Keys.RETURN);	
		SeleniumUtil.click(driver, Applications.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_editDataSource"))));
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("txt_applications_pageHeader")));
		SeleniumUtil.delay(1000);
		Assert.assertTrue(SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("txt_editDataSource_pwd"))).getAttribute("type").equalsIgnoreCase("password"), "Password field is shown as a normal text");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
