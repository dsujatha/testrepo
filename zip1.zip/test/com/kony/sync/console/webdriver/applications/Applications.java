package com.kony.sync.console.webdriver.applications;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applicationPublish.ApplicationPublish;
import com.kony.sync.console.webdriver.utils.SeleniumConfigProperties;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;


public abstract class Applications extends BaseTestcase{

	private static WebDriverWait wait;
	private static String status;
	private static String alertText;
	private static List<WebElement> authTypes;
	private static List<WebElement> rowElements = new ArrayList<WebElement>();
	
	/**
	 * Navigate to the Application page
	 */
	
	public static void navigateToApplicationsPage(WebDriver driver){

		SeleniumUtil.waitForText(driver, By.linkText(configObj.getPropertyValue("link_applications")), "Applications");
		SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_applications")));

	}

	/**
	 * add a new application
	 * @param driver
	 * @param fileName
	 * @return success message if new application added successfully, else null.
	 */
	
	public static String add(WebDriver driver, String fileName){
		
		status=null;
		try{
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_addApplication")));
			SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+fileName);
			SeleniumUtil.click(driver, SeleniumUtil.waitForElement(driver,By.id(configObj.getPropertyValue("btn_upload"))));
			SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")));
			SeleniumUtil.waitForText(driver,By.xpath(configObj.getPropertyValue("msg_addApplication_Status")), "Sync Configuration uploaded successfully.");
			status=SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while adding an application.");
			e.printStackTrace();
		}
		return status;
		
	}

	/**
	 * Edit and upload existing application.
	 * @param driver
	 * @param fileName
	 * @param appName
	 * @return success message if new application added successfully, else null.
	 */
	
	public static String edit(WebDriver driver, String fileName, String appName){
		
		status=null;
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), appName+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			SeleniumUtil.click(driver, waitForElement(driver,By.linkText(appName)));
			SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+fileName);
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_upload")));
			SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")));
			status=SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")));
		}catch(Exception e){
			Reporter.log("ERROR: problem occurred while editing the application.");
			e.printStackTrace();
		}
		return status;
		
	}

	/**
	 * Delete the application.
	 * @param driver
	 * @param appName
	 */

	public static void delete(WebDriver driver, String appName){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), appName+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			ApplicationPublish.select(driver, appName);
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_deleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);

		}catch(Exception e){

			Reporter.log("ERROR: problem occurred while deleting application.");
			e.printStackTrace();
		}
		
	}

	/**
	 * cancel the application delete operation. 
	 * @param driver
	 * @param appName
	 */
	
	public static void cancelDelete(WebDriver driver, String appName){
		
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), appName+Keys.RETURN);
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
			SeleniumUtil.click(driver, By.cssSelector(configObj.getPropertyValue("link_appName")));
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cancelDeleteApp")));
			SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, false);

		}catch(Exception e){

			Reporter.log("ERROR: problem occurred while cancelling the delete application operation.");
			e.printStackTrace();
		}
		
	}

	/**
	 * get the authentication types from the authentication column of the application grid.
	 * @param driver
	 * @return list of authentication types
	 */
	
	public static List<WebElement> getAuthentication(WebDriver driver){
		
		authTypes=null;
		try{
			WebElement table = SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_application")));
			List<WebElement> rows  =	table.findElements(By.tagName("tr"));
			int rowCount = rows.size();
			if(rowCount > 1){
				table.findElement(By.xpath(configObj.getPropertyValue("link_assignAuthenticationToApp"))).click();
				SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_authenticationTypeDropDown")));
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_authenticationTypeDropDown")));
				authTypes = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_authenticationTypes")));
			}else{
				System.out.println("No record exist inside the Application grid.");
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return authTypes;
		
	}


	/**
	 * upload a new application
	 * @param driver
	 * @param fileName
	 * @return success message if new application added successfully, else null.
	 *//*
	public static void generateDBScripts(WebDriver driver, boolean isGenerateDBScripts, String fileName){

		try{
			driver.findElement(By.id(configObj.getPropertyValue("btn_addApplication"))).click();
		    driver.findElement(By.id(configObj.getPropertyValue("btn_chooseFile"))).sendKeys(SeleniumConfigProperties.getProjectHome()+"\\resources\\configFiles\\"+fileName);
		    if(isGenerateDBScripts){
		    	driver.findElement(By.name(configObj.getPropertyValue("cbox_appUpload_GenerateDBScripts"))).click();
		    }
		    driver.findElement(By.id(configObj.getPropertyValue("btn_upload"))).click();
		    SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("msg_addApplication_Status")));
		  //  status = driver.findElement(By.xpath(configObj.getPropertyValue("msg_addApplication_Status"))).getText();
			}catch(Exception e){
			Reporter.log("ERROR: problem occurred while adding an application.");
			e.printStackTrace();
		}

	}*/


	/**
	 * wait for an element until it displayed on the page otherwise timeout after 10 seconds.
	 * @param driver
	 * @param byElement
	 * @return byElement
	 */
	
	public static By waitForElement(WebDriver driver, By byElement){
		
		wait = new WebDriverWait(driver, 10L);
		try{
			wait.until(ExpectedConditions.visibilityOfElementLocated(byElement));

		}catch(Exception e){
			Reporter.log("FAILURE: waitForElement, "+byElement+" has not found. TIMED OUT AFTER 10 SECONDS. \n"+e);
		}
		return byElement;
		
	}

	/**
	 * check if element is present on the page
	 * @param by
	 * @return true or false
	 */
	
	public static boolean isElementPresent(WebDriver driver, By by) {
		
		boolean flag=false;
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			flag = false;
		}
		return flag;
		
	}

	/**
	 * close the alert and return the text present on the alert box
	 * @return text
	 */
	
	public static String closeAlertAndGetItsText(WebDriver driver, boolean acceptAlert) {
		
		alertText=null;
		try {
			Alert alert = driver.switchTo().alert();
			alertText = alert.getText();
			if (acceptAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		}finally{
			acceptAlert=false;
		}

	}

	/**
	 * Click authentication
	 * @param driver
	 * @param appID
	 */
	
	public static void clickAuthentication(WebDriver driver, String appID){
		
		boolean flag=false;
		try{
			WebElement table = SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_application")));
			List<WebElement> rows  =	table.findElements(By.tagName("tr"));
			int rowCount = rows.size();
			if(rowCount > 1){

				for(int i=2; i<=rowCount; i++){
					SeleniumUtil.waitForElement(driver, By.xpath("//tr["+i+"]/td[4]/a/span"));
					if(table.findElement(By.xpath("//tr["+i+"]/td[4]/a/span")).getText().equals(appID)){
						SeleniumUtil.clickAndWait(driver, By.xpath("//table[@id='applicationgrid']/tbody/tr["+i+"]//a[@id='assauth']"),1000);
						flag=true;
						break;
					}
				}
				if(!flag){
					System.out.println("Authentication name not found.");
				}
			}else{
				System.out.println("No record exist inside the Authentication grid.");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get numbers of rows present in the Applications table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{
			WebElement table = SeleniumUtil.findElement(driver, By.id(configObj.getPropertyValue("grid_application")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
		
	}

}