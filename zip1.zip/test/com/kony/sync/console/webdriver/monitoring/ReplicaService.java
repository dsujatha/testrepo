package com.kony.sync.console.webdriver.monitoring;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class ReplicaService extends BaseTestcase{

	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	public static void navigateToReplicaServicePage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_replicaService_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public static void clickOnLink(WebDriver driver, String linkName){

		try{
			SeleniumUtil.click(driver, By.linkText(linkName));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}


	/**
	 * search by replica status
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByReplicaStatus(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_replicaStatus")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * get numbers of rows present in the Replica Service table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{

			WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_replicaService")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
	}

	/**
	 * search by application id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByApplicationID(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_applicationID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by Sync Server IP
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchBySyncServerIP(WebDriver driver, String searchKey){
	
		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replica_searchBy_SyncServerIP")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by start and end date time
	 * @param driver
	 * @param startTime
	 * @param endTime
	 */
	
	public static void searchByStartAndEndTime(WebDriver driver, String startTime, String endTime){

		try{
			// wait for Start Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_startTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_startTime")), startTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_replicaService_calender_Done")));

			// wait for end Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_endTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_endTime")), endTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_replicaService_calender_Done")));
			// wait for the date and time to appear in the end Time text box
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by No. of rows
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByNoOfRows(WebDriver driver, String searchKey){
	
	try{
	
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_NoOfRows")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
