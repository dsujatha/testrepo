
package com.kony.sync.console.webdriver.monitoring;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class SecurityAuditTest extends BaseTestcase{

	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){

		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Security Audit"));
			SecurityAudit.navigateToSecurityAuditPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_securityAudit_pageHeader")), "Security Audit");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on 'who changed' with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBywhoChanged(){

		try{
		SecurityAudit.searchByWhoChanged(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_securityAudit"), "sync",configObj.getPropertyValue("txt_securityAudit_whoChangedInEachRow")),"Search by who changed is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on 'who changed' with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchBywhoChanged(){

		try{
		SecurityAudit.searchByWhoChanged(driver, "abcxyz");
		Assert.assertTrue(SecurityAudit.getRowCount(driver) == 0,"Search by who changed is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whoChanged"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on 'what changed' with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByWhatChanged(){

		try{
		SecurityAudit.searchByWhatChanged(driver, "ADDED");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_securityAudit"), "ADDED",configObj.getPropertyValue("txt_securityAudit_whatChangedInEachRow")),"Search by what changed is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	/*
	 * Searching based on 'what changed' with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByWhatChanged(){

		try{
		SecurityAudit.searchByWhatChanged(driver, "abcxyz");
		Assert.assertTrue(SecurityAudit.getRowCount(driver) == 0,"Search by what changed is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whatChanged"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/* 
	 * Searching based on valid Time in 'when'
	 * 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByValidWhenTime(){

		try{
		SecurityAudit.searchByWhenDateTime(driver, "08/01/2013 10:49:28 +0530");
		Assert.assertTrue(SeleniumUtil.verifyInitialDateTimeSearch(driver, "08/01/2013 10:49:28 +0530", "grid_securityAudit", configObj.getPropertyValue("txt_securityAudit_whentimeInEachRow")),"Search by when time is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/* 
	 * Searching based on invalid Time in 'when'
	 * 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByWhenTime(){

		try{
		SecurityAudit.searchByWhenDateTime(driver, "08/20/2030 06:12:12 +0530");
		Assert.assertTrue(SecurityAudit.getRowCount(driver) == 0, "Search by when time is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whenDateTime"))).contains("08/20/2030 06:12:12"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on 'comments' with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByComments(){

		try{
		SecurityAudit.searchByComments(driver, "enable");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_securityAudit"), "enable" +"",configObj.getPropertyValue("txt_securityAudit_commentsInEachRow")),"Search by comments is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Searching based on 'comments' with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByComments(){

		try{
		SecurityAudit.searchByComments(driver, "abcxyz");
		Assert.assertTrue(SecurityAudit.getRowCount(driver) == 0, "Search by comments is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_comments"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_securityAudit"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_securityAudit", By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whoChanged"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whenDateTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for When time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForWhenTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_securityAudit_searchBy_whenDateTime", "grid_securityAudit", "start")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForWhenTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_securityAudit_searchBy_whenDateTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,2),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "securityAudit";
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_securityAudit_searchBy_whoChanged");
		
	}
	
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_securityAudit", By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whoChanged"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_securityAudit"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown(){

		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
