
package com.kony.sync.console.webdriver.monitoring;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.applicationPublish.ApplicationPublish;
import com.kony.sync.console.webdriver.applications.Applications;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class ReplicaServiceTest extends BaseTestcase{
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Replica Service"));
			ReplicaService.navigateToReplicaServicePage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_replicaService_pageHeader")), "Replica Service");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-287:Verifying of Application Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
		if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("txt_replica_appIdColumn")))){
			SeleniumUtil.delay(1000);
			String parentWindow= driver.getWindowHandle();
			SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("link_replica_appId")));
			SeleniumUtil.delay(1000);
			Set<String> handles=driver.getWindowHandles();
			Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
			
			 for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow);
		}else{
			Assert.fail("Application ID not found.");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}	
	
	/*
	 * Sync-288:Searching based on Replica status
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByReplicaStatus(){
		
		try{
		ReplicaService.searchByReplicaStatus(driver, "COMPLETED");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_replicaService"), "COMPLETED", configObj.getPropertyValue("txt_replica_statusInEachRow")),"Search by replica status is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-288:Searching based on Replica status- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByReplicaStatus(){
		
		try{
		ReplicaService.searchByReplicaStatus(driver, "xyzabc");
		Assert.assertTrue(ReplicaService.getRowCount(driver) == 0,"Search by replica status is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_replicaStatus"))).equals("xyzabc"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 *  Sync-289:Searching based on Applications - with a valid search text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		ReplicaService.searchByApplicationID(driver, "pers");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_replicaService"), "pers", configObj.getPropertyValue("txt_replica_appIdInEachRow")),"Application Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-289:Searching based on Application ID- with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){
		
		try{
		ReplicaService.searchByApplicationID(driver, "xyzabc");
		Assert.assertTrue(ReplicaService.getRowCount(driver) == 0,"Search by applicationID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_applicationID"))).equals("xyzabc"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 *   Sync-290,291:Searching based on valid range of Start and End Date, Time
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByStartAndEndTime() throws Exception{
		
		// valid search by time format "mm/dd/yyyy hh:mm:ss"
		ReplicaService.searchByStartAndEndTime(driver, "07/23/2013 18:00:00", "07/23/2013 18:05:00");
		SeleniumUtil.waitForElement(driver, By.linkText("PersMSSql"));
		Assert.assertTrue(ReplicaService.getRowCount(driver) == 3,"Search by StartAndEndTime is not working");
		
	}
	
	
	 *   Sync-290,291:Searching based on invalid range of Start and End Date, Time
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByStartAndEndTime() throws Exception{
		
		// valid search by date time format "mm/dd/yyyy hh:mm:ss"
		ReplicaService.searchByStartAndEndTime(driver, "07/23/2013 00:00:00", "07/21/2013 00:00:00");
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_replicaService_SyncRecord")), "No records to show");
		Assert.assertTrue(ReplicaService.getRowCount(driver) == 0,"Search by StartAndEndTime is not working");
		
	}*/
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_replicaService_pageHeader")), "Replica Service"))
		{
			ReplicaService.searchByStartAndEndTime(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530");
		Assert.assertTrue(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530", "grid_replicaService", configObj.getPropertyValue("txt_replica_startTimeInEachRow"), configObj.getPropertyValue("txt_replica_endTimeInEachRow")),"Valid search for start and end time together is not working.");
	}
		else {
			Assert.fail("Replica service page is not obtained");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_replicaService_pageHeader")), "Replica Service"))
		{
			ReplicaService.searchByStartAndEndTime(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530");
		Assert.assertFalse(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530", "grid_replicaService", configObj.getPropertyValue("txt_replica_startTimeInEachRow"), configObj.getPropertyValue("txt_replica_endTimeInEachRow")),"Invalid search for start and end time together is not working.");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_startTime"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Replica Service page is not obtained");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByNoOfRows(){
		
		try{
		ReplicaService.searchByNoOfRows(driver,"1");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_replicaService"), "1", configObj.getPropertyValue("txt_replica_noOfRowsInEachRow")),"No. of rows search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByNoOfRows(){
		
		try{
		ReplicaService.searchByNoOfRows(driver,"1234567890");
		Assert.assertTrue(ReplicaService.getRowCount(driver) == 0," Invalid no. of rows search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_NoOfRows"))).equals("1234567890"), "Text in the search field is not cleared after refreshing");
		 
		 ReplicaService.searchByNoOfRows(driver, "abcxyz");
		 Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).toLowerCase().contains("must be number".toLowerCase()), "Error pop up is not shown when searched with non-numeric no.");
	     Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_NoOfRows"))).equals("abcxyz"), "Text in the search field is not cleared after clicking OK on alert box");		 
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Searching based on Sync Server IP- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncServerIP(){
		
		try{
		ReplicaService.searchBySyncServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_replicaService"), "0", configObj.getPropertyValue("txt_replica_syncServerIPInEachRow")),"Sync Server IP search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
   /*
	*   Searching based on Sync Server IP- with a invalid search text
	*/
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchBySyncServerIP(){
		
		try{
		ReplicaService.searchBySyncServerIP(driver, "abcxyz");
		Assert.assertTrue(ReplicaService.getRowCount(driver) == 0," Invalid Sync Server IP search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_replica_searchBy_SyncServerIP"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_replicaService"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_replicaService", By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_applicationID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	
	{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_startTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_endTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		
	}
	
	
	/*
	 * Verifying calendar for start time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForStartTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_replicaService_searchBy_startTime", "grid_replicaService", "start")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for end time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForEndtime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_replicaService_searchBy_endTime", "grid_replicaService", "end")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForStartTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_replicaService_searchBy_startTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForEndTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_replicaService_searchBy_endTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,1),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{ 
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test error details link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testErrorDetailsLink()
	{
		try{
		if(SeleniumUtil.isElementPresent(driver, By.linkText("View Error Details")))
		{
			SeleniumUtil.click(driver, By.linkText("View Error Details"));
			Assert.assertTrue(SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("win_modelWin"))).equalsIgnoreCase("Error Details"),"Error details pop up is not opened");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * verify page title
	 
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle() throws Exception{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_replicaService")), "page title is not appropriate");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "replicaService";
		
	}
	
	/*
	 * 
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_replicaService_searchBy_applicationID");
		
	}
	
	/*
	 * DEF617 - verify display of Application-config when the application id is clicked under replica tab.
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationConfigAfterDeleteAndCreateDEF617()
	{
		if(configObj.getPropertyValue("database").equalsIgnoreCase("MSSQL"))
		{
		try{
		Applications.navigateToApplicationsPage(driver);	
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")), "Persistent"+Keys.RETURN);
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_applications_searchBy_applicationid")));
	    addDbScripts();
		SeleniumUtil.delay(5000);
		ReplicaService.navigateToReplicaServicePage(driver);
		
		ReplicaService.searchByApplicationID(driver, "persistent");
		
		String parentWindow= driver.getWindowHandle();
		SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("link_replica_appId")));
		SeleniumUtil.delay(1000);
		Set<String> handles=driver.getWindowHandles();
		 for(String windowHandle  : handles)
	       {
	       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
	          {
	    	   driver.switchTo().window(windowHandle);
	    	   break;
	          }
	       }
		 Assert.assertTrue(driver.getPageSource().contains("AppID=\"Persistent\""),"config details are not shown");
		 driver.close();
	     driver.switchTo().window(parentWindow);
	     SeleniumUtil.delay(2000);
	     Applications.navigateToApplicationsPage(driver);
	     addDbScripts();
	        SeleniumUtil.delay(5000);
			ReplicaService.navigateToReplicaServicePage(driver);
			
			ReplicaService.searchByApplicationID(driver, "persistent");
			SeleniumUtil.delay(5000);
			
			parentWindow= driver.getWindowHandle();
			SeleniumUtil.click(driver,By.xpath(configObj.getPropertyValue("link_replica_appId")));
			SeleniumUtil.delay(1000);
			handles=driver.getWindowHandles();
			 for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   break;
		          }
		       }
			 Assert.assertTrue(driver.getPageSource().contains("AppID=\"Persistent\""),"config details are not shown");
			 driver.close();
		     driver.switchTo().window(parentWindow);
		     Applications.navigateToApplicationsPage(driver);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(SeleniumUtil.isElementPresent(driver, By.xpath("//button[@role='button']")))
			{
				SeleniumUtil.click(driver, By.xpath("//button[@role='button']"));
			}
			Applications.delete(driver, "Persistent");
		      }
		}
	}
	
	/*
	 * Used for adding persistent applications with DB scripts
	 */
	
	public void addDbScripts()
	{
		
		try{
		if(SeleniumUtil.isElementPresent(driver, By.linkText("Persistent"))){
			Applications.delete(driver, "Persistent");
		}
		ApplicationPublish.chooseFile(driver, "PersistentSampleSyncConfig.xml");
		ApplicationPublish.generatePersistentDBScripts(driver);
		ApplicationPublish.upload(driver);
		driver.switchTo().activeElement();
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_generatedDDLScripts")));
		SeleniumUtil.delay(6000);
		//Execute DDL scripts for Replica schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")));
		SeleniumUtil.delay(1000);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_replicaDBConfig_Pasword")), "kony123!");
		SeleniumUtil.delay(1000);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_replicaDBConfig_Execute")));
		SeleniumUtil.delay(8000);
		//Execute DDL scripts for Upload schema.
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")));
		SeleniumUtil.delay(1000);
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Username")), "sa");
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_uploadDBConfig_Password")), "kony123!");
		SeleniumUtil.delay(1000);
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_uploadDBConfig_Execute")));
		SeleniumUtil.delay(2000);
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_executedUploadDDLScripts")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("img_saveXML")));
		SeleniumUtil.delay(1000);
		//Click on the Done button.
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dbConfig_Done")));
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_replicaService", By.id(configObj.getPropertyValue("tbx_replicaService_searchBy_applicationID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_replicaService"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}

	