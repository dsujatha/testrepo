package com.kony.sync.console.webdriver.monitoring;

import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class SyncErrorsTest extends BaseTestcase{

	/**
	 * @param args
	 */
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void setUp() {
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_syncErrors_mainPage")));
			SyncErrors.navigateToSyncErrorsPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_syncErrors_pageHeader")), "Sync Errors");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Verifying of User ID Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUserIDLink(){
		
		try{
		SyncErrors.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			SyncErrors.clickOnLink(driver, "syncadmin");
			driver.switchTo().activeElement();
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userID")), "syncadmin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userName")), "Sync Admin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userEmail")), "syncadmin@konylabs.com"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_Mobile")), "1234567890"));
			
		}else{
			Assert.fail("User ID not found.");
		}
	}
		catch(Exception e){
		e.printStackTrace();	
		}
		
	}
	
	/*
	 * Verify Application Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
		   SyncErrors.searchByApplicationID(driver, "PersMSSql");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_applicationID")));
			if(SeleniumUtil.isElementPresent(driver, By.linkText("PersMSSql"))){
				String parentWindow= driver.getWindowHandle();
				SyncErrors.clickOnLink(driver, "PersMSSql");
				SeleniumUtil.delay(1000);
				Set<String> handles=driver.getWindowHandles();
				Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
				
				 for(String windowHandle  : handles)
			       {
			       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
			          {
			    	   driver.switchTo().window(windowHandle);
			    	   driver.close();
			    	   break;
			          }
			       }
			         driver.switchTo().window(parentWindow); //cntrl to parent window
				
			}else{
				Assert.fail("Application ID not found.");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searching based on User ID - with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByUserID(){
		
		try{
		SyncErrors.searchByUserID(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_syncErrors"), "sync", configObj.getPropertyValue("txt_syncErrors_userIdInEachRow")),"User Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searching based on User ID - with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByUserID(){
		
		try{
		SyncErrors.searchByUserID(driver, "abcxyz");
		Assert.assertTrue(SyncErrors.getRowCount(driver) == 0,"Search by userID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_userID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Searching based on Application ID- with a valid search text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		SyncErrors.searchByApplicationID(driver, "PersMSSql");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_syncErrors"), "PersMSSql", configObj.getPropertyValue("txt_syncErrors_applicationIdInEachRow")),"Search by applicationId is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searching based on Application ID- with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){
		
		try{
		SyncErrors.searchByApplicationID(driver, "xyzabcd");
		Assert.assertTrue(SyncErrors.getRowCount(driver) == 0,"Search by applicationId is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_applicationID"))).equals("xyzabcd"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	

	/*
	 * Searching based on SyncOperation- with a valid search text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncOperation(){
		
		try{
		SyncErrors.searchBySyncOperation(driver, "SERVICE");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_syncErrors"), "SERVICE", configObj.getPropertyValue("txt_syncErrors_syncOperationInEachRow")),"Search by txt_syncErrors_syncOperation is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 * Searching based on SyncOperation- with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchBySyncOperation(){
		
		try{
		SyncErrors.searchBySyncOperation(driver, "xyzabcd");
		Assert.assertTrue(SyncErrors.getRowCount(driver) == 0,"Search by SyncOperation is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_syncOperation"))).equals("xyzabcd"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Searching based on Sync Server IP- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncServerIP(){
		
		try{
		SyncErrors.searchBySyncServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_syncErrors"), "0", configObj.getPropertyValue("txt_syncErrors_syncServerIPInEachRow")),"Sync Server IP search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
   /*
	*   Searching based on Sync Server IP- with a invalid search text
	*/
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchBySyncServerIP(){
		
		try{
		SyncErrors.searchBySyncServerIP(driver, "abcxyz");
		Assert.assertTrue(SyncErrors.getRowCount(driver) == 0," Invalid Sync Server IP search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_SyncServerIP"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	 /*
	  * Searching based on invalid range of date Time
	  */
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidDateTime(){
		
		try{
		SyncErrors.searchByDateTime(driver, "08/14/2030 00:00:00 +0530");
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_noRecordsToShow")), "No records to show");
		Assert.assertTrue(SyncErrors.getRowCount(driver) == 0,"Search by SyncErrors data time is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_dateTime"))).contains("08/14/2030 00:00:00"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/* 
	 * Searching based on valid date Time
	 */
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchDateTime(){
		
		try{
		SyncErrors.searchByDateTime(driver,"07/23/2013 18:00:00 +0530");
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		Assert.assertTrue(SeleniumUtil.verifyInitialDateTimeSearch(driver, "07/23/2013 18:00:00 +0530", "grid_syncErrors", configObj.getPropertyValue("txt_syncErrors_dateTimeInEachRow")),"Valid search for date time is not working.");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_syncErrors"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_syncErrors", By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_dateTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar for Sync errors date time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarFordateTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_syncErrors_searchBy_dateTime", "grid_syncErrors", "start")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForDateTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_syncErrors_searchBy_dateTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,1),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test error details link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testErrorDetailsLink()
	{
		try{
			if(SeleniumUtil.isElementPresent(driver, By.linkText("View Error Details")))
			{
				SeleniumUtil.click(driver, By.linkText("View Error Details"));
				Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("win_modelWin"))).equalsIgnoreCase("Error Details"),"Error details pop up is not opened");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "syncErrors";
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_syncErrors_searchBy_userID");
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_syncErrors", By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_syncErrors"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
