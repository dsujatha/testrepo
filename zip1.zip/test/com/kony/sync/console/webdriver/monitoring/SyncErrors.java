package com.kony.sync.console.webdriver.monitoring;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class SyncErrors extends BaseTestcase{

	/**
	 * @param args
	 */
	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	public static void navigateToSyncErrorsPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_syncErrors_mainPage")));
			}catch(Exception e){
				e.printStackTrace();
			}
		
	}
	
public static void clickOnLink(WebDriver driver, String linkName){
		
		try{
			SeleniumUtil.click(driver, By.linkText(linkName));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

/**
 * search by user id
 * @param driver
 * @param searchKey
 */

public static void searchByUserID(WebDriver driver, String searchKey){

	try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_userID")), searchKey+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	}catch(Exception e){
		e.printStackTrace();
	}

}

/**
 * search by application id
 * @param driver
 * @param searchKey
 */

public static void searchByApplicationID(WebDriver driver, String searchKey){

	try{

		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_applicationID")), searchKey+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

	}catch(Exception e){
		e.printStackTrace();
	}

}

/**
 * search by sync operation
 * @param driver
 * @param searchKey
 */

public static void searchBySyncOperation(WebDriver driver, String searchKey){

	try{

		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_syncOperation")), searchKey+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

	}catch(Exception e){
		e.printStackTrace();
	}

}

/**
 * search by Sync Server IP
 * @param driver
 * @param searchKey
 */

public static void searchBySyncServerIP(WebDriver driver, String searchKey){

	try{
		
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_SyncServerIP")), searchKey+Keys.RETURN);
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

/**
 * search by date time
 * @param driver
 * @param dateTime
 */

public static void searchByDateTime(WebDriver driver, String dateTime){
	
	try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_dateTime")));
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_syncErrors_searchBy_dateTime")), dateTime);
		// close the calendar control
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_syncErrors_calender_Done")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

/**
 * get numbers of rows present in the Sync Errors table
 * @param driver
 * @return count of rows
 */

public static int getRowCount(WebDriver driver){
	
	rowElements = null;
	try{
	
		WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_syncErrors")));
		rowElements = table.findElements(By.tagName("tr"));
	
	}catch(Exception e){
		e.printStackTrace();
	}
	return rowElements.size() - 1;
}

}
