package com.kony.sync.console.webdriver.monitoring;

import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class ConflictsTest extends BaseTestcase{

	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_conflicts_mainPage")));
			Conflicts.navigateToConflictsPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_conflicts_pageHeader")), "Conflict");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-299.a:Verifying of User ID Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUserIDLink(){
		
		try{
		Conflicts.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			Conflicts.clickOnLink(driver, "syncadmin");
			driver.switchTo().activeElement();
			// verify user details like user id, username, email, mobile
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userID")), "syncadmin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userName")), "Sync Admin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userEmail")), "syncadmin@konylabs.com"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_Mobile")), "1234567890"));
			
		}else{
			Assert.fail("User ID not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * 	Sync-299.b:Verify Device ID link 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeviceIDLink(){
		
		try{
		Conflicts.searchByDeviceID(driver, "000000000000000");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_deviceID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("000000000000000"))){
			
			Conflicts.clickOnLink(driver, "000000000000000");
			driver.switchTo().activeElement();
			// verify user details like device id, device OS, device Model, device OS version
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceID")), "000000000000000"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceOS")), "android"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceModel")), "google_sdk"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceVersion")), "2.2"));
			
		}else{
			Assert.fail("Device ID not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-299.c:Verify Application Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
			Conflicts.searchByApplicationID(driver, "PersMSSql");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_applicationID")));
			if(SeleniumUtil.isElementPresent(driver, By.linkText("PersMSSql"))){
				String parentWindow= driver.getWindowHandle();
				Conflicts.clickOnLink(driver, "PersMSSql");
				SeleniumUtil.delay(1000);
				Set<String> handles=driver.getWindowHandles();
				Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
				
				 for(String windowHandle  : handles)
			       {
			       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
			          {
			    	   driver.switchTo().window(windowHandle);
			    	   driver.close();
			    	   break;
			          }
			       }
			         driver.switchTo().window(parentWindow);
				
			}else{
				Assert.fail("Application ID not found.");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-299.d:Verify Client Row Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testClientRowLink(){
		
		try{
		Conflicts.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			//clicking the first view link in the client row column 
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_conflicts_clientRow")));
			driver.switchTo().activeElement();
			// verify category details like Picture,Description,CategoryName,CategoryID,konysyncClientCategoryID,konysynchashsum
			SeleniumUtil.waitForElement(driver, By.tagName("pre"));
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.tagName("pre")).isEmpty(),"Client row details are not available");
		}else{
			Assert.fail("Client Row Link is not found.");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-299.e:Verify Server Row Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testServerRowLink(){
		
		try{
		Conflicts.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			//clicking the first view link in the server row column 
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_conflicts_serverRow")));
			driver.switchTo().activeElement();
			// verify category details like Picture,Description,CategoryName,CategoryID,SoftDeleteFlag,LastUpdateTime
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.tagName("pre")).isEmpty(),"Server row details are not present");
		}else{
			Assert.fail("Server row link is not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-299.f:Verify Merged Row Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testMergedRowLink(){
		
		try{
		Conflicts.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			//clicking the first view link in the Merged row column 
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_conflicts_mergedRow")));
			driver.switchTo().activeElement();
			// verify category details like Picture,Description,CategoryName,CategoryID,konysyncClientCategoryID,konysynchashsum
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.tagName("pre")).isEmpty(),"Merged row details are not present");
		}else{
			Assert.fail("Merged row link is not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Searching based on User ID - with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByUserID(){
		
		try{
		Conflicts.searchByUserID(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_conflicts"), "sync", configObj.getPropertyValue("txt_conflicts_userIdInEachRow")),"User Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searching based on User ID - with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByUserID(){
		
		try{
		Conflicts.searchByUserID(driver, "abcxyz");
		Assert.assertTrue(Conflicts.getRowCount(driver) == 0,"Search by userID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searching based on Device ID - with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByDeviceID(){
		
		try{
		Conflicts.searchByDeviceID(driver, "000000000000000");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_conflicts"), "000000000000000", configObj.getPropertyValue("txt_conflicts_deviceIdInEachRow")),"Valid Search of device ID is not working as expected.");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searching based on Device ID - with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchByDeviceID(){
		
		try{
		Conflicts.searchByDeviceID(driver, "1234567890");
		Assert.assertTrue(Conflicts.getRowCount(driver) == 0,"Search by deviceID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_deviceID"))).equals("1234567890"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-300:Searching based on Application ID- with a valid search text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		Conflicts.searchByApplicationID(driver, "PersMSSql");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_conflicts"), "PersMSSql", configObj.getPropertyValue("txt_conflicts_applicationIdInEachRow")),"Search by applicationId is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 * Sync-300:Searching based on Application ID- with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){
		
		try{
		Conflicts.searchByApplicationID(driver, "xyzabcd");
		Assert.assertTrue(Conflicts.getRowCount(driver) == 0,"Search by applicationId is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_applicationID"))).equals("xyzabcd"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Searching based on Sync Server IP- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncServerIP(){
		
		try{
		Conflicts.searchBySyncServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_conflicts"), "0", configObj.getPropertyValue("txt_conflicts_syncServerIPInEachRow")),"Sync Server IP search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
   /*
	*   Searching based on Sync Server IP- with a invalid search text
	*/
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchBySyncServerIP(){
		
		try{
		Conflicts.searchBySyncServerIP(driver, "abcxyz");
		Assert.assertTrue(Conflicts.getRowCount(driver) == 0," Invalid Sync Server IP search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_SyncServerIP"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Searching based on valid conflict Time
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidConflictTime() throws Exception{
		
		// valid search by time format "mm/dd/yyyy hh:mm:ss"
		Conflicts.searchByConflictTime(driver,"07/23/2013 18:00:00");
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		Assert.assertTrue(Conflicts.getRowCount(driver) == 2,"Search by ConflictTime is not working");
		
	}
	*/
	
	 /*
	  * Searching based on invalid range of conflict Time
	  */
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidConflictTime(){
		
		try{
		// valid search by date time format "mm/dd/yyyy hh:mm:ss"
		Conflicts.searchByConflictTime(driver, "08/14/2030 00:00:00 +0530");
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_conflicts_SyncRecord")), "No records to show");
		Assert.assertTrue(Conflicts.getRowCount(driver) == 0,"Search by ConflictTime is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_conflictTime"))).contains("08/14/2030 00:00:00"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/* 
	 * Searching based on valid conflict Time
	 */
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchConflictTime(){
		
		try{
		// valid search by time format "mm/dd/yyyy hh:mm:ss"
		Conflicts.searchByConflictTime(driver,"07/23/2013 18:00:00 +0530");
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		Assert.assertTrue(SeleniumUtil.verifyInitialDateTimeSearch(driver, "07/23/2013 18:00:00 +0530", "grid_conflicts", configObj.getPropertyValue("txt_conflicts_conflictTimeInEachRow")),"Valid search for conflict time is not working.");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	/*
	 * Searching based on conflict resolution policy with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByConflictResolutionPolicy(){
		
		try{
		Conflicts.searchByConflictResolutionPolicy(driver, "CLIENT_WINS");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_conflicts"), "CLIENT_WINS", configObj.getPropertyValue("txt_conflicts_conflictResPolInEachRow")),"Search by conflict resolution policy is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 * Searching based on conflict resolution policy with an invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByConflictResolutionPolicy(){
		
		try{
		Conflicts.searchByConflictResolutionPolicy(driver, "xyzabc");
		Assert.assertTrue(Conflicts.getRowCount(driver) == 0,"Search by ConflictResolutionPolicy is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_conflictResolutionPolicy"))).equals("xyzabc"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_conflicts"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_conflicts", By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_conflictTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for conflict time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForConflictTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_conflicts_searchBy_conflictTime", "grid_conflicts", "start")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForConflictTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_conflicts_searchBy_conflictTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,1),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 *test error details link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testErrorDetailsLink()
	{
		try{
			if(SeleniumUtil.isElementPresent(driver, By.linkText("View Error Details")))
			{
				SeleniumUtil.click(driver, By.linkText("View Error Details"));
				Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_conflicts_errorDetailsWin"))).equalsIgnoreCase("Error Details"),"Error details pop up is not opened");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * verify page title
	 
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle() throws Exception{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_conflicts")), "page title is not appropriate");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return "conflicts";
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return configObj.getPropertyValue("tbx_conflicts_searchBy_userID");
	}
	
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_conflicts", By.id(configObj.getPropertyValue("tbx_conflicts_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_conflicts"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
