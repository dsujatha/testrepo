package com.kony.sync.console.webdriver.monitoring;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class SyncPerformance extends BaseTestcase{
	
	public static void navigateToSyncPerformancePage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_syncPerformance_mainPage")));
			}catch(Exception e){
				e.printStackTrace();
			}
		
	}
	
public static void clickOnLink(WebDriver driver, String linkName){
		
		try{
			driver.findElement(By.linkText(linkName)).click();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

public static boolean verifyNavigationOfPages(WebDriver driver){
	
	  try{
	  int totalNoOfPages=(Integer.parseInt(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_totalNoOfPages")))));
	  if(totalNoOfPages>1)
	  {
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_lastPage")));
		  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading"))); 
		  String pageInfo =  SeleniumUtil.getVisibleText(driver, By.className(configObj.getPropertyValue("txt_pageInfo"))).trim().replaceAll("\\s+", "");
	  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
		List<Integer> result = new ArrayList<Integer>();
		if (matcher.find()) {
			do {
				result.add(Integer.parseInt(matcher.group(0)));
			} while (matcher.find());
		}
	  int noOfRecords=result.get(2);
	  Assert.assertTrue(noOfRecords==result.get(1), "All the records are not fetched even after moving to the last page");
	 Assert.assertTrue(totalNoOfPages==(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo"))))),"Page is not able to navigate to the last page");

	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_nextPage"))), "Next button is not disabled even after reaching the final page");
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_lastPage"))), "Last button is not disabled even after reaching the final page");
	  
	  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_firstPage")));
	  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_previousPage"))), "Previous button is not disabled even after reaching the first page");
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_firstPage"))), "First button is not disabled even after reaching the first page");
	  }
	  else{
		  Assert.fail("Enough no. of records are not there, so navigation of pages cannot be tested");
		  return false;
	  }
	  return true;
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
		  return false;
	  }
	  
}


public static boolean verifyNavigationOfPagesBottom(WebDriver driver){
	
	  try{
	  int totalNoOfPages=(Integer.parseInt(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_totalNoOfPages_bottom")))));
	  if(totalNoOfPages>1)
	  {
		  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_lastPage_bottom")));
		  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading"))); 
		  String pageInfo =  SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_pageInfo_bottom"))).trim().replaceAll("\\s+", "");
	  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
		List<Integer> result = new ArrayList<Integer>();
		if (matcher.find()) {
			do {
				result.add(Integer.parseInt(matcher.group(0)));
			} while (matcher.find());
		}
	  int noOfRecords=result.get(2);
	  Assert.assertTrue(noOfRecords==result.get(1), "All the records are not fetched even after moving to the last page");
	 Assert.assertTrue(totalNoOfPages==(Integer.parseInt(SeleniumUtil.getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom"))))),"Page is not able to navigate to the last page");
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_nextPage_bottom"))), "Next button is not disabled even after reaching the final page");
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_lastPage_bottom"))), "Last button is not disabled even after reaching the final page");
	  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_firstPage_bottom")));
	  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_previousPage_bottom"))), "Previous button is not disabled even after reaching the first page");
	  Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_firstPage_bottom"))), "First button is not disabled even after reaching the first page");
	  }
	  else{
		  Assert.fail("Enough no. of records are not there, so navigation of pages cannot be tested");
		  return false;
	  }
	  return true;
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
		  return false;
	  }
}

}
