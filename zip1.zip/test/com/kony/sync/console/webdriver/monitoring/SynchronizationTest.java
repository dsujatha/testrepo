package com.kony.sync.console.webdriver.monitoring;


import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class SynchronizationTest extends BaseTestcase{

	@BeforeTest
	public void loadDriver() {
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeMethod
	public void setUp() {
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Synchronization"));
			Synchronization.navigateToSynchronizationPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_synchronization_pageHeader")), "Synchronization");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-269, DEF215:Searching based on User ID- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByUserIDDEF215(){
		
		try{
		Synchronization.searchByUserID(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_synchronization"), "sync", configObj.getPropertyValue("txt_synchronization_userIdInEachRow")),"User Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-269:Searching based on User ID- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByUserID(){
		
		try{
		Synchronization.searchByUserID(driver, "xyz");
		Assert.assertTrue(Synchronization.getRowCount(driver) == 0,"Invalid User Id search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-269:Searching based on Device ID- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByDeviceID(){
		
		try{
		Synchronization.searchByDeviceID(driver, "000");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_synchronization"), "000", configObj.getPropertyValue("txt_synchronization_deviceIdInEachRow")),"Device Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*
 *   Sync-269:Searching based on Device ID- with a invalid search text
 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchByDeviceID(){
		
		try{
		Synchronization.searchByDeviceID(driver, "101019");
		Assert.assertTrue(Synchronization.getRowCount(driver) == 0," Invalid Device Id search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_deviceID"))).equals("101019"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Sync-270:Searching based on Application ID- with a valid search text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		Synchronization.searchByApplicationID(driver, "pers");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_synchronization"), "pers", configObj.getPropertyValue("txt_synchronization_appIdInEachRow")),"Application Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-270:Searching based on Application ID- with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){
		
		try{
		Synchronization.searchByApplicationID(driver, "abcxyz");
		Assert.assertTrue(Synchronization.getRowCount(driver) == 0,"Invalid application Id search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_applicationID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Searching based on Sync Server IP- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncServerIP(){
		
		try{
		Synchronization.searchBySyncServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_synchronization"), "0", configObj.getPropertyValue("txt_synchronization_SyncServerIPInEachRow")),"Sync Server IP search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
   /*
	*   Searching based on Sync Server IP- with a invalid search text
	*/
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchBySyncServerIP(){
		
		try{
		Synchronization.searchBySyncServerIP(driver, "abcxyz");
		Assert.assertTrue(Synchronization.getRowCount(driver) == 0," Invalid Sync Server IP search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_SyncServerIP"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 *   Sync-271:Searching based on valid range of Start and End Date, Time
	 */
/*	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByStartTime() throws Exception{
		
		// valid search by time format "mm/dd/yyyy hh:mm:ss"
		Synchronization.searchByStartAndEndTime(driver, "07/23/2013 18:00:00", "07/23/2013 18:05:00");
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		Assert.assertTrue(Synchronization.getRowCount(driver) == 3);
		
	}*/
		
	/*
	 *   Sync-271:Searching based on valid range of Start and End Date, Time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_synchronization_pageHeader")), "Synchronization"))
		{
			Synchronization.searchByStartAndEndTime(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530");
		Assert.assertTrue(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530", "grid_synchronization", configObj.getPropertyValue("txt_synchronization_startTimeInEachRow"), configObj.getPropertyValue("txt_synchronization_endTimeInEachRow")),"Valid search for start and end time together is not working.");
		}
		else {
			Assert.fail("Synchronization page is not obtained");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-271:Searching based on invalid range of Start and End Date, Time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_synchronization_pageHeader")), "Synchronization"))
		{
			Synchronization.searchByStartAndEndTime(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530");
		Assert.assertFalse(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530", "grid_synchronization", configObj.getPropertyValue("txt_synchronization_startTimeInEachRow"), configObj.getPropertyValue("txt_synchronization_endTimeInEachRow")),"Invalid search for start and end time together is not working.");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_startTime"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Synchronization page is not obtained");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_synchronization"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	/*
	 *   Sync-271:Searching based on invalid range of Start and End Date, Time
	 */
	
	/*@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByStartTime() throws Exception{
		
		// valid search by date time format "mm/dd/yyyy hh:mm:ss"
		Synchronization.searchByStartAndEndTime(driver, "07/21/2013 00:00:00", "07/22/2013 00:00:00");
		System.out.println(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_synchronization_SyncRecord")), "No records to show"));
		Assert.assertTrue(Synchronization.getRowCount(driver) == 0);
		
	}*/
	
	/*
	 *   Sync-268.a:Verify User ID link 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUserIDLink(){
		
		Synchronization.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			Synchronization.clickOnLink(driver, "syncadmin");
			driver.switchTo().activeElement();
			try{
			// verify user details like user id, username, email, mobile
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userID")), "syncadmin"));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userName")), "Sync Admin"));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userEmail")), "syncadmin@konylabs.com"));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_Mobile")), "1234567890"));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id("ok")),"close button is not available");
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))),"pop up close button at right corner is not available");
			SeleniumUtil.click(driver, By.id("ok"));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("win_synchronization_userdetails"))), "User details pop is not closed yet");
			Synchronization.searchByUserID(driver, "sync");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID")));
			Synchronization.clickOnLink(driver, "syncadmin");
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("win_synchronization_userdetails")+"/span")), "User details pop is not closed yet");
			}
			catch(Exception e){
				if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				}
			}
			
		}else{
			Assert.fail("User ID not found.");
		}
		
	}
	
	
	/*
	 * 	Sync-268.b:Verify Device ID link 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeviceIDLink(){
		
		Synchronization.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			Synchronization.clickOnLink(driver, "000000000000000");
			driver.switchTo().activeElement();
			try{
			// verify user details like device id, device OS, device Model, device OS version
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceID")), "000000000000000"));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceOS")), "android"));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceModel")), "google_sdk"));
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceVersion")), "2.2"));
			
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id("ok")),"close button is not available");
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))),"pop up close button at right corner is not available");
			SeleniumUtil.click(driver, By.id("ok"));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("win_synchronization_deviceDetails"))), "User details pop is not closed yet");
			Synchronization.searchByUserID(driver, "sync");
			SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID")));
			Synchronization.clickOnLink(driver, "000000000000000");
			
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
			Assert.assertFalse(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("win_synchronization_deviceDetails"))), "User details pop is not closed yet");
			}
			catch(Exception e){
				if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))))
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
				}
			}
			
		}else{
			Assert.fail("Device ID not found.");
		}
		
	}
	
	/*
	 * Sync-268.a:Verify Application Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
		Synchronization.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			String parentWindow= driver.getWindowHandle();
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_synchronization_appId")));
			SeleniumUtil.delay(1000);
			Set<String> handles=driver.getWindowHandles();
			Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
			
			 for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow); //cntrl to parent window
			
		}else{
			Assert.fail("Application ID not found.");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_synchronization", By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_startTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_endTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for RegistrationTime
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForRegistrationTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_synchronization_searchBy_startTime", "grid_synchronization", "start")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for end time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForEndTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_synchronization_searchBy_endTime", "grid_synchronization", "end")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForRegistrationTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_synchronization_searchBy_startTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on end time field to check the presence of calendar
	 */
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForEndTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_synchronization_searchBy_endTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,2),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test error details link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testErrorDetailsLink()
	{
		
		try{
		if(SeleniumUtil.isElementPresent(driver, By.linkText("View Error Details")))
			
		{
			SeleniumUtil.click(driver, By.linkText("View Error Details"));
			Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("win_modelWin"))).equalsIgnoreCase("Error Details"),"Error details pop up is not opened");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "synchronization";
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return configObj.getPropertyValue("tbx_synchronization_searchBy_userID");
		
	}
	
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_synchronization", By.id(configObj.getPropertyValue("tbx_synchronization_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_synchronization"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be displayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
	