package com.kony.sync.console.webdriver.monitoring;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class SecurityAudit extends BaseTestcase{
	
	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	public static void navigateToSecurityAuditPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_securityAudit_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by 'who changed'
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByWhoChanged(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whoChanged")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * search by 'what changed'
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByWhatChanged(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whatChanged")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * get numbers of rows present in the securityAudit table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{

			WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_securityAudit")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
		
	}
	
	/**
	 * search by 'when' time
	 * @param driver
	 * @param date time
	 */
	
	public static void searchByWhenDateTime(WebDriver driver, String whenDateTime){

		try{
			// wait for Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whenDateTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_whenDateTime")), whenDateTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_securityAudit_calender_Done")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by 'comments'
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByComments(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_securityAudit_searchBy_comments")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
