package com.kony.sync.console.webdriver.monitoring;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class ChangeReplay extends BaseTestcase{
	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	public static void navigateToChangeReplayPage(WebDriver driver){

		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_changeReplay_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public static void clickOnLink(WebDriver driver, String linkName){

		try{
			SeleniumUtil.click(driver, By.linkText(linkName));
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by user id
	 * @param driver
	 * @param searchKey
	 */

	public static void searchByUserID(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_userID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by device id
	 * @param driver
	 * @param searchKey
	 */

	public static void searchByDeviceID(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_deviceID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by application id
	 * @param driver
	 * @param searchKey
	 */

	public static void searchByApplicationID(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_applicationID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * get numbers of rows present in the changeReplay table
	 * @param driver
	 * @return count of rows
	 */

	public static int getRowCount(WebDriver driver){

		rowElements = null;
		try{

			WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_changeReplay")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;

	}

	/**
	 * search by request id
	 * @param driver
	 * @param searchKey
	 */

	public static void searchByRequestID(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_requestID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by Sync Server IP
	 * @param driver
	 * @param searchKey
	 */

	public static void searchBySyncServerIP(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_cReplay_searchBy_SyncServerIP")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by start and end date time
	 * @param driver
	 * @param startTime
	 * @param endTime
	 */

	public static void searchByStartAndEndTime(WebDriver driver, String startTime, String endTime){

		try{
			// wait for Start Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_startTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_startTime")), startTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changeReplay_calender_Done")));
			// wait for the date and time to appear in the Start Time text box

			// wait for End Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_endTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_endTime")), endTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_changeReplay_calender_Done")));
			// wait for the date and time to appear in the Start Time text box
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by Target
	 * @param driver
	 * @param searchKey
	 */

	public static void searchByTarget(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_target")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by Type
	 * @param driver
	 * @param searchKey
	 */

	public static void searchByType(WebDriver driver, String searchKey){

		try{
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_changeReplay_searchBy_type")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
