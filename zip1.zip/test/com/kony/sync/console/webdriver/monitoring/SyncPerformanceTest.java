package com.kony.sync.console.webdriver.monitoring;

import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class SyncPerformanceTest extends BaseTestcase{
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Sync Performance"));
			SyncPerformance.navigateToSyncPerformancePage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_syncPerformance_pageHeader")), "Sync Performance");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
			
	}
	
	/*
	 *   Sync-275.a:Verifying of User ID Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUserIDLink(){
		
		try{
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			SyncPerformance.clickOnLink(driver, "syncadmin");
			driver.switchTo().activeElement();
			// verify user details like user id, username, email, mobile
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userID")), "syncadmin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userName")), "Sync Admin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userEmail")), "syncadmin@konylabs.com"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_Mobile")), "1234567890"));
			
		}else{
			Assert.fail("User ID not found.");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-275.b:Verifying of Device ID Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testDeviceIDLink(){
		
		try{
			SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			SyncPerformance.clickOnLink(driver, "000000000000000");
			driver.switchTo().activeElement();
			// verify user details like device id, device OS, device Model, device OS version
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceID")), "000000000000000"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceOS")), "android"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceModel")), "google_sdk"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_DeviceDwin_deviceVersion")), "2.2"));
			
		}else{
			Assert.fail("Device ID not found.");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-275.c:Verifying of Application ID Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_syncPerformance_appId")));
			SeleniumUtil.delay(1000);
			String parentWindow= driver.getWindowHandle();
			Set<String> availableWindows=driver.getWindowHandles();
			Assert.assertTrue(availableWindows.size() == 2);
			
			for(String windowHandle  : availableWindows)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow);
			
		}else{
			Assert.fail("Application ID not found.");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_syncPerformance"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SyncPerformance.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * verify sorting of data - checks whether data is changing on the click of column name
	 
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,1),"Data is not sorted on the click of column name");
	}*/
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{

		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
/*	
	 * verify page title
	 
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle() throws Exception{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_syncPerformance")), "page title is not appropriate");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		
		return "syncPerformance";
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		
		return null;
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_syncPerformance"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SyncPerformance.verifyNavigationOfPagesBottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be displayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
