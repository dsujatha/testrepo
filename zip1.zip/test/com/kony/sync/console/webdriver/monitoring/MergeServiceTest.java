package com.kony.sync.console.webdriver.monitoring;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class MergeServiceTest extends BaseTestcase {
	
	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@BeforeMethod
	public void setUp(){
		
		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText("Merge Service"));
			MergeService.navigateToMergeServicePage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_mergeservice_pageHeader")), "Merge Service");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 * Sync-281:Searching based on User ID- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByUserID(){
		
		try{
		MergeService.searchByUserID(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_mergeservice"), "sync", configObj.getPropertyValue("txt_merge_userIdInEachRow")),"User Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Sync-281:Searching based on User ID- with invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByUserID(){
		
		try{
		MergeService.searchByUserID(driver, "xyz");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0,"Invalid User Id search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_userID"))).equals("xyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-281:Searching based on Request ID- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByRequestID(){
		
		try{
		MergeService.searchByRequestID(driver, "1");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_mergeservice"), "1", configObj.getPropertyValue("txt_merge_requestIdInEachRow")),"Request Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
   /*
    *   Sync-281:Searching based on Request ID- with a invalid search text
    */
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchByRequestID(){
		
		try{
		MergeService.searchByRequestID(driver, "11100000");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0, "Invalid Request Id search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_requestID"))).equals("11100000"), "Text in the search field is not cleared after refreshing");
		 
		MergeService.searchByRequestID(driver, "abcxyz");
		Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).toLowerCase().contains("must be number".toLowerCase()), "Error pop up is not shown when searched with non-numeric no.");
        Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_requestID"))).equals("abcxyz"), "Text in the search field is not cleared after clicking OK on alert box");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		 
	}
	
	/*
	 *  Sync-281:Searching based on Application ID- with a valid search text 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){
		
		try{
		MergeService.searchByApplicationID(driver, "pers");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_mergeservice"), "pers", configObj.getPropertyValue("txt_merge_appIdInEachRow")),"Application Id search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 *   Sync-281:Searching based on Application ID- with a invalid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){
		
		try{
		MergeService.searchByApplicationID(driver, "abcxyz");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0,"Invalid application Id search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_applicationID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/*
	 *  Sync-282:Searching based on Merge status with valid text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByMergedStatus(){
		
		try{
		MergeService.searchByMergedStatus(driver,"MERGED");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_mergeservice"), "MERGED", configObj.getPropertyValue("txt_merge_statusInEachRow")),"Merged search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 *  Sync-282:Searching based on Merge status with invalid text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByMergedStatus(){
		
		try{
		MergeService.searchByMergedStatus(driver,"abcxyz");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0,"Invalid Merged search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_MergedStatus"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Sync-282:Searching based on number of rows with valid text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByNoOfRows(){
		
		try{
		MergeService.searchByNoOfRows(driver,"1");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_mergeservice"), "1", configObj.getPropertyValue("txt_merge_noOfRowsInEachRow")),"No. of rows search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	/*
	 *  Sync-282:Searching based on number of rows with invalid text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByNoOfRows(){
		
		try{
		MergeService.searchByNoOfRows(driver,"1234567890");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0," Invalid no. of rows search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_NoOfRows"))).equals("1234567890"), "Text in the search field is not cleared after refreshing");
		 
		 MergeService.searchByNoOfRows(driver, "abcxyz");
		 Assert.assertTrue(SeleniumUtil.closeAlertBoxAndGetItsText(driver).toLowerCase().contains("must be number".toLowerCase()), "Error pop up is not shown when searched with non-numeric no.");
	     Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_NoOfRows"))).equals("abcxyz"), "Text in the search field is not cleared after clicking OK on alert box");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		 
	}
	
	/*
	 *  Searching based on Sync Server IP- with a valid search text
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchBySyncServerIP(){
		
		try{
		MergeService.searchBySyncServerIP(driver, "0");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_mergeservice"), "0", configObj.getPropertyValue("txt_merge_syncServerIPInEachRow")),"Sync Server IP search is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
   /*
	*   Searching based on Sync Server IP- with a invalid search text
	*/
	
	@Test(enabled=true, timeOut=300000)
	public void testInvalidSearchBySyncServerIP(){
		
		try{
		MergeService.searchBySyncServerIP(driver, "abcxyz");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0," Invalid Sync Server IP search is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_merge_searchBy_SyncServerIP"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-284,285:Searching based on valid range of Start and End Date, Time
	 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByStartandEndTime() throws Exception{
		
		// valid search by time format "mm/dd/yyyy hh:mm:ss"
		MergeService.searchByStartAndEndTime(driver, "07/23/2013 18:00:00", "07/23/2013 18:05:00");
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		Assert.assertTrue(MergeService.getRowCount(driver) == 1);
		
	}
	
	
	 *   Sync-284,285:Searching based on invalid range of Start and End Date, Time
	 
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByStartandEndTime() throws Exception{
		
		// valid search by date time format "mm/dd/yyyy hh:mm:ss"
		MergeService.searchByStartAndEndTime(driver, "07/21/2013 00:00:00", "07/22/2013 00:00:00");
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_mergeservice_SyncRecord")), "No records to show");
		Assert.assertTrue(MergeService.getRowCount(driver) == 0);
		
	}*/
	
	
	/*
	 *   Sync-271:Searching based on valid range of Start and End Date, Time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_mergeservice_pageHeader")), "Merge Service"))
		{
			MergeService.searchByStartAndEndTime(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530");
		Assert.assertTrue(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530", "grid_mergeservice", configObj.getPropertyValue("txt_merge_startTimeInEachRow"), configObj.getPropertyValue("txt_merge_endTimeInEachRow")),"Valid search for start and end time together is not working.");
		}
		else {
			Assert.fail("Merge service page is not obtained");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *   Sync-271:Searching based on valid range of Start and End Date, Time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_mergeservice_pageHeader")), "Merge Service"))
		{
			MergeService.searchByStartAndEndTime(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530");
		Assert.assertFalse(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "03/23/2030 20:27:45 +0530", "07/23/2012 17:47:38 +0530", "grid_mergeservice", configObj.getPropertyValue("txt_merge_startTimeInEachRow"), configObj.getPropertyValue("txt_merge_endTimeInEachRow")),"Invalid search for start and end time together is not working.");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_startTime"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");
	}
		else {
			Assert.fail("Merge Service page is not obtained");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 *   Sync-281:Verify User ID link 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testUserIDLink(){
		
		try{
		SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_userID")), "syncadmin"+Keys.RETURN);	
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){
			
			MergeService.clickOnLink(driver, "syncadmin");
			driver.switchTo().activeElement();
			// verify user details like user id, username, email, mobile
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userID")), "syncadmin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userName")), "Sync Admin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_userEmail")), "syncadmin@konylabs.com"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_userDwin_userD_Mobile")), "1234567890"));
			
		}else{
			Assert.fail("User ID not found.");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Sync-281:Verify Application Link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testApplicationIDLink(){
		
		try{
		MergeService.searchByApplicationID(driver, "pers");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_applicationID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PersMSSql"))){
			String parentWindow= driver.getWindowHandle();
			MergeService.clickOnLink(driver, "PersMSSql");
			SeleniumUtil.delay(1000);
			Set<String> handles=driver.getWindowHandles();
			Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
			
			 for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow);
			
		}else{
			Assert.fail("Application ID not found.");
		}
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_mergeservice"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	/*
	 * Verifying refresh
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_mergeservice", By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_startTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_endTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for start time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForStartTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_mergeservice_searchBy_startTime", "grid_mergeservice", "start")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for end time
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarForEndtime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_mergeservice_searchBy_endTime", "grid_mergeservice", "end")," Time search through calendar is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForStartTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_mergeservice_searchBy_startTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForEndTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_mergeservice_searchBy_endTime"), "Calendar is not visible on alternate clicks");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,1),"Data is not sorted on the click of column name");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 *test error details link
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testErrorDetailsLink()
	{
		try{
			if(SeleniumUtil.isElementPresent(driver, By.linkText("View Error Details")))
			{
				SeleniumUtil.click(driver, By.linkText("View Error Details"));
				Assert.assertTrue(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("win_modelWin"))).equalsIgnoreCase("Error Details"),"Error details pop up is not opened");

			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
/*	
	 * verify page title
	 
	@Test(enabled=true, timeOut=300000)
	public void testPageTitle() throws Exception{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_mergeservice")), "page title is not appropriate");
	}*/
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return "mergeservice";
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return configObj.getPropertyValue("tbx_mergeservice_searchBy_userID");
	}
	
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_mergeservice", By.id(configObj.getPropertyValue("tbx_mergeservice_searchBy_userID"))),"Refresh is not working");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_mergeservice"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
