package com.kony.sync.console.webdriver.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.monitoring.SecurityAudit;

public abstract class SeleniumUtil extends BaseTestcase{

	private static WebDriverWait wait=null;
	private static String alertText=null;
	private static String confirmationText;
	private static boolean flag;
	private static String text;

	/**
	 * wait for an element until it displayed on the page otherwise timeout after 30 seconds.
	 * @param driver
	 * @param byElement
	 * @return byElement
	 */
	
	public static By waitForElement(WebDriver driver, By by){
		
		wait = new WebDriverWait(driver, 30L);
		try{
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));

		}catch(Exception e){
			Reporter.log("FAILURE: waitForElement, "+by+" has not found. TIMED OUT AFTER 30 SECONDS. \n"+e);
		}
		return by;
		
	}

	/**
	 * wait for a text until it displayed on the page otherwise timeout after 30 seconds.
	 * @param driver
	 * @param by
	 * @param text
	 * @return boolean
	 */
	
	public static boolean waitForText(WebDriver driver, By by, String text){
		
		flag=false;
		wait = new WebDriverWait(driver, 30L);
		try{
			flag = wait.until(ExpectedConditions.textToBePresentInElementLocated(by, text));

		}catch(Exception e){
			Reporter.log("FAILURE: waitForText, "+text+" has not found. TIMED OUT AFTER 30 SECONDS. \n"+e);
		}

		return flag;

	}

	/**
	 * wait for a text until it displayed on the input element otherwise timeout after 30 seconds.
	 * @param driver
	 * @param by
	 * @param text
	 * @return boolean
	 */
	
	public static boolean waitForTextValue(WebDriver driver, By by, String text){
		
		flag=false;
		wait = new WebDriverWait(driver, 30L);
		try{
			flag = wait.until(ExpectedConditions.textToBePresentInElementValue(by, text));

		}catch(Exception e){
			Reporter.log("FAILURE: waitForText, "+text+" has not found. TIMED OUT AFTER 30 SECONDS. \n"+e);
		}
		return flag;

	}

	/**
	 * wait for an element until it is invisible.
	 * @param driver
	 * @param byElement
	 */
	
	public static void waitForInvisibilityOfElement(WebDriver driver, By by){
		
		wait = new WebDriverWait(driver, 10L);
		try{
			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));

		}catch(Exception e){
			Reporter.log("FAILURE: waitForElement, "+by+" has not been invisible. TIMED OUT AFTER 10 SECONDS. \n"+e);
		}
		
	}
	
	/**
	 * wait for alert until alert is displayed on the page with in 10 seconds
	 */
	
	public static void waitForAlert(WebDriver driver){
		
		wait = new WebDriverWait(driver, 10L);
		try{
			wait.until(ExpectedConditions.alertIsPresent());

		}catch(Exception e){
			Reporter.log("FAILURE: alert is not visible. TIMED OUT AFTER 10 SECONDS. \n"+e);
		}
		
	}
	
	/**
	 * Returns the element after finding it
	 * @param driver
	 * @param by
	 * @return WebElement
	 */
	
	public static WebElement findElement(WebDriver driver, By by){
		
		WebElement element=null;
		element = driver.findElement(waitForElementToBePresent(driver, by));
		try{
			return element;
		}catch(Exception e){
			e.printStackTrace();
			return element;
		}
		
	}
	
	/**
	 * Returns the elements after finding them
	 * @param driver
	 * @param by
	 * @returns list of WebElements
	 */
	
	public static List<WebElement> findElements(WebDriver driver, By by){
		
		List<WebElement> elements=null;
		try{
			elements = driver.findElements(waitForElementToBePresent(driver, by));
			return elements;
		}catch(Exception e){
			e.printStackTrace();
			return elements;
		}
		
	}
	
	/**
	 * Get the text present on the web element .
	 * @param driver
	 * @param by
	 * @return text
	 */
	
	public static String getVisibleText(WebDriver driver, By by){
		
		text=null;
		try{
			text = driver.findElement(waitForElementToBePresent(driver, by)).getText();
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * Get the text from the text field if getVisibleText above is not suitable .
	 * @param driver
	 * @param by
	 * @return text
	 */
	
	public static String getText(WebDriver driver, By by){
		
		text=null;
		try{
			text = driver.findElement(by).getAttribute("value");
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
		
	}
	
	/**
	 * set the text into the text field.
	 * @param driver
	 * @param by
	 * @param text
	 */
	
	public static void setText(WebDriver driver, By by, String text){
		
		try{
			driver.findElement(waitForElement(driver, by)).clear();
			driver.findElement(by).sendKeys(text);
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	
	/**
	 * clear the text in the text field.
	 * @param driver
	 * @param by
	 */
	
	public static void clear(WebDriver driver, By by){
		
		try{
			driver.findElement(waitForElement(driver, by)).clear();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * click on an element
	 * @param driver
	 * @param by
	 */
	
	public static void click(WebDriver driver, By by){
		
		try{
			findElement(driver,waitForElement(driver, by)).click();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/**
	 * click on an element
	 * @param driver
	 * @param by
	 */
	
	public static void clickAndWait(WebDriver driver, By by, int timeInSeconds){
		
		try{
			findElement(driver,waitForElement(driver, by)).click();
			delay(timeInSeconds);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	/**
	 * close the alert and return the text present on the alert box
	 * @return text
	 */
	
	public static String closeAlertAndGetItsText(WebDriver driver, boolean acceptAlert) {
		
		alertText=null;
		try {
			Alert alert = driver.switchTo().alert();
			alertText = alert.getText();
			if (acceptAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		}finally{
			acceptAlert=false;
		}

	}

	/**
	 * check if element is present on the page
	 * @param by
	 * @return true or false
	 */
	
	public static boolean isElementPresent(WebDriver driver, By by) {
		
		boolean flag=false;
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			flag = false;
		}
		return flag;
		
	}

	/**
	 * Check if a particular text is present in the text of the element
	 * @param driver
	 * @param by
	 * @param text
	 * @return true or false
	 */

	public static boolean verifyContainsText(WebDriver driver, By by, String text) {

		boolean flag=false;
		try {
			flag=driver.findElement(by).getText().toLowerCase().contains(text.toLowerCase());
			return flag;
		} catch (NoSuchElementException e) {
			flag = false;
		}
		return flag;
		
	}

	/**
	 * Checks if a result of search is correct - each row is checked whether the searched text is present in the result or not
	 * Can be used to verify whether the expected data is present in the table.
	 * @param driver
	 * @param gridName
	 * @param searchVal
	 * @param xpathOfRequiredElementInEachRow - '$' has to be sent in the xpath as a variable parameter, it gets replaced during the iterations in order to get the text from each row
	 * @return true or false
	 */

	public static boolean verifySearchedContent(WebDriver driver, String gridID, String searchVal, String xpathOfRequiredElementInEachRow) {

		try{
			waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  delay(2000);
				WebElement table = findElement(driver,By.id(gridID));
			List<WebElement> rows  =	table.findElements(By.tagName("tr"));
			int rowCount = rows.size();
			if(rowCount > 1){
				for(int i=2; i<=rowCount; i++){
					waitForElement(driver, By.xpath(xpathOfRequiredElementInEachRow.replace("$", i+"")));

					if(!table.findElement(By.xpath(xpathOfRequiredElementInEachRow.replace("$", i+""))).getText().toLowerCase().contains(searchVal.toLowerCase())){
						return false;
					}
				}
			}
			else{
				return false;
			}
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}

	/**
	 * Checking page info - verifies the no. of rows displayed and the page info shown in the page  
	 * @param driver
	 * @param noOfRows
	 * @return true or false
	 */
	
	public static boolean verifyPagingInfo(WebDriver driver, int noOfRows) {
		
		try {
			String pageInfo = getVisibleText(driver, By.className(configObj.getPropertyValue("txt_pageInfo"))).trim().replaceAll("\\,+", "");
			Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
			if (result.get(2) < 10) {
				if (result.get(1) == result.get(2) && result.get(1) == noOfRows) {
					return true;
				} else {
					return false;
				}
			} else {
				if (result.get(2) >= 10 && result.get(1) == 10) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
	
	/**
	   * check if search of initialDateTime displays correct data
	   * @param driver
	   * @param initialDateTime
	   * @param gridID
	   * @param xpathOfRequiredElementInEachRow
	   * @return true or false
	   */
	
	  public static boolean verifyInitialDateTimeSearch(WebDriver driver, String initialDateTime, String gridID, String xpathOfRequiredElementInEachRow)
	  {
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				List<WebElement> rows = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
				int rowCount = rows.size();
			  if(rowCount>1)
			  {
				  for(int i=2; i<=rowCount; i++){
					  waitForElement(driver, By.xpath(xpathOfRequiredElementInEachRow.replace("$", i+"")));
					  if(!(fmt.parse(getVisibleText(driver, By.xpath(xpathOfRequiredElementInEachRow.replace("$", i+"")))).getTime()>=fmt.parse(initialDateTime).getTime())){
						  return false;
					  }
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
	   * check if search of laterOnDateTime displays correct data
	   * @param driver
	   * @param gridID
	   * @param laterOnDateTime
	   * @param xpathOfRequiredElementInEachRow
	   * @return true or false
	   */
	  
	  public static boolean verifyLaterOnDateTimeSearch(WebDriver driver, String laterOnDateTime, String gridID, String xpathOfRequiredElementInEachRow)
	  {
		  
		  try{

			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  List<WebElement> rows = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  int rowCount = rows.size();
			  if(rowCount>1)
			  {
				  for(int i=2; i<=rowCount; i++){
					  
					  waitForElement(driver, By.xpath(xpathOfRequiredElementInEachRow.replace("$", i+"")));
					  if(!(fmt.parse(getVisibleText(driver,By.xpath(xpathOfRequiredElementInEachRow.replace("$", i+"")))).getTime()<=fmt.parse(laterOnDateTime).getTime())){
						  return false;
					  }
				  }
			  }
			  else{
				  return false;
			  }
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  /**
	   * check if search of initialDateTime and laterOnDateTime together displays correct data
	   * @param driver
	   * @param initialDateTime
	   * @param gridID
	   * @param laterOnDateTime
	   * @return true or false
	   */
	  
	  public static boolean verifyInitialLaterDateTimeOnSearch(WebDriver driver,String initialDateTime, String laterOnDateTime, String gridID, String xpathOfRequiredElementInInitialtimeEachRow, String xpathOfRequiredElementInFinaltimeEachRow)
	  {
		  
		  try{
			  SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			  List<WebElement> rows = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  int rowCount = rows.size();
			  if(rowCount>1)
			  {
				for (int i = 2; i <= rowCount; i++) {
					
					waitForElement(driver,
							By.xpath(xpathOfRequiredElementInFinaltimeEachRow.replace("$", i+"")));
					if (!((fmt.parse(
							getVisibleText(driver,
									By.xpath(xpathOfRequiredElementInInitialtimeEachRow.replace("$", i+""))))
									.getTime() >= fmt.parse(
											initialDateTime).getTime()) && (fmt.parse(
							getVisibleText(driver,
									By.xpath(xpathOfRequiredElementInInitialtimeEachRow.replace("$", i+""))))
									.getTime() <= fmt.parse(
											laterOnDateTime).getTime())))
											{
												return false;
											}
											
					if(!((fmt.parse(
							getVisibleText(driver,
											By.xpath(xpathOfRequiredElementInFinaltimeEachRow.replace("$", i+""))))
											.getTime() >= fmt.parse(
													initialDateTime).getTime()) && (fmt.parse(
							getVisibleText(driver,
											By.xpath(xpathOfRequiredElementInFinaltimeEachRow.replace("$", i+""))))
											.getTime()) <= (fmt.parse(
													laterOnDateTime).getTime()))){
												return false;
											}
				  							}
			  	}
			  else{
				  return false;
			  }
			   return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	
	
	  public static boolean verifyRefresh(WebDriver driver, String gridID, By by) {

			try {
				  List<WebElement> first = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
				  int initialCount = first.size()-1;
				  if(initialCount!=0)
				  {
					  setText(driver, by, "xyzabcd"+Keys.RETURN);
				  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  List<WebElement> afterSearch = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
				  if(afterSearch.size()-1==0)
				  {
					click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
				  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  
				  List<WebElement> last = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
				  int finalCount = last.size()-1;
				  if(initialCount==finalCount)
				  {
					  if(getText(driver, by).equals(""))
					  {
					  return true;
					  }
					  else{
						  Assert.fail("The searched string is not cleared even after clicking on refresh");
						  return false;
					  }
				  }
				  else{
					  return false;
				  }
				  }
				  else{
					  Assert.fail("The invalid search string is showing results while trying to test refresh");
					  return false;
				  }
				  }
				  else{
					  Assert.fail("The row is empty so refresh cannot be tested");
					  return false;
				  }
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				  return false;
			}
			
			}
	  
	  /*
	   * Verify collapseOfTable
	   */
	  
	  public static boolean verifyCollapseOfTable(WebDriver driver)
	  {
		  
		  try{
		  if(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_collapse"))))
		  {
			  click(driver, By.xpath(configObj.getPropertyValue("btn_collapse")));
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			  
			  Assert.assertTrue(isElementPresent(driver, By.xpath("//div[@class='ui-state-default ui-jqgrid-hdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  Assert.assertTrue(isElementPresent(driver, By.xpath("//div[@class='ui-jqgrid-bdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  
			  click(driver, By.xpath("//a[contains(@class,'HeaderButton')]"));
			  waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			  
			  Assert.assertTrue(isElementPresent(driver, By.xpath("//div[@class='ui-state-default ui-jqgrid-hdiv' and contains(@style,'display: block')]")), "Collpase button is not working");
			  Assert.assertTrue(isElementPresent(driver, By.xpath("//div[@class='ui-jqgrid-bdiv' and contains(@style,'display: block')]")), "Collpase button is not working");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  return true;
		  }
		  else{
			  Assert.fail("Collapse button is not present");
			  return false;
		  }
	  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
	  }
	  
	  /*
	   * Verify calendar for start/end date
	   * @param driver
	   * @param searchBox
	   * @param grid Id
	   * @param time takes two values either start or end - start is used to check the data which populates after the start date and reverse for end date
	   */
	  
	  public static boolean verifyTimeThroughCalendarAndSearch(WebDriver driver, String searchBox, String gridId, String time)
	  {
		  
		  try{
			  SeleniumUtil.delay(2000);
			  clickAndWait(driver, By.id(configObj.getPropertyValue(searchBox)),1000);
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
				Assert.assertTrue(isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
				if((int)findElement(driver,By.id(configObj.getPropertyValue(gridId))).findElements(By.tagName("tr")).size()>1)
				{
					if(time.equalsIgnoreCase("start"))
					{
					for(int i=0;i<12;i++)
					{
						click(driver, By.xpath(configObj.getPropertyValue("btn_calendarNext")));
					}
					}
					else{
						for(int i=0;i<36;i++)
						{
							click(driver, By.xpath(configObj.getPropertyValue("btn_calendarPrev")));
						}
					}
					clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_calendar_done")),1000);
					waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					
					Assert.assertTrue((int)findElement(driver,By.id(configObj.getPropertyValue(gridId))).findElements(By.tagName("tr")).size()-1==0, "Search is not working on click of done");
					
					if(time.equalsIgnoreCase("start"))
					{
						click(driver, By.id(configObj.getPropertyValue(searchBox)));
						click(driver, By.xpath(configObj.getPropertyValue("btn_calendar_now")));
						clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_calendar_done")),1000);
						Assert.assertTrue((int)findElement(driver,By.id(configObj.getPropertyValue(gridId))).findElements(By.tagName("tr")).size()-1==0, "Search is not working when time is set using now and clicking on done");
					}
					else{
						click(driver, By.id(configObj.getPropertyValue(searchBox)));
						click(driver, By.xpath(configObj.getPropertyValue("btn_calendar_now")));
						clickAndWait(driver, By.xpath(configObj.getPropertyValue("btn_calendar_done")),1000);
						Assert.assertTrue((int)findElement(driver,By.id(configObj.getPropertyValue(gridId))).findElements(By.tagName("tr")).size()-1>0, "Search is not working when time is set using now and clicking on done");
					}
					
				}
				else{
					Assert.fail("there are no rows to check search functionality through calendar");
				}

			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  }
	  
	  /*
	   * Verify alternative clicks for time field
	   * @param driver
	   * @param searchBox
	   * @param grid Id
	   */
	  
	  public static boolean verifyAlternativeClicksForTimeField(WebDriver driver, String searchBox)
	  {
		  try{
			  waitForElement(driver, By.id(configObj.getPropertyValue(searchBox)));
			  click(driver, By.id(configObj.getPropertyValue(searchBox)));
			  click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
			  SeleniumUtil.delay(2000);
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  clickAndWait(driver, By.id(configObj.getPropertyValue(searchBox)),1000);
			  SeleniumUtil.delay(1000);
			  waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
			  Assert.assertTrue(isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present for alternative clicks");
			  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
	  }
	  
	  
	  /*
	   * verify navigation of pages
	   */
	  
	  public static boolean verifyNavigationOfPages(WebDriver driver)
	  {
		  
		  try{
			  int totalNoOfPages=(Integer.parseInt(getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_totalNoOfPages")))));
		  if(totalNoOfPages>1)
		  {
		  click(driver,By.xpath(configObj.getPropertyValue("btn_lastPage")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			 String pageInfo = getVisibleText(driver, By.className(configObj.getPropertyValue("txt_pageInfo"))).trim().replaceAll("\\,+", "");
		  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
		  int noOfRecords=result.get(2);
		  Assert.assertTrue(noOfRecords==result.get(1), "All the records are not fetched even after moving to the last page");
		  Assert.assertTrue(totalNoOfPages==(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo"))))),"Page is not able to navigate to the last page");

		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_nextPage"))), "Next button is not disabled even after reaching the final page");
		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_lastPage"))), "Last button is not disabled even after reaching the final page");
		  
		  click(driver, By.xpath(configObj.getPropertyValue("btn_firstPage")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_previousPage"))), "Previous button is not disabled even after reaching the first page");
		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_firstPage"))), "First button is not disabled even after reaching the first page");

		  if(totalNoOfPages<20){			  
		  for(int i=2;i<=totalNoOfPages;i++)
		  {
			  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  click(driver,By.xpath(configObj.getPropertyValue("btn_nextPage")));
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue(i==(Integer.parseInt(getText(driver,By.xpath(configObj.getPropertyValue("tbx_pageNo"))))),"Page is not able to navigate to" +i+ "page in performing next");
			  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
		  }
		  
		  for(int i=2;i<=totalNoOfPages;i++)
		  {
			  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  click(driver,By.xpath(configObj.getPropertyValue("btn_previousPage")));
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue(i==(totalNoOfPages-(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo")))))+1),"Page is not able to navigate to" +i+ "page in performing prev");

			  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
		  }
		  }
		  else{
			  
			  for(int i=2;i<=20;i++)
			  {
				  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  click(driver,By.xpath(configObj.getPropertyValue("btn_nextPage")));
				  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  Assert.assertTrue(i==(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo"))))),"Page is not able to navigate to" +i+ "page in performing next");
				  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
			  }
			  
			  for(int i=2;i<=20;i++)
			  {
				  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  click(driver,By.xpath(configObj.getPropertyValue("btn_previousPage")));
				  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  Assert.assertTrue(i==(20-(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo")))))+1),"Page is not able to navigate to" +i+ "page in performing prev");
				  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
			  }  
			  
		  }
		  click(driver,By.xpath(configObj.getPropertyValue("btn_lastPage")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  click(driver,By.xpath(configObj.getPropertyValue("btn_firstPage")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  
		  Assert.assertTrue(1==(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo"))))),"Page is not able to navigate to the first page");

		 String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		 setText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo")), (totalNoOfPages)+""+Keys.RETURN);
		 waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
		  
		  
			 setText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo")), 100000000+""+Keys.RETURN);
			 waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			 Assert.assertFalse(isElementPresent(driver, By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")),"Page search with invalid text is not working");
			 Assert.assertTrue(getVisibleText(driver, By.className(configObj.getPropertyValue("txt_pageInfo"))).equalsIgnoreCase("Empty records"),"Empty Records text is not shown");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
		 
		  }
		  else{
			  Assert.fail("Enough no. of records are not there, so navigation of pages cannot be tested");
			  return false;
		  }
		  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	
	  /*
	   * verify size of the page
	   */
	  
	  public static boolean verifyNoOfRecordsToBeDisplayed(WebDriver driver)
	  {
		  
		  try{
		  int no[]={10,20,40,60};
		  for(int i=1;i<=4;i++)
		  {
			Assert.assertTrue(findElement(driver,By.xpath("//select[@class='ui-pg-selbox']/option["+i+"]")).getText().equals(no[i-1]+""),"The criteria to get page size is not matched");
		  }
		  
		  String pageInfo = getVisibleText(driver, By.className(configObj.getPropertyValue("txt_pageInfo"))).trim().replaceAll("\\,+", "");

		  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
		  int noOfRecords=result.get(2);
		  int beforeRows=(int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size();
		  
		  int totalNoOfPages=(Integer.parseInt(getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_totalNoOfPages")))));
		  if(totalNoOfPages>1)
		  {
		  if(noOfRecords>10 && noOfRecords<20)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 20 is not working");
		  }
		  if(noOfRecords==20)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(beforeRows+10),"No.of records changed to 20 is not working");
		  }
		  if(noOfRecords>20 && noOfRecords<40)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  beforeRows=(int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size();
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 40 is not working");
		  }
		  if(noOfRecords==40)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(beforeRows+30),"No.of records changed to 40 is not working");
		  }
		  if(noOfRecords>40 && noOfRecords<60)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
			  beforeRows=(int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size();
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("60");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 60 is not working");
		  }
		  if(noOfRecords==60)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(40),"No.of records changed to 40 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("60");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(beforeRows+50),"No.of records changed to 60 is not working");
		  }
		  if(noOfRecords>60)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText("60");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==60,"No.of records changed to 60 is not working");
		  }
		  
		  verifyNavigationWithMoreNoOfPages(driver, noOfRecords);
		  driver.navigate().refresh();
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  
		  if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
		  {
		  Assert.assertTrue(findElement(driver,By.xpath("//div[contains(@id,'gview')]/div[4]")).getAttribute("style").contains("height: 100%"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
		  return true;
		  }
		  else{
			  Assert.assertTrue(findElement(driver,By.xpath("//div[contains(@id,'gview')]/div[4]")).getAttribute("style").contains("height: auto"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
			  return true;
		  }
		  
		  }
		  else{
			  Assert.fail("Enough records are not there to check the functionality of no. of records to be displayed");
			  return false;
		  }
	  }
		  catch(Exception e){
		  e.printStackTrace();
		  return false;
	  }
		  
	  }
	  
	  /*
	   * navigation With More No Of Pages
	   * support method for verifyNoOfRecordsToBeDisplayed
	   */
	  
	  public static void verifyNavigationWithMoreNoOfPages(WebDriver driver, int noOfRecords) throws InterruptedException
	  {
		  
		  if(noOfRecords>20 && noOfRecords<=40){
			  
			  Assert.assertFalse(noOfPages(driver,"20"),"Not navigated to next page with 20 as page size");
		  }
		  
		  if(noOfRecords>40 && noOfRecords<=60){
			  Assert.assertFalse(noOfPages(driver,"20"),"Not navigated to next page with 20 as page size");
			  driver.navigate().refresh();
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertFalse(noOfPages(driver,"40"),"Not navigated to next page with 40 as page size");
		  }
		  
		  if(noOfRecords>60){
			  Assert.assertFalse(noOfPages(driver,"20"),"Not navigated to next page with 20 as page size");
			  driver.navigate().refresh();
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertFalse(noOfPages(driver,"40"),"Not navigated to next page with 40 as page size");
			  driver.navigate().refresh();
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  Assert.assertFalse(noOfPages(driver,"60"),"Not navigated to next page with 60 as page size");
		  }
		  
	  }
	  
	  /*
	   * support method for verifyNavigationWithMoreNoOfPages
	   */
	  
	  public static boolean noOfPages(WebDriver driver,String num) throws InterruptedException 
	  {
		  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown")))).selectByVisibleText(num);
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  
		  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  click(driver,By.xpath(configObj.getPropertyValue("btn_nextPage")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  
		  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  return beforeId.equals(afterId);
		  
	  }
	  
	  /*
	   * Sorting data in all the fields
	   * trNum is the number in the table grid from where the data starts
	   * It checks only the changing of row id after clicking on the sort button
	   */
	  
	  @SuppressWarnings(value = { "unchecked","rawtypes" })
	  public static boolean verifySortingOfData(WebDriver driver,int trNum)
	  {
		  try{
			List<String> exceptionColumns = new ArrayList(Arrays.asList("View Configuration","Edit Datasource","Authentication","Error Details","Client Row","Server Row","Merged Row","Request Size (Bytes)","Response Size (Bytes)","Request","Response","Elapsed Time (sec)","DataSource Elapsed Time (sec)","Elapsed Time(sec)","Job Class","Trigger","Trigger Details","Http Request","Http Response","Response Code","View History","DataSource Log"));
			  if(getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_devices_pageHeader"))).equalsIgnoreCase("Devices"))
			  {
				  exceptionColumns.add("Users");
				  exceptionColumns.add("Device OS");
			  }
			  if((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>1)
			  {
				  int noOfColumns=findElements(driver,By.xpath("//thead/tr[1]/th[not(contains(@style,'none'))]")).size();
				  int count=0,noOfIterations=0;
				  if(trNum==3)
				  {
					  count=3;
					  noOfIterations=(noOfColumns+2);
				  }
				  if(trNum==2)
				  {
					  count=2;
					  noOfIterations=(noOfColumns+2);
				  }
				  if(trNum==1)
				  {
					  count=1;
					  noOfIterations=(noOfColumns+1);
				  }
				  if(trNum==4)
				  {
					  count=4;
					  noOfIterations=(noOfColumns+1);
				  }
				  String columnName;
				  for(int i=count;i<noOfIterations;i++)
				  {
					  columnName=findElement(driver,By.xpath("//thead/tr[1]/th["+i+"]")).getText().trim();
					  if(!exceptionColumns.contains(columnName))
					  {
					  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][2]")).getAttribute("id");
					  clickAndWait(driver,By.xpath("//thead/tr[1]/th["+i+"]/div"),200);
					  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  
					  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][2]")).getAttribute("id");
					  clickAndWait(driver,By.xpath("//thead/tr[1]/th["+i+"]/div"),200);
					  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

					  String anotherId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][2]")).getAttribute("id");
					  Assert.assertFalse(beforeId.equals(afterId) && beforeId.equals(anotherId),"Column " + columnName + " is not sorted");
					  driver.navigate().refresh();
					  SeleniumUtil.delay(200);
					  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					  }
				  }
				  return true;
				
			  }
			  else{
				  Assert.fail("Enough data is not there to check the sort functionality ");
				  return false;
			  }
			  
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	  
	  
		/**
		 * verifies the title of the page
		 * @param driver
		 * @param expected title
		 * @return true or false
		 */
	  
	public static boolean verifyPageTitle(WebDriver driver, String title) {
		
		try {
			String pageTitle = getPageTitle(driver);
			if (pageTitle.trim().replaceAll("\\s+", "").equalsIgnoreCase(title.trim().replaceAll("\\s+", ""))) {
				return true;
			} else {
				return false;
			}
		} catch (NoSuchElementException e) {
			return false;
		}
		
	}
	
	/**
	 * returns the page title which driver is currently working on
	 * @param driver
	 * @return page title
	 */
	
	public static String getPageTitle(WebDriver driver){
		
		String title;
		do {
			title=driver.getTitle();
		} while(title.isEmpty());
		return title;
		
	}
	
	 public static void waitForNumberOfWindowsToEqual(WebDriver driver, final int numberOfWindows) { 
		 
	     new WebDriverWait(driver, 10) { 
	     }.until(new ExpectedCondition<Boolean>() { 
	         @Override 
	         public Boolean apply(WebDriver driver) {                         
	             return (driver.getWindowHandles().size() == numberOfWindows); 
	         } 
	     }); 
	     
	} 
	  
	 public static void delay(int time) throws InterruptedException { 
	     Thread.sleep(time);
	}
	 
	 /**
		 * close the confirmation box(having separate method because webdriver can't handle JQuery pop ups in the way it handles normal alerts) and return the text present on the box
		 * @return text
		 */
	 
		public static String closeConfirmationBoxAndGetItsText(WebDriver driver, boolean accept) {
			
			confirmationText=null;
			try {
				WebElement element=findElement(driver, By.xpath(configObj.getPropertyValue("dialog_confirm")));
				confirmationText = element.findElement(By.xpath(configObj.getPropertyValue("txt_reportConfirmDialog"))).getText();
				if (accept) {
					waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_yes_reportConfirm")));
					click(driver, By.xpath(configObj.getPropertyValue("btn_yes_reportConfirm")));
				} else {
					waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_no_reportConfirm")));
					click(driver, By.xpath(configObj.getPropertyValue("btn_no_reportConfirm")));
				}
				return confirmationText;
			}finally{
				accept=false;
			}

		}

		
		 /**
		 * close the alert box(having separate method because webdriver can't handle JQuery pop ups in the way it handles normal alerts) and return the text present on the box
		 * @return text
		 */
		
		public static String closeAlertBoxAndGetItsText(WebDriver driver) {
			
			confirmationText=null;
			try {
				waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_alert_box")));
				alertText = getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_alert_box")));
				click(driver, By.xpath(configObj.getPropertyValue("btn_alert_box")));
				return alertText;
			}catch(Exception e){
				e.printStackTrace();
				return "";
			}

		}		
		
	private static By waitForElementToBePresent(WebDriver driver, By by) {
		
		wait = new WebDriverWait(driver, 30L);
		try{
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		}catch(Exception e){
			Reporter.log("FAILURE: waitForElement, "+by+" has not found. TIMED OUT AFTER 30 SECONDS. \n"+e);
		}
		return by;
		
	}
	
	/**
	 * check if element is present on the page
	 * @param by
	 * @return true or false
	 */
	
	public static boolean isElementDisplayed(WebDriver driver, By by) {
		
		boolean flag=false;
		try {
			flag=driver.findElement(by).isDisplayed();
		} catch (NoSuchElementException e) {
			flag = false;
		}
		return flag;
		
	}
	
	/**
	 * verifies the audit status in security audit page when any change is done
	 * @param driver
	 * @param whatChanged
	 * @param comments
	 */
	
	public static void verifySecurityAudit(WebDriver driver, String whatChanged, String comments)
	{
		
		SecurityAudit.navigateToSecurityAuditPage(driver);
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_securityAudit_pageHeader")), "Security Audit");
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_latest_whatChanged"))).trim(), whatChanged);
		Assert.assertEquals(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_latest_comments"))).trim(), comments);
		
	}
	
	
	
	public static boolean verifyRefresh_bottom(WebDriver driver, String gridID, By by) {

		try {
			  List<WebElement> first = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  int initialCount = first.size()-1;
			  if(initialCount!=0)
			  {
				  setText(driver, by, "xyzabcd"+Keys.RETURN);
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  List<WebElement> afterSearch = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  if(afterSearch.size()-1==0)
			  {
				click(driver, By.xpath(configObj.getPropertyValue("btn_refresh_bottom")));
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  
			  List<WebElement> last = findElement(driver,By.id(configObj.getPropertyValue(gridID))).findElements(By.tagName("tr"));
			  int finalCount = last.size()-1;
			  if(initialCount==finalCount)
			  {
				  if(getText(driver, by).equals(""))
				  {
				  return true;
				  }
				  else{
					  Assert.fail("The searched string is not cleared even after clicking on refresh");
					  return false;
				  }
			  }
			  else{
				  return false;
			  }
			  }
			  else{
				  Assert.fail("The invalid search string is showing results while trying to test refresh");
				  return false;
			  }
			  }
			  else{
				  Assert.fail("The row is empty so refresh cannot be tested");
				  return false;
			  }
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			  return false;
		}
		
		}
	
	public static boolean verifyPagingInfo_bottom(WebDriver driver, int noOfRows) {
		
		try {
			String pageInfo = getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_pageInfo_bottom"))).trim().replaceAll("\\,+", "");
			Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
			if (result.get(2) < 10) {
				if (result.get(1) == result.get(2) && result.get(1) == noOfRows) {
					return true;
				} else {
					return false;
				}
			} else {
				if (result.get(2) >= 10 && result.get(1) == 10) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
	
	 public static boolean verifyNavigationOfPages_bottom(WebDriver driver)
	  {
		 
		  try{
			  int totalNoOfPages=(Integer.parseInt(getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_totalNoOfPages_bottom")))));
		  if(totalNoOfPages>1)
		  {
		  click(driver,By.xpath(configObj.getPropertyValue("btn_lastPage_bottom")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			 String pageInfo = getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_pageInfo_bottom"))).trim().replaceAll("\\,+", "");
		  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
		  int noOfRecords=result.get(2);
		  Assert.assertTrue(noOfRecords==result.get(1), "All the records are not fetched even after moving to the last page");
		  Assert.assertTrue(totalNoOfPages==(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom"))))),"Page is not able to navigate to the last page");

		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_nextPage_bottom"))), "Next button is not disabled even after reaching the final page");
		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_lastPage_bottom"))), "Last button is not disabled even after reaching the final page");
		  
		  click(driver, By.xpath(configObj.getPropertyValue("btn_firstPage_bottom")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_previousPage_bottom"))), "Previous button is not disabled even after reaching the first page");
		  Assert.assertFalse(isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_firstPage_bottom"))), "First button is not disabled even after reaching the first page");

		  if(totalNoOfPages<20){			  
		  for(int i=2;i<=totalNoOfPages;i++)
		  {
			  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  click(driver,By.xpath(configObj.getPropertyValue("btn_nextPage_bottom")));
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue(i==(Integer.parseInt(getText(driver,By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom"))))),"Page is not able to navigate to" +i+ "page in performing next");
			  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
		  }
		  
		  for(int i=2;i<=totalNoOfPages;i++)
		  {
			  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  click(driver,By.xpath(configObj.getPropertyValue("btn_previousPage_bottom")));
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue(i==(totalNoOfPages-(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom")))))+1),"Page is not able to navigate to" +i+ "page in performing prev");
			  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
		  }
		  }
		  else{
			  
			  for(int i=2;i<=20;i++)
			  {
				  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  click(driver,By.xpath(configObj.getPropertyValue("btn_nextPage_bottom")));
				  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  Assert.assertTrue(i==(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom"))))),"Page is not able to navigate to" +i+ "page in performing next");
				  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
			  }
			  
			  for(int i=2;i<=20;i++)
			  {
				  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  click(driver,By.xpath(configObj.getPropertyValue("btn_previousPage_bottom")));
				  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
				  Assert.assertTrue(i==(20-(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom")))))+1),"Page is not able to navigate to" +i+ "page in performing prev");
				  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
				  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to"+i+"  page");
			  }  
			  
		  }
		  click(driver,By.xpath(configObj.getPropertyValue("btn_lastPage_bottom")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  click(driver,By.xpath(configObj.getPropertyValue("btn_firstPage_bottom")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  Assert.assertTrue(1==(Integer.parseInt(getText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom"))))),"Page is not able to navigate to the first page");

		 String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		 setText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom")), (totalNoOfPages)+""+Keys.RETURN);
		 waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
		  
		  
			 setText(driver, By.xpath(configObj.getPropertyValue("tbx_pageNo_bottom")), 100000000+""+Keys.RETURN);
			 waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			 Assert.assertFalse(isElementPresent(driver, By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")),"Page search with invalid text is not working");
			 Assert.assertTrue(getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_pageInfo_bottom"))).equalsIgnoreCase("Empty records"),"Empty Records text is not shown");
			  Assert.assertFalse(beforeId.equals(afterId),"Not navigated to page which is entered manually in search of page");
		  }
		  else{
			  Assert.fail("Enough no. of records are not there, so navigation of pages cannot be tested");
			  return false;
		  }
		  return true;
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
			  return false;
		  }
		  
	  }
	
	
	
	 /*
	   * verify size of the page at bottom
	   */
	 
	  public static boolean verifyNoOfRecordsToBeDisplayed_bottom(WebDriver driver)
	  {
		  
		  try{
		  int no[]={10,20,40,60};
		  for(int i=1;i<=4;i++)
		  {
			Assert.assertTrue(findElement(driver,By.xpath("//td[contains(@id,'center') and not(contains(@id,'top'))]//select[@class='ui-pg-selbox']/option["+i+"]")).getText().equals(no[i-1]+""),"The criteria to get page size is not matched");
		  }
		  String pageInfo = getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_pageInfo_bottom"))).trim().replaceAll("\\,+", "");

		  Matcher matcher = Pattern.compile("(\\d+)").matcher(pageInfo);
			List<Integer> result = new ArrayList<Integer>();
			if (matcher.find()) {
				do {
					result.add(Integer.parseInt(matcher.group(0)));
				} while (matcher.find());
			}
		  int noOfRecords=result.get(2);
		  int beforeRows=(int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size();
		  int totalNoOfPages=(Integer.parseInt(getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_totalNoOfPages_bottom")))));
		  if(totalNoOfPages>1)
		  {
		  if(noOfRecords>10 && noOfRecords<20)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 20 is not working");
		  }
		  if(noOfRecords==20)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(beforeRows+10),"No.of records changed to 20 is not working");
		  }
		  if(noOfRecords>20 && noOfRecords<40)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  beforeRows=(int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size();
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 40 is not working");
		  }
		  if(noOfRecords==40)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(beforeRows+30),"No.of records changed to 40 is not working");
		  }
		  if(noOfRecords>40 && noOfRecords<60)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
			  beforeRows=(int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size();
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("60");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()>beforeRows,"No.of records changed to 60 is not working");
		  }
		  if(noOfRecords==60)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(40),"No.of records changed to 40 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("60");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==(beforeRows+50),"No.of records changed to 60 is not working");
		  }
		  if(noOfRecords>60)
		  {
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("20");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==20,"No.of records changed to 20 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("40");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==40,"No.of records changed to 40 is not working");
			  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText("60");
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertTrue((int)findElements(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1]")).size()==60,"No.of records changed to 60 is not working");
		  }
		  
		  verifyNavigationWithMoreNoOfPages_bottom(driver, noOfRecords);
		  driver.navigate().refresh();
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
		  {
		  Assert.assertTrue(findElement(driver,By.xpath("//div[contains(@id,'gview')]/div[4]")).getAttribute("style").contains("height: 100%"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
		  return true;
		  }
		  else{
			  Assert.assertTrue(findElement(driver,By.xpath("//div[contains(@id,'gview')]/div[4]")).getAttribute("style").contains("height: auto"),"The height of the grid is not in 'auto', so more no. of results won't be visible");
			  return true;
		  }
		  }
		  else{
			  Assert.fail("Enough records are not there to check the functionality of no. of records to be displayed");
			  return false;
		  }
	  }
		  catch(Exception e){
		  e.printStackTrace();
		  return false;
	  }
		  
	  }
	  
	  /*
	   * navigation With More No Of Pages at bottom
	   */
	  
	  public static void verifyNavigationWithMoreNoOfPages_bottom(WebDriver driver, int noOfRecords) throws InterruptedException
	  {
		  
		  if(noOfRecords>20 && noOfRecords<=40){
			  Assert.assertFalse(noOfPages_bottom(driver,"20"),"Not navigated to next page with 20 as page size");
		  }
		  if(noOfRecords>40 && noOfRecords<=60){
			  Assert.assertFalse(noOfPages_bottom(driver,"20"),"Not navigated to next page with 20 as page size");
			  driver.navigate().refresh();
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertFalse(noOfPages_bottom(driver,"40"),"Not navigated to next page with 40 as page size");
		  }
		  if(noOfRecords>60){
			  Assert.assertFalse(noOfPages_bottom(driver,"20"),"Not navigated to next page with 20 as page size");
			  driver.navigate().refresh();
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertFalse(noOfPages_bottom(driver,"40"),"Not navigated to next page with 40 as page size");
			  driver.navigate().refresh();
			  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
			  Assert.assertFalse(noOfPages_bottom(driver,"60"),"Not navigated to next page with 60 as page size");
		  }
		  
	  }
	  
	  /*
	   * support method for verifyNavigationWithMoreNoOfPages at bottom
	   */
	  
	  public static boolean noOfPages_bottom(WebDriver driver,String num) throws InterruptedException 
	  {
		  
		  new Select(findElement(driver,By.xpath(configObj.getPropertyValue("pgNo_dropDown_bottom")))).selectByVisibleText(num);
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  String beforeId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  click(driver,By.xpath(configObj.getPropertyValue("btn_nextPage_bottom")));
		  waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		  String afterId=findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>1][1]")).getAttribute("id");
		  return beforeId.equals(afterId);
		  
	  }

}