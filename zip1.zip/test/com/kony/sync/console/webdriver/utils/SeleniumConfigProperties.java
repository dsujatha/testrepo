package com.kony.sync.console.webdriver.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

public class SeleniumConfigProperties
{
  private Properties properties = new Properties();
  public static final String SELENIUM_PROPERTIES_FILENAME = "Selenium.properties";
  public static final String SEL_HOME = "sel.home";
  public static final String PROJECT_HOME = "SELENIUMPROJECT_HOME3";
  private static SeleniumConfigProperties instance = null;

  private SeleniumConfigProperties(InputStream in) throws IOException
  {
	  
    try {
      this.properties.load(in);
    } finally {
      if (in != null)
        try {
          in.close();
        } catch (IOException e) {
          System.out.println("Error While Closing Selenium Properties File");
        }
    }
    
  }

  public static SeleniumConfigProperties getInstance()
  {
	  
    try {
    	String selHome = SeleniumConfigProperties.getProjectHome()+"\\test\\com\\kony\\sync\\console\\webdriver\\utils";
    	String confFileName = selHome + File.separator + File.separator + "Selenium.properties";
		File confFile = new File(confFileName);
			if (!confFile.exists()) {
				System.out.println("Selenium.Properties File Does Not Exist");
				instance = null;
			} else if (instance == null) {
				InputStream in = new FileInputStream(confFile);
				instance = new SeleniumConfigProperties(in);

        PropertyConfigurator.configureAndWatch(confFileName, 10000L);
      }
    }
    catch (FileNotFoundException e)
    {
      System.out.println("SeleniumProperties File Does Not Exist");
      instance = null;
    } catch (IOException e) {
      System.out.println("Error While Reading SeleniumProperties File");
      instance = null;
    } catch (Exception e) {
      System.out.println("Error While Reading SeleniumProperties File");
      instance = null;
    }
    return instance;
    
  }
  public static String getSeleniumPropertiesFilename() {
	  
    return "Selenium.properties";
    
  }

  public static String getSelHome() {
	  
    String selHome = System.getProperty("sel.home");

    if (selHome == null) {
      selHome = System.getenv("sel.home");
    }
    System.out.println("SEL_HOME :" + selHome);
    return selHome;
    
  }

  public static String getProjectHome(){
	  
	  String projectHome = System.getProperty(PROJECT_HOME);

	    if (projectHome == null) {
	    	projectHome = System.getenv(PROJECT_HOME);
	    }
	    return projectHome;
	    
  }
  
  public String getPropertyValue(String propertyName) {
	  
    if ((this.properties != null) && (this.properties.get(propertyName) != null)) {
      return ((String)this.properties.get(propertyName)).trim();
    }
    return null;
    
  }
  
  public String getPropertyValue(String propertyName, String defualtValue) {
	  
    if ((this.properties != null) && (this.properties.get(propertyName) != null)) {
      return ((String)this.properties.get(propertyName)).trim();
    }
    return defualtValue;
    
  }
  
  public Properties getProperties() {
	  
    return this.properties;
    
  }
  public void setProperties(Properties properties) {
	  
    this.properties = properties;
    
  }
  
}