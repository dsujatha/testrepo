package com.kony.sync.console.webdriver.configuration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Configuration extends BaseTestcase{
	
	public static void navigateToConfigurationPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_configuration_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public static void setTraceLogging(WebDriver driver, String selectOption)
	{
		
		try{
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
			new Select(SeleniumUtil.findElement(driver,By.id("enableTraceLog"))).selectByVisibleText(selectOption);
			  }
			else{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_traceLoggingDropDown")));
				  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_traceLogStatus")));
				  for (WebElement option : options) {
				     if(selectOption.equalsIgnoreCase(option.getText()))
				     {
				        option.click();
				     	break;
				     }
				  }
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	public static void setLogLevel(WebDriver driver, String selectOption)
	{
		
		try{
			{
				SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_logLevelDropDown")));
				  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_logLevels")));
				  for (WebElement option : options) {
				     if(selectOption.equalsIgnoreCase(option.getText()))
				     {
				        option.click();
				     	break;
				     }
				  }
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void setDataRetentionPeriod(WebDriver driver, String selectOption)
	{
		
		try{
			{
				if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
				  {
			   new Select(SeleniumUtil.findElement(driver,By.id("retentionperiod"))).selectByVisibleText(selectOption);
				  }
				else{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dataRetentionDropDown")));
					  List<WebElement> options = SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_dataRetentionPeriod")));
					  for (WebElement option : options) {
					     if(selectOption.equalsIgnoreCase(option.getText()))
					     {
					        option.click();
					     	break;
					     }
					  }
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
