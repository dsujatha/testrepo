package com.kony.sync.console.webdriver.configuration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class ConfigurationTest extends BaseTestcase{
	
	@BeforeTest
	public void loadDriver() {
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeMethod
	public void setUp(){

		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_configuration_mainPage")));
			Configuration.navigateToConfigurationPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_configuration_pageHeader")), "Configuration Details");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Change trace logging and check the status
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testTraceLogging(){

		try{
		Configuration.setTraceLogging(driver, "Disabled");
		SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_configuration_status")), "Configuration settings updated successfully."),"Configuration settings are not updated successfully");
		SeleniumUtil.click(driver,By.linkText(configObj.getPropertyValue("link_traceLogs_mainPage")));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_pageHeader")), "Trace Logs");
		SeleniumUtil.click(driver, By.linkText("click here"));
		SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_configuration_pageHeader")), "Configuration Details");
		Configuration.setTraceLogging(driver, "Enabled");
		SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_configuration_status")), "Configuration settings updated successfully."),"Configuration settings are not updated successfully");
		driver.navigate().refresh();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Change log level and check the status
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testLogLevel(){
		
		try{
		String level;
		String logLevels[]={"TRACE","DEBUG","INFO","WARN","ERROR","FATAL","OFF"};
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_logLevelDropDown")));
		for(int i=1;i<logLevels.length;i++)
		{
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath("//select[@id='loglevel']/option["+i+"]"),logLevels[i-1]),logLevels[i-1]+"is not available in drop down list ");
			  }
		else{
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath("//div[contains(@class,'select2-drop')]/ul/li["+i+"]/div"),logLevels[i-1]),logLevels[i-1]+"is not available in drop down list ");
		}
		}
		if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
		  {
		SeleniumUtil.waitForElement(driver,By.xpath(configObj.getPropertyValue("text_selectedLogLevel")));
		level=SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("text_selectedLogLevel")));
		  }
		else{
			SeleniumUtil.waitForElement(driver,By.xpath(configObj.getPropertyValue("text_displayedLogLevel")));
		level=SeleniumUtil.getVisibleText(driver,By.xpath(configObj.getPropertyValue("text_displayedLogLevel")));
		}
		driver.navigate().refresh();
		if(!level.equalsIgnoreCase("INFO")){
		Configuration.setLogLevel(driver, "INFO");
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_configuration_status")), "Configuration settings updated successfully."),"Configuration settings are not updated successfully");
		Configuration.setLogLevel(driver, "DEBUG");
		driver.navigate().refresh(); 
		}
		else{
			Configuration.setLogLevel(driver, "DEBUG");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_configuration_status")), "Configuration settings updated successfully."),"Configuration settings are not updated successfully");
			Configuration.setLogLevel(driver, "INFO");
			driver.navigate().refresh();
		} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		///Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
		if(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("btn_collapse"))))
		  {
			  SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_collapse")));
			  ///SeleniumUtil.delay(2000);
			  SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("txt_propertyNameTitle")));
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-state-default ui-jqgrid-hdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[@class='ui-jqgrid-bdiv' and contains(@style,'display: none')]")), "Collpase button is not working");
			  SeleniumUtil.click(driver, By.xpath("//a[contains(@class,'HeaderButton')]"));
			  SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("txt_propertyNameTitle")));
			  Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("txt_propertyNameTitle"))),"Collpase button is not working");
		  }
	}*/
	
	/*
	 * verify maximize and minimize
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testMinimizeAndMaximize()
	{
		
		try{
		List<WebElement> ls1= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_btn_minimize"))); 
		for(WebElement element : ls1)
		{
			element.click();
		}
		//verifies whether all the fields are minimized 
		List<WebElement> ls2= driver.findElements(By.xpath("//tbody/tr[contains(@style,'display: none;')]")); 
		Assert.assertTrue(ls2.size()>0,"Fields are not minimized");
		ls1= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_btn_maximize"))); 
		for(WebElement element : ls1)
		{
			element.click();
		}
		//verifies whether all the fields are maximized
		ls2= driver.findElements(By.xpath("//tbody/tr[contains(@style,'display: none;')]"));
		Assert.assertTrue(ls2.size()==0,"All the fields are not maximized");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Change monitoring data retention period and check the status
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testMonitoringDataRetention(){

		try{
		String period[]={"OFF","10 Days","20 Days","30 Days","60 Days","90 Days","120 Days","180 Days"};
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_dataRetentionDropDown")));
		for(int i=1;i<period.length;i++)
		{
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath("//select[@id='retentionperiod']/option["+i+"]"),period[i-1]),period[i-1]+" is not available in drop down list ");
			  }
			else{
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath("//div[contains(@class,'select2-drop')]/ul/li["+i+"]/div"),period[i-1]),period[i-1]+"is not available in drop down list ");
			}
		}
		driver.navigate().refresh();
			Configuration.setDataRetentionPeriod(driver, "10 Days");
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("txt_configuration_status")), "Configuration settings updated successfully."),"Configuration settings are not updated successfully");
			Configuration.setDataRetentionPeriod(driver, "180 Days");
			driver.navigate().refresh();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify page title
	 */
	
	@Override
	protected String getPageId() {
		return "configuration";
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return null;
	}
	
	@AfterTest
	public void tearDown(){
		
		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
