package com.kony.sync.console.webdriver;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.kony.sync.console.webdriver.utils.SeleniumConfigProperties;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class BaseTestcase
{
  public static final Logger logger = Logger.getLogger(BaseTestcase.class);
  public WebDriver driver;
  public String baseUrl;
  public StringBuffer verificationErrors = new StringBuffer();
  public static SeleniumConfigProperties configObj;

  
  public static void loadConfigurationFile()
  {
	  
    configObj = SeleniumConfigProperties.getInstance();
    if (configObj == null) {
      System.out.println("Could not load Selenium properties file.Existing...");
      logger.info("Could not load Selenium properties file.Existing...");
      Assert.fail("Could not load Selenium properties file.Existing...");
    }
    
  }

  public void setUp() throws Exception
  
  {
    loadConfigurationFile();

    String browser = configObj.getPropertyValue("browser");

    if (browser.equals("ie")) {
      
    	System.setProperty("webdriver.ie.driver", SeleniumConfigProperties.getProjectHome()+"//resources//drivers//IEDriverServer.exe");
    	driver = new InternetExplorerDriver();
    	
    } else if (browser.equals("firefox")) {
    	
    	FirefoxProfile profileAutoUser = new FirefoxProfile();

    	profileAutoUser.setPreference("browser.download.manager.showWhenStarting",false);
    	profileAutoUser.setPreference("browser.download.folderList",2);
    	profileAutoUser.setPreference("browser.helperApps.neverAsk.saveToDisk","application/octet-stream,application/zip,text/xml");
    	
        DesiredCapabilities capFF = DesiredCapabilities.firefox();
        capFF.setCapability(FirefoxDriver.PROFILE, profileAutoUser);
    	
    	driver = new FirefoxDriver(profileAutoUser);
      
    } else if (browser.equals("chrome")) {
    	
    	System.setProperty("webdriver.chrome.driver", SeleniumConfigProperties.getProjectHome()+"//resources//drivers//chromedriver.exe");
    	driver = new ChromeDriver();
    	
    } else {
    	
    	logger.info("Browser value not configured in Selenium.Properties File , taking the default value as firefox");
    	driver = new FirefoxDriver();
    }
    driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	
  }
  
	/*
	 * DEF492 : verify page title
	 */
  
	@Test(enabled=true, timeOut=300000)
	public void testPageTitleDEF492(){
		
		try{
		String key = getPageId();
		if(key != null){
			Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_" + getPageId())), "page title is not appropriate");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	protected abstract String getPageId();
	
	/*
	 * verify search by % and _
	 */
/*	@Test(enabled=true, timeOut=300000)
	public void testSearchBySpecialCharacters() throws Exception{
		
		List<WebElement> elements=driver.findElements(By.xpath("//th[not(contains(@style,'none'))]//input[contains(@id,'gs_') and not(contains(@class,'hasDatepicker'))]")); 
		for(WebElement element:elements)
		{
			element.sendKeys("%_"+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath("//div[contains(@class,'loading')]"));
			if(SeleniumUtil.isElementDisplayed(driver, By.xpath("//div[@aria-labelledby='ui-dialog-title-alertDialog']//button[1]")))
			{
				SeleniumUtil.click(driver, By.xpath("//div[@aria-labelledby='ui-dialog-title-alertDialog']//button[1]"));
			}
			else{
				Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath("//div[contains(@id,'rec') or contains(@id,'Rec') and contains(@style,'red')]"), "No records to show"), "Search is not working when searched with invalid characters like %_");
			}
			element.clear();
		}
	}*/
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Test(enabled=true, timeOut=300000)
	public void testCalendarFieldEventAffectOnPage() throws Exception{
		
		String key = getSearchId();
		if(key != null){
			SeleniumUtil.waitForElement(driver, By.id(key));
			if(!SeleniumUtil.isElementDisplayed(driver, By.xpath(configObj.getPropertyValue("txt_noRecordsToShow"))))
			{
				List<WebElement> elements=SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("tbxs_dateTimeFields")));
				for(WebElement element:elements)
				{
					SeleniumUtil.setText(driver, By.id(key), "abcxyz");
					element.click();
					element.sendKeys(Keys.TAB);
					SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
					Assert.assertFalse(SeleniumUtil.isElementDisplayed(driver, By.xpath(configObj.getPropertyValue("txt_noRecordsToShow"))), "Calendar is automatically triggering an event which is effecting other fields on the page");
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
				}
			}
		}
		
	}

	protected abstract String getSearchId();
	
	@AfterMethod
	public void afterMethod() throws Exception{
		
		System.out.println("in after method");
		if(SeleniumUtil.isElementPresent(driver,By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin"))) && !SeleniumUtil.isElementDisplayed(driver, By.xpath(configObj.getPropertyValue("win_dataSourceLog"))))
		{
			if(!SeleniumUtil.isElementDisplayed(driver, By.xpath(configObj.getPropertyValue("win_viewAppHistory"))))
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_cornerCloseModelWin")));
		}
		
	}
  
}