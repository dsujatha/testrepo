package com.kony.sync.console.webdriver.logs;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.login.Login;
import com.kony.sync.console.webdriver.users.Users;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public class LogsTest extends BaseTestcase{

	@BeforeTest
	public void loadDriver() {
		
		try {
			super.setUp();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@BeforeMethod
	public void setUp(){

		try{
		if(!SeleniumUtil.isElementPresent(driver, By.linkText(configObj.getPropertyValue("link_logout"))))
		{
			driver.get(configObj.getPropertyValue("baseUrl"));
			driver.manage().window().maximize();
			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		}
			driver.manage().window().maximize();
			SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_traceLogs_mainPage")));
			Logs.navigateToTraceLogsPage(driver);
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_pageHeader")), "Trace Logs");
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/*
	 *     Sync-325.a:Verifying of User ID
	 */

	@Test(priority=1,enabled=true, timeOut=300000)
	public void testUserIDLink(){
		
		try{
		Logs.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){

			Logs.clickOnLink(driver, "syncadmin");
			driver.switchTo().activeElement();
			// verify user details like user id, username, email, mobile
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_userD_userID")), "syncadmin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_userD_userName")), "Sync Admin"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_userD_userEmail")), "syncadmin@konylabs.com"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_userD_Mobile")), "1234567890"));

		}else{
			Assert.fail("User ID not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}


	/*
	 *  	Sync-325.b:Verifying of Device ID
	 */

	@Test(priority=2,enabled=true, timeOut=300000)
	public void testDeviceIDLink(){
		
		try{
		Logs.searchByDeviceID(driver, "000");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_deviceID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("000000000000000"))){

			Logs.clickOnLink(driver, "000000000000000");
			driver.switchTo().activeElement();
			// verify user details like device id, device OS, device Model, device OS version
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_DeviceD_deviceID")), "000000000000000"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_DeviceD_deviceOS")), "android"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_DeviceD_deviceModel")), "google_sdk"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_DeviceD_deviceVersion")), "2.2"));

		}else{
			Assert.fail("Device ID not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}


	/*
	 * Sync-324:Verifying of Application Link
	 */

	@Test(priority=3,enabled=true, timeOut=300000)
	public void testApplicationIDLink(){

		try{
		Logs.searchByApplicationID(driver, "pers");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_applicationID")));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("PersMSSql"))){
			String parentWindow= driver.getWindowHandle();
			Logs.clickOnLink(driver, "PersMSSql");
			SeleniumUtil.delay(1000);
			Set<String> handles=driver.getWindowHandles();
			Assert.assertTrue(handles.size() == 2,"Application Id link is not working");
			
			 for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		    	   driver.switchTo().window(windowHandle);
		    	   driver.close();
		    	   break;
		          }
		       }
		         driver.switchTo().window(parentWindow);

		}else{
			Assert.fail("Application ID not found.");
		}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/*
	 *  Sync-326:Verify HTTP Request
	 */

	@Test(priority=4,enabled=true, timeOut=300000)
	public void testHttpRequestLink(){

		try{
		Logs.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID")));
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){

			Logs.clickOnLink(driver, "View Http Request");
			driver.switchTo().activeElement();

			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("win_traceLogs_httpRequest")), "Http Request"));
			// verify HTTP request details like Trace logs, Request headers, Request body,Request body button, close button
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_httpRequest"))).isEmpty());
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpRequest_method"))).isEmpty());
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpRequest_uri"))).isEmpty());
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_httpRequest_reqHeader")), "Request Headers"));
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpRequest_reqHeaderBody"))).isEmpty());

			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_httpRequest_requestBody")), "Request Body"));
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpRequest_requestBodyData"))).isEmpty());
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[contains(@id,'exceptiondiv') and contains(@style,'none')]")),"Raw request body is shown with out clicking on show");
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_showHide")));
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath("//div[contains(@id,'exceptiondiv') and contains(@style,'display')]")),"Raw request body is not shown");
			Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("btn_showHide"))).equalsIgnoreCase("Show Raw Request Body"), "Value of button is not changed to 'hide' even after raw data is shown");
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_showHide")));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.className(configObj.getPropertyValue("btn_close_win")),"Close"));
			
		}else{
			Assert.fail("HTTP request link not found.");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}


	/*
	 *  Sync-327:Verify HTTP Response
	 */

	@Test(priority=5,enabled=true, timeOut=300000)
	public void testHttpResponseLink(){
		
		try{
		Logs.searchByUserID(driver, "sync");
		SeleniumUtil.clear(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID")));
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		if(SeleniumUtil.isElementPresent(driver, By.linkText("syncadmin"))){

			Logs.clickOnLink(driver, "View Http Response");
			driver.switchTo().activeElement();
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("win_traceLogs_httpResponse")), "Http Response"),"HTTP response layout is not opened or its title might be wrong");
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_httpResponse"))).isEmpty());
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpResponse_method"))).isEmpty());
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpResponse_uri"))).isEmpty());
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpResponse_resHeader"))).isEmpty());
			Assert.assertFalse(SeleniumUtil.getVisibleText(driver, By.xpath(configObj.getPropertyValue("txt_httpResponse_resHeaderBody"))).isEmpty());
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_httpResponse_responseBody")), "Response Body"));
			Assert.assertTrue(SeleniumUtil.waitForText(driver, By.className(configObj.getPropertyValue("btn_close_win")),"Close"));
		}
		else{
			Assert.fail("HTTP response link not found.");
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}


	/*
	 * Sync-328:Sync Service Log
	 */
	
	@Test(priority=31,enabled=true, timeOut=300000)
	public void testSyncServiceLog() throws Exception{
	SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_syncServiceLogs_mainPage")));
		
		String parentWindow = driver.getWindowHandle();
		Logs.navigateToSyncServiceLogsPage(driver);
		SeleniumUtil.delay(10000);
		
		Set<String> handles =  driver.getWindowHandles();
		   for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		          driver.switchTo().window(windowHandle);
		    try{
		    	
		  		if(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("tbx_userID"))))
				{
		  			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		  			String url=configObj.getPropertyValue("baseUrl");
		  			String serviceUrl= url.replace("syncconsole/login.jsp", "syncservice/tracker/log");
		  			driver.get(serviceUrl);
		  			SeleniumUtil.delay(10000);
				}
		  		
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_syncServiceLogs_sideBar")), "Sync Service Logs");
			SeleniumUtil.delay(15000);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("cbx_serviceLogs")));
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("cbx_serviceLogs")));
			SeleniumUtil.delay(4000);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("txtArea_serviceLogs")));
			Assert.assertTrue(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("txtArea_serviceLogs"))).getAttribute("wrap").equalsIgnoreCase("off"), "Wrap log is not in off mode");
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("cbx_serviceLogs")));
			SeleniumUtil.delay(2000);
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
			Assert.assertTrue(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("txtArea_serviceLogs"))).getAttribute("wrap").equalsIgnoreCase("soft"), "Wrap log is not in on mode");
			}
			else{
				Assert.assertTrue(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("txtArea_serviceLogs"))).getAttribute("wrap").equalsIgnoreCase("on"), "Wrap log is not in on mode");
			}
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_serviceLogs_refresh"))), "Refresh is not present");
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_serviceLogs_download"))), "Download is not present");
			Logs.clickOnLink(driver, "Configuration");
			Assert.assertTrue(driver.getCurrentUrl().contains("config"), "Configuration page is not opened");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_filter")), "Licensing");
			List<WebElement> lsLabel= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_serviceLogs_config_Logger")));
			List<WebElement> lsSelect= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_serviceLogs_config_level")));
			String logLevels[]={"TRACE","DEBUG","INFO","WARN","ERROR","FATAL","OFF"};
			for(WebElement element:lsLabel)
			{
				Assert.assertTrue(element.getText().toLowerCase().contains("Licensing".toLowerCase()),"Search is not working");
			}
			for(WebElement element:lsSelect)
			{
				for(int i=0;i<7;i++)
				{
                Assert.assertTrue(element.getText().toLowerCase().contains(logLevels[i].toLowerCase()),"Log levels are not present");				
				}
			}
		    }
		    finally{
		    	driver.close(); //closing child window
		        driver.switchTo().window(parentWindow); //cntrl to parent window
		    }
				
		}
	}
		   
	}

	/*
	 * Sync-329:Sync Console Log
	 * DEF498:SyncConsole logs not getting opened when user tries to edit any editable component like users/groups/applications.
	 */
	
	@Test(priority=32,enabled=true, timeOut=300000)
	public void testSyncConsoleLogDEF498() throws Exception{
		
		Users.navigateToUsersHomePage(driver);
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("link_users_firstUser")));
		Logs.navigateToTraceLogsPage(driver);
		String parentWindow = driver.getWindowHandle();
		Logs.navigateToSyncConsoleLogsPage(driver);
		SeleniumUtil.delay(10000);
		
		Set<String> handles =  driver.getWindowHandles();
		   for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		          driver.switchTo().window(windowHandle);
		    try{
		    	
		    	if(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("tbx_userID"))))
				{
		  			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		  			String url=configObj.getPropertyValue("baseUrl");
		  			String serviceUrl= url.replace("syncconsole/login.jsp", "syncconsole/tracker/log");
		  			driver.get(serviceUrl);
		  			SeleniumUtil.delay(10000);
				}
		    	
			SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_syncConsoleLogs_sideBar")), "Sync Console Logs");
			SeleniumUtil.delay(15000);
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("cbx_consoleLogs")));
			while(!SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("cbx_consoleLogs"))).isSelected())
			{
				SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("cbx_consoleLogs")));
			}
			SeleniumUtil.delay(2000);
			SeleniumUtil.waitForElement(driver, (By.id(configObj.getPropertyValue("txtArea_consoleLogs"))));
			Assert.assertTrue(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("txtArea_consoleLogs"))).getAttribute("wrap").equalsIgnoreCase("off"), "Wrap log is not in off mode");
			SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("cbx_consoleLogs")));
			SeleniumUtil.delay(2000);
			if(configObj.getPropertyValue("browser").equalsIgnoreCase("ie"))
			  {
			Assert.assertTrue(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("txtArea_consoleLogs"))).getAttribute("wrap").equalsIgnoreCase("soft"), "Wrap log is not in on mode");
			}
			else{
				Assert.assertTrue(SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("txtArea_consoleLogs"))).getAttribute("wrap").equalsIgnoreCase("on"), "Wrap log is not in on mode");
			}
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_consoleLogs_refresh"))), "Refresh is not present");
			Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("btn_consoleLogs_download"))), "Download is not present");
			
			Logs.clickOnLink(driver, "Configuration");
			Assert.assertTrue(driver.getCurrentUrl().contains("config"), "Configuration page is not opened");
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_filter")), "Licensing");
			List<WebElement> lsLabel= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_consoleLogs_config_Logger")));
			List<WebElement> lsSelect= SeleniumUtil.findElements(driver,By.xpath(configObj.getPropertyValue("list_consoleLogs_config_level")));
			String logLevels[]={"TRACE","DEBUG","INFO","WARN","ERROR","FATAL","OFF"};
			for(WebElement element:lsLabel)
			{
				Assert.assertTrue(element.getText().toLowerCase().contains("Licensing".toLowerCase()),"Search is not working");
			}
			for(WebElement element:lsSelect)
			{
				for(int i=0;i<7;i++)
				{
                Assert.assertTrue(element.getText().toLowerCase().contains(logLevels[i].toLowerCase()),"Log levels are not present");				
				}
			}
		    }
		    finally{
		    	driver.close(); //closing child window
		        driver.switchTo().window(parentWindow); //cntrl to parent window
		    }
		          }
		       }
		   
	}

	/*
	 *  Sync-330:Searching based on User ID with a valid search text
	 */

	@Test(priority=6,enabled=true, timeOut=300000)
	public void testValidSearchByUserID(){
		
		try{
		Logs.searchByUserID(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "sync",configObj.getPropertyValue("txt_logs_userIdInEachRow")),"User Id search is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/*
	 *  Sync-330:Searching based on User ID with invalid search text
	 */

	@Test(priority=7,enabled=true, timeOut=300000)
	public void testInValidSearchByUserID(){

		try{
		Logs.searchByUserID(driver, "abcxyz");
		Assert.assertTrue(Logs.getRowCount(driver) == 0,"Search by user ID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/*
	 *  Sync-330.a:Searching based on Device ID - with a valid search text
	 */

	@Test(priority=8,enabled=true, timeOut=300000)
	public void testValidSearchByDeviceID(){

		try{
		Logs.searchByDeviceID(driver, "000");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "000",configObj.getPropertyValue("txt_logs_deviceIdInEachRow")),"device Id search is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/*
	 *  Sync-330.b:Searching based on Device ID - with a invalid search text
	 */

	@Test(priority=9,enabled=true, timeOut=300000)
	public void testInvalidSearchByDeviceID(){

		try{
		Logs.searchByDeviceID(driver, "111000");
		Assert.assertTrue(Logs.getRowCount(driver) == 0,"Search by device ID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_deviceID"))).equals("111000"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/* 
	 * Sync-331:Searching based on Application ID- with a valid search text 
	 */

	@Test(priority=10,enabled=true, timeOut=300000)
	public void testValidSearchByApplicationID(){

		try{
		Logs.searchByApplicationID(driver, "pers");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "pers",configObj.getPropertyValue("txt_logs_applicationIdInEachRow")),"Application ID search is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/* 
	 * Sync-331:Searching based on Application ID- with a invalid search text
	 */

	@Test(priority=11,enabled=true, timeOut=300000)
	public void testInValidSearchByApplicationID(){

		try{
		Logs.searchByApplicationID(driver, "abcxyz");
		Assert.assertTrue(Logs.getRowCount(driver) == 0,"Search by Application ID is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		 Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_applicationID"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

/*
	 //UI changed
	 * Sync-332,333: Searching based on valid log Date, Time
	 * 
	@Test(enabled=true, timeOut=300000)
	public void testValidSearchByValidLogTime() throws Exception{

		// valid search by time format "mm/dd/yyyy hh:mm:ss"
		Logs.searchByLogDateTime(driver, "07/23/2013 18:11:20");
		SeleniumUtil.waitForElement(driver, By.linkText("syncadmin"));
		Assert.assertTrue(Logs.getRowCount(driver) == 1,"Search by logtime is not working");

	}

	 * Sync-332,333: Searching based on invalid log Date, Time
	 * 

	@Test(enabled=true, timeOut=300000)
	public void testInValidSearchByInvalidLogTime() throws Exception{

		// valid search by date time format "mm/dd/yyyy hh:mm:ss"
		Logs.searchByLogDateTime(driver, "07/24/2013 18:08:00");
		SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("msg_logs_SyncRecord")), "No records to show");
		Assert.assertTrue(Logs.getRowCount(driver) == 0,"Search by logtime is not working");
	}*/
	
	
	@Test(priority=12,enabled=true, timeOut=300000)
	public void testValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_pageHeader")), "Trace Logs"))
		{
			Logs.searchByStartAndEndTime(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530");
		Assert.assertTrue(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "07/23/2012 17:47:38 +0530", "03/23/2030 20:27:45 +0530", "grid_traceLogs", configObj.getPropertyValue("txt_logs_startTimeInEachRow"), configObj.getPropertyValue("txt_logs_endTimeInEachRow")),"Valid search for start and end time together is not working.");
	}
		else {
			Assert.fail("TraceLogs page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(priority=13,enabled=true, timeOut=300000)
	public void testInValidSearchStartAndEndtime(){
		
		try{
		if(SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_traceLogs_pageHeader")), "Trace Logs"))
		{
			Logs.searchByStartAndEndTime(driver, "03/23/2030 20:27:45 +0530", "07/23/2013 17:47:38 +0530");
		Assert.assertFalse(SeleniumUtil.verifyInitialLaterDateTimeOnSearch(driver, "03/23/2030 20:27:45 +0530", "07/23/2013 17:47:38 +0530", "grid_traceLogs",configObj.getPropertyValue("txt_logs_startTimeInEachRow"), configObj.getPropertyValue("txt_logs_endTimeInEachRow")),"Invalid search for start and end time together is not working.");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_startTime"))).contains("03/23/2030 20:27:45"), "Text in the search field is not cleared after refreshing");

	}
		else {
			Assert.fail("TraceLogs page is not obtained");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
/*	// UI changed 
	 * Sync-323:Record Trace logs for Insert Update and Delete Actions
	 
	@Test(enabled=true, timeOut=300000)
	public void testLogFields() throws Exception{
		
		String Fields[]= {"","User ID","Device ID","Application ID","Log Date Time","Http Request","Http Response","Response Code"};
		List<WebElement> element=driver.findElements(By.xpath("//tr[@class='ui-jqgrid-labels']/th/div"));
		int count=0;
		for(WebElement e:element)
		{
			Assert.assertTrue(e.getText().equalsIgnoreCase(Fields[count]), "Fields are not matching");
			count++;
		}
	}*/
	
	/*
	 * Verifying page info
	 */
	
	@Test(priority=14,enabled=true, timeOut=300000)
	public void testPageInfo()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_traceLogs"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying refresh
	 */
	
	@Test(priority=15,enabled=true, timeOut=300000)
	public void testRefresh()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh(driver, "grid_traceLogs", By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying calendar
	 */
	
	@Test(priority=16,enabled=true, timeOut=300000)
	public void testCalendar()
	{
		
		try{
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_startTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		SeleniumUtil.clickAndWait(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_endTime")),1000);
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("datePicker")));
		Assert.assertTrue(SeleniumUtil.isElementPresent(driver, By.xpath(configObj.getPropertyValue("datePicker"))),"Calendar is not present");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for start time
	 */
	
	@Test(priority=17,enabled=true, timeOut=300000)
	public void testCalendarForStartTime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_traceLogs_searchBy_startTime", "grid_traceLogs", "start")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Verifying calendar for end time
	 */
	
	@Test(priority=18,enabled=true, timeOut=300000)
	public void testCalendarForEndtime()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyTimeThroughCalendarAndSearch(driver,"tbx_traceLogs_searchBy_endTime", "grid_traceLogs", "end")," Time search through calendar is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(priority=19,enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForStartTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_traceLogs_searchBy_startTime"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying alternative clicks on updated on time field to check the presence of calendar
	 */
	
	@Test(priority=20,enabled=true, timeOut=300000)
	public void verifyAlternativeClicksForEndTimeField()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyAlternativeClicksForTimeField(driver, "tbx_traceLogs_searchBy_endTime"), "Calendar is not visible on alternate clicks");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
/*	
	 * Verifying Collapse button to minimize and expand the table
	 
	@Test(priority=21,enabled=true, timeOut=300000)
	public void testCollapseOfTable()
	{
		Assert.assertTrue(SeleniumUtil.verifyCollapseOfTable(driver),"Collapse of the table is not working");
	}*/
	
	/*
	 *Navigation to pages 
	 */
	
	@Test(priority=22,enabled=true, timeOut=300000)
	public void testNavigationOfPages()
	{
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *test size of page
	 */
	
	@Test(priority=23,enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayed()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify sorting of data - checks whether data is changing on the click of column name
	 */
	
	@Test(priority=24,enabled=true, timeOut=300000)
	public void testSortingOfData()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifySortingOfData(driver,2),"Data is not sorted on the click of column name");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify logs page title
	 */
	
	@Test(priority=25,enabled=true, timeOut=300000)
	public void testLogsPageTitle(){
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_traceLogs")), "page title is not appropriate");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify SyncServiceLogs page title
	 */
	
	@Test(priority=26,enabled=true, timeOut=300000)
	public void testSyncServiceLogsPageTitle() throws Exception{
		
		SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_syncServiceLogs_mainPage")));
		
		String parentWindow = driver.getWindowHandle();
		Logs.navigateToSyncServiceLogsPage(driver);
		SeleniumUtil.delay(10000);
		Set<String> handles =  driver.getWindowHandles();
		   for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		          driver.switchTo().window(windowHandle);
		          
			  		if(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("tbx_userID"))))
					{
			  			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
			  			String url=configObj.getPropertyValue("baseUrl");
			  			String serviceUrl= url.replace("syncconsole/login.jsp", "syncservice/tracker/log");
			  			driver.get(serviceUrl);
			  			SeleniumUtil.delay(10000);
					}
			  		
		         SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_syncServiceLogs_sideBar")), "Sync Service Logs");
		         try{
		         Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_syncServiceLogs")), "page title is not appropriate");
		         }
		         finally{
		         driver.close(); //closing child window
		         driver.switchTo().window(parentWindow); //cntrl to parent window
		         }
		          }
		       }
		   
	}
	
	/*
	 * verify SyncconsoleLogs page title
	 */
	
	@Test(priority=27,enabled=true, timeOut=300000)
	public void testSyncconsoleLogsPageTitle() throws Exception{
		
		SeleniumUtil.waitForElement(driver, By.linkText(configObj.getPropertyValue("link_syncConsoleLogs_mainPage")));
		
		String parentWindow = driver.getWindowHandle();
		Logs.navigateToSyncConsoleLogsPage(driver);
		SeleniumUtil.delay(10000);
		Set<String> handles =  driver.getWindowHandles();
		   for(String windowHandle  : handles)
		       {
		       if(!(windowHandle.equals(parentWindow)) && driver.getWindowHandles().size()==2)
		          {
		          driver.switchTo().window(windowHandle);
		          
		  		if(SeleniumUtil.isElementPresent(driver, By.id(configObj.getPropertyValue("tbx_userID"))))
				{
		  			Login.login(driver, configObj.getPropertyValue("username"), configObj.getPropertyValue("password"));
		  			String url=configObj.getPropertyValue("baseUrl");
		  			String serviceUrl= url.replace("syncconsole/login.jsp", "syncconsole/tracker/log");
		  			driver.get(serviceUrl);
		  			SeleniumUtil.delay(10000);
				}
		  		
		         SeleniumUtil.waitForText(driver, By.xpath(configObj.getPropertyValue("txt_syncConsoleLogs_sideBar")), "Sync Console Logs");
		         try{
		         Assert.assertTrue(SeleniumUtil.verifyPageTitle(driver, configObj.getPropertyValue("pagetitle_syncConsoleLogs")), "page title is not appropriate");
		         }
		         finally{
		         driver.close(); //closing child window
		         driver.switchTo().window(parentWindow); //cntrl to parent window
		         }
		          }
		       }
		       
	}
	
	/*
	 * verify page title
	 */
	@Override
	protected String getPageId() {
		return null;
	}
	
	/*
	 *  Searching based on request type with a valid search text
	 */

	@Test(priority=28,enabled=true, timeOut=300000)
	public void testValidSearchByRequestType(){

		try{
		Logs.searchByRequestType(driver, "load");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "load",configObj.getPropertyValue("txt_logs_requestTypeInEachRow")),"Request ID search is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}
	
	
	/*
	 *  Searching based on request type with a invalid search text
	 */

	@Test(priority=29,enabled=true, timeOut=300000)
	public void testInValidSearchByRequestType(){

		try{
		Logs.searchByRequestType(driver, "abcxyz");
		SeleniumUtil.delay(1000);
		Assert.assertTrue(Logs.getRowCount(driver) == 0,"Search by request type is not working");
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_refresh")));
		Assert.assertFalse(SeleniumUtil.getText(driver,By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_requestType"))).equals("abcxyz"), "Text in the search field is not cleared after refreshing");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * clear trace logs
	 */
	
	@Test( priority=41, enabled=true, timeOut=300000)
	public void testClearTraceLogs(){

		try{
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_clearTraceLogs")));
		SeleniumUtil.closeConfirmationBoxAndGetItsText(driver, true);
		SeleniumUtil.waitForText(driver,By.xpath(configObj.getPropertyValue("txt_noRecordsToShow")),"No records to show");
		Assert.assertTrue(Logs.getRowCount(driver)<1, "Trace logs are not cleared");
		Assert.assertTrue(SeleniumUtil.getVisibleText(driver,By.id(configObj.getPropertyValue("txt_clearLogs_status"))).equalsIgnoreCase("Cleared trace logs successfully."), "Cleared trace logs message is not given correctly");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *  Test show only errors
	 */

	@Test(priority=30,enabled=true, timeOut=300000)
	public void testShowOnlyErrors(){
		
		try{
		int rowCount=Logs.getRowCount(driver);
		int flag=2;
		for(int i=2;i<rowCount+2;i++)
		{
			if(!SeleniumUtil.getVisibleText(driver,By.xpath("//table[@id='traceloggrid']//tr["+i+"]/td[13]")).toLowerCase().contains("error"))
				break;
			flag++;
		}
		int beforeRowId=(Integer.parseInt(SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>0]["+flag+"]")).getAttribute("id")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_showOnlyErrors")));
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "Error",configObj.getPropertyValue("txt_logs_responseCodeInEachRow")),"Errors are not shown on the click of show only errors");
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_showOnlyErrors")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		int afterRowId=(Integer.parseInt(SeleniumUtil.findElement(driver,By.xpath("//table[contains(@id,'grid')]/tbody/tr[position()>0]["+flag+"]")).getAttribute("id")));
		Assert.assertEquals(beforeRowId, afterRowId,"Logs page is not showing the normal data after clicking on Show All Logs");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/*
	 * DEF521 : Search not working in Trace Logs when the option show only errors is used
	 * Test search after show only errors is clicked
	 */
	
	@Test(priority=33,enabled=true, timeOut=300000)
	public void testSearchAfterClickOnShowOnlyErrorsDEF521(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_showOnlyErrors")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_showOnlyErrors")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		Logs.searchByUserID(driver, "sync");
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "sync",configObj.getPropertyValue("txt_logs_userIdInEachRow")),"Search is not working after click of show only errors");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying the units of Request and Response columns
	 * DEF466 : Request and Response size units needed to be mentioned for better customer experience.
	 */
	
	@Test( priority=34, enabled=true, timeOut=300000)
	public void testCheckRequestAndResponseSizeUnitsDEF466(){

		try{
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("requestSizeColumnNameid")), "Request Size (Bytes)"),"Request size column is not displayed with unit");
		Assert.assertTrue(SeleniumUtil.waitForText(driver, By.id(configObj.getPropertyValue("responseSizeColumnNameid")), "Response Size (Bytes)"),"Response size column is not displayed with unit");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/*
	 * Verifying functionality of show only errors after navigating away from first page  
	 */
	
	@Test( priority=35, enabled=true, timeOut=300000)
	public void testShowOnlyErrorsOnNavigation(){
		
		try{
		SeleniumUtil.waitForElement(driver, By.xpath(configObj.getPropertyValue("btn_nextPage")));
		SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_nextPage")));
		SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("btn_showOnlyErrors")));
		SeleniumUtil.click(driver, By.id(configObj.getPropertyValue("btn_showOnlyErrors")));
		Assert.assertTrue(SeleniumUtil.verifySearchedContent(driver, configObj.getPropertyValue("grid_traceLogs"), "Error",configObj.getPropertyValue("txt_logs_responseCodeInEachRow")),"'Show Only Errors' button is not working after navigating away from the first page");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * verify affect of event on calendar field on other fields of the page
	 */
	
	@Override
	protected String getSearchId() {
		return configObj.getPropertyValue("tbx_traceLogs_searchBy_userID");
	}
	
	
	/*
	 * Verifying bottom refresh button
	 */
	
	@Test(priority=36, enabled=true, timeOut=300000)
	public void testRefreshBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyRefresh_bottom(driver, "grid_traceLogs", By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID"))),"Refresh is not working");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying page info bottom
	 */
	
	@Test(priority=37, enabled=true, timeOut=300000)
	public void testPageInfoBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyPagingInfo_bottom(driver,SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_traceLogs"))).findElements(By.tagName("tr")).size()-1),"Page info is not correct");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Navigation to pages at bottom
	 */
	
	@Test(priority=38, enabled=true, timeOut=300000)
	public void testNavigationOfPagesBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNavigationOfPages_bottom(driver),"Navigation of pages is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 *Test size of page at bottom
	 */
	
	@Test(priority=39, enabled=true, timeOut=300000)
	public void testNoOfRecordsToBeDisplayedBottom()
	{
		
		try{
		Assert.assertTrue(SeleniumUtil.verifyNoOfRecordsToBeDisplayed_bottom(driver),"No. of records to be diplayed in a page is not working as expected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Verifying DataSourceElapsedTime column
	 */
	
	@Test( priority=40, enabled=true, timeOut=300000)
	public void testDataSourceElapsedTime() throws Exception{
		
		List<WebElement> rows=SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_traceLogs"))).findElements(By.tagName("tr"));
		int rowCount = rows.size();
		if(rowCount > 1){
			for(int i=2; i<=rowCount; i++){
				try{
				if(Double.parseDouble(SeleniumUtil.findElement(driver, By.xpath(configObj.getPropertyValue("txt_logs_dataSourceElapsedTimeInEachRow").replace("$", i+""))).getText())>0)
				{
					SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("txt_logs_dataSourceElapsedTimeInEachRowWithSomeVal").replace("$", i+"")));
					SeleniumUtil.delay(2000);
					Assert.assertTrue(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))), "DataSourceLog Window is not opened");
					if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))))
					{
						SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close")));
					}
				}
				}
				catch(Exception e)
				{
					if(SeleniumUtil.isElementDisplayed(driver,By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close"))))
					{
						SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("logRowWin_dataSourceLog_close")));
					}
				}
			}
		}
		else {
			Assert.fail("There is no data in the table to verify DataSourceElapsedTime");
		}
		
	}
	
	@AfterTest
	public void tearDown(){

		try{
		System.out.println("tear down method called!!");
		driver.close();
		driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}	
}
