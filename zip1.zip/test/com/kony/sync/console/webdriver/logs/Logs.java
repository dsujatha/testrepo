package com.kony.sync.console.webdriver.logs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kony.sync.console.webdriver.BaseTestcase;
import com.kony.sync.console.webdriver.utils.SeleniumUtil;

public abstract class Logs extends BaseTestcase{
	
	private static List<WebElement> rowElements = new ArrayList<WebElement>();

	public static void navigateToTraceLogsPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_traceLogs_mainPage")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public static void clickOnLink(WebDriver driver, String linkName){

		try{
			SeleniumUtil.click(driver, By.linkText(linkName));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public static void navigateToSyncServiceLogsPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_syncServiceLogs_mainPage")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public static void navigateToSyncConsoleLogsPage(WebDriver driver){
		
		try{
			SeleniumUtil.click(driver, By.linkText(configObj.getPropertyValue("link_syncConsoleLogs_mainPage")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by user id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByUserID(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_userID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by device id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByDeviceID(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_deviceID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * search by application id
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByApplicationID(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_applicationID")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	/**
	 * get numbers of rows present in the traceLogs table
	 * @param driver
	 * @return count of rows
	 */
	
	public static int getRowCount(WebDriver driver){
		
		rowElements = null;
		try{

			WebElement table = SeleniumUtil.findElement(driver,By.id(configObj.getPropertyValue("grid_traceLogs")));
			rowElements = table.findElements(By.tagName("tr"));

		}catch(Exception e){
			e.printStackTrace();
		}
		return rowElements.size() - 1;
		
	}
	
	/**
	 * search by log date time
	 * @param driver
	 * @param log date time
	 */
	
	public static void searchByLogDateTime(WebDriver driver, String logDateTime){

		try{
			// wait for Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_logDateTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_logDateTime")), logDateTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_traceLogs_calender_Done")));
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by start and end date time
	 * @param driver
	 * @param startTime
	 * @param endTime
	 */
	
	public static void searchByStartAndEndTime(WebDriver driver, String startTime, String endTime){
		
		try{
			// wait for Start Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_startTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_startTime")), startTime);

			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_traceLogs_calender_Done")));
			// wait for the date and time to appear in the Start Time text box
			
			// wait for Start Time text box to be displayed on the page.
			SeleniumUtil.waitForElement(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_endTime")));
			// Type the date and time to search the record
			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_endTime")), endTime);
			// close the calendar control
			SeleniumUtil.click(driver, By.xpath(configObj.getPropertyValue("btn_traceLogs_calender_Done")));
			// wait for the date and time to appear in the Start Time text box
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * search by request type
	 * @param driver
	 * @param searchKey
	 */
	
	public static void searchByRequestType(WebDriver driver, String searchKey){

		try{

			SeleniumUtil.setText(driver, By.id(configObj.getPropertyValue("tbx_traceLogs_searchBy_requestType")), searchKey+Keys.RETURN);
			SeleniumUtil.waitForInvisibilityOfElement(driver, By.xpath(configObj.getPropertyValue("img_loading")));
		}catch(Exception e){
			e.printStackTrace();
		}

	}
}
