USE [master];
-- ###SYNCCONSOLE DROP AND CREATE###
IF EXISTS(SELECT name FROM sys.databases WHERE name = N'syncconsole') 
BEGIN
ALTER DATABASE [syncconsole] 
    SET SINGLE_USER 
    WITH ROLLBACK IMMEDIATE
DROP DATABASE [syncconsole] ;
END

CREATE DATABASE [syncconsole];
GO

IF NOT EXISTS(SELECT name FROM sys.databases WHERE name = N'syncconsole') 
BEGIN
	RAISERROR('Failed to create syncconsole database', 20, -1) with log;
	RETURN;
END

ALTER DATABASE [syncconsole] SET COMPATIBILITY_LEVEL = 100;

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [syncconsole].[dbo].[sp_fulltext_database] @action = 'enable'
end

ALTER DATABASE [syncconsole] SET ANSI_NULL_DEFAULT OFF

ALTER DATABASE [syncconsole] SET ANSI_NULLS OFF

ALTER DATABASE [syncconsole] SET ANSI_PADDING OFF

ALTER DATABASE [syncconsole] SET ANSI_WARNINGS OFF

ALTER DATABASE [syncconsole] SET ARITHABORT OFF

ALTER DATABASE [syncconsole] SET AUTO_CLOSE OFF

ALTER DATABASE [syncconsole] SET AUTO_CREATE_STATISTICS ON

ALTER DATABASE [syncconsole] SET AUTO_SHRINK OFF

ALTER DATABASE [syncconsole] SET AUTO_UPDATE_STATISTICS ON

ALTER DATABASE [syncconsole] SET CURSOR_CLOSE_ON_COMMIT OFF

ALTER DATABASE [syncconsole] SET CURSOR_DEFAULT  GLOBAL

ALTER DATABASE [syncconsole] SET CONCAT_NULL_YIELDS_NULL OFF

ALTER DATABASE [syncconsole] SET NUMERIC_ROUNDABORT OFF

ALTER DATABASE [syncconsole] SET QUOTED_IDENTIFIER OFF

ALTER DATABASE [syncconsole] SET RECURSIVE_TRIGGERS OFF

ALTER DATABASE [syncconsole] SET  DISABLE_BROKER

ALTER DATABASE [syncconsole] SET AUTO_UPDATE_STATISTICS_ASYNC OFF

ALTER DATABASE [syncconsole] SET DATE_CORRELATION_OPTIMIZATION OFF

ALTER DATABASE [syncconsole] SET TRUSTWORTHY OFF

ALTER DATABASE [syncconsole] SET ALLOW_SNAPSHOT_ISOLATION OFF

ALTER DATABASE [syncconsole] SET PARAMETERIZATION SIMPLE

ALTER DATABASE [syncconsole] SET READ_COMMITTED_SNAPSHOT OFF

ALTER DATABASE [syncconsole] SET HONOR_BROKER_PRIORITY OFF

ALTER DATABASE [syncconsole] SET  READ_WRITE

ALTER DATABASE [syncconsole] SET RECOVERY SIMPLE

ALTER DATABASE [syncconsole] SET  MULTI_USER

ALTER DATABASE [syncconsole] SET PAGE_VERIFY CHECKSUM

ALTER DATABASE [syncconsole] SET DB_CHAINING OFF
-- ###SYNCCONSOLE DROP AND CREATE###

USE [syncconsole];


/****** Object:  Table [dbo].[PROFILE_MASTER]    Script Date: 12/04/2012 22:02:53 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[PROFILE_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[detail] [varchar](255) NULL,
	[insertId] [varchar](255) NULL,
	[insertTimestamp] [datetime] NULL,
	[isDeleted] [tinyint] NULL,
	[isEnabled] [tinyint] NULL,
	[name] [varchar](255) NULL,
	[type] [varchar](255) NULL,
	[updateId] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF



/****** Object:  Table [dbo].[SECURITYAUDIT_MASTER]    Script Date: 03/31/2012 17:21:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[SECURITYAUDIT_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[action] [varchar](255) NULL,
	[actionDescription] [varchar](255) NULL,
	[insertTimestamp] [datetime] NULL,
	[userId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[ROLE_MASTER]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[ROLE_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[details] [varchar](255) NULL,
	[name] [varchar](255) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[USER_MASTER]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[USER_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[email] [varchar](200) NULL,
	[enterpriseId] [varchar](1000) NULL,
	[insertId] [varchar](255) NULL,
	[insertTimestamp] [datetime] NULL,
	[isDeleted] [tinyint] NULL,
	[isEnabled] [tinyint] NULL,
	[mobile] [varchar](255) NULL,
	[name] [varchar](1000) NOT NULL,
	[password] [varchar](200) NOT NULL,
	[updateId] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[userId] [varchar](100) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[APPLICATION_MASTER]    Script Date: 12/04/2012 22:02:53 ******/
/****** Object:  Table [dbo].[APPLICATION_MASTER]    Script Date: 12/18/2012 14:02:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[APPLICATION_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[applicationId] [varchar](100) NOT NULL,
	[description] [varchar](255) NULL,
	[insertId] [varchar](255) NULL,
	[insertTimestamp] [datetime] NULL,
	[isDeleted] [tinyint] NULL,
	[name] [varchar](1000) NOT NULL,
	[syncConfig] [text] NULL,
	[syncconfigxmlversion] [varchar](255) NULL,
	[updateId] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[profileId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[DEVICE_MASTER]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[DEVICE_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[OS] [varchar](255) NULL,
	[deviceId] [varchar](255) NOT NULL,
	[userAgent] [varchar](1000) NULL,
	[insertId] [varchar](255) NULL,
	[insertTimestamp] [datetime] NULL,
	[isDeleted] [tinyint] NULL,
	[isEnabled] [tinyint] NULL,
	[model] [varchar](255) NULL,
	[updateId] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[version] [varchar](255) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[GROUP_MASTER]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[GROUP_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[details] [varchar](2000) NOT NULL,
	[insertId] [varchar](255) NULL,
	[insertTimestamp] [datetime] NULL,
	[isDeleted] [tinyint] NULL,
	[name] [varchar](1000) NOT NULL,
	[updateId] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[DEVICE_USER]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

CREATE TABLE [dbo].[DEVICE_USER](
	[deviceid] [numeric](19, 0) NOT NULL,
	[userid] [numeric](19, 0) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[userid] ASC,
	[deviceid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

/****** Object:  Table [dbo].[CONFLICT_MASTER]    Script Date: 04/10/2012 19:51:24 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[CONFLICT_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[clientRow] [text] NULL,
	[conflictResolutionPolicy] [varchar](255) NULL,
	[errorMessage] [text] NULL,
	[insertTimestamp] [datetime] NULL,
	[mergedRow] [text] NULL,
	[serverRow] [text] NULL,
	[time] [datetime] NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NULL,
	[deviceId] [numeric](19, 0) NULL,
	[userId] [numeric](19, 0) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[CONFIGURATION_MASTER]    Script Date: 05/04/2012 14:55:14 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[CONFIGURATION_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[insertTimestamp] [datetime] NULL,
	[propName] [varchar](255) NOT NULL,
	[propValue] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[userId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[propName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[APPLICATION_GROUP]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

CREATE TABLE [dbo].[APPLICATION_GROUP](
	[applicationid] [numeric](19, 0) NOT NULL,
	[groupid] [numeric](19, 0) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[groupid] ASC,
	[applicationid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

/****** Object:  Table [dbo].[UPLOADQUEUE_MASTER]    Script Date: 04/10/2012 19:51:24 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[UPLOADQUEUE_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[errorMessage] [text] NULL,
	[insertTimestamp] [datetime] NULL,
	[numberOfRows] [numeric](19, 0) NULL,
	[requestEndTime] [datetime] NULL,
	[requestId] [numeric](19, 0) NULL,
	[requestStartTime] [datetime] NULL,
	[serverblob] [varchar](255) NULL,
	[status] [varchar](255) NULL,
	[totalBytesReceived] [numeric](19, 0) NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NULL,
	[deviceId] [numeric](19, 0) NULL,
	[userId] [numeric](19, 0) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[TRACELOG_MASTER]    Script Date: 05/17/2012 11:20:04 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[TRACELOG_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[insertTimestamp] [datetime] NULL,
	[rawRequest] [text] NULL,
	[request] [text] NULL,
	[requestHeader] [text] NULL,
	[requestId] [numeric](19, 0) NULL,
	[requestMethod] [varchar](255) NULL,
	[requestUri] [varchar](255) NULL,
	[response] [text] NULL,
	[responseCode] [int] NOT NULL,
	[responseHeader] [text] NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NULL,
	[deviceId] [numeric](19, 0) NULL,
	[userId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[SYNCHRONIZATION_MASTER]    Script Date: 04/10/2012 19:51:24 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[SYNCHRONIZATION_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[endTime] [datetime] NULL,
	[errorMessage] [text] NULL,
	[insertTimestamp] [datetime] NULL,
	[serviceName] [varchar](255) NULL,
	[startTime] [datetime] NULL,
	[totalBytesReceived] [int] NOT NULL,
	[totalBytesSent] [int] NOT NULL,
	[totalRowsReceived] [int] NOT NULL,
	[totalRowsSent] [int] NOT NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NOT NULL,
	[deviceId] [numeric](19, 0) NOT NULL,
	[userId] [numeric](19, 0) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF


/****** Object:  Table [dbo].[GROUP_USER]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

CREATE TABLE [dbo].[GROUP_USER](
	[groupid] [numeric](19, 0) NOT NULL,
	[userid] [numeric](19, 0) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[userid] ASC,
	[groupid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

/****** Object:  Table [dbo].[GROUP_ROLE]    Script Date: 02/27/2012 11:41:54 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

CREATE TABLE [dbo].[GROUP_ROLE](
	[roleid] [numeric](19, 0) NOT NULL,
	[groupid] [numeric](19, 0) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[groupid] ASC,
	[roleid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

/****** Object:  Table [dbo].[REPLICASERVICE_MASTER]    Script Date: 04/10/2012 19:51:24 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[REPLICASERVICE_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[endTime] [datetime] NULL,
	[errorMessage] [text] NULL,
	[insertTimestamp] [datetime] NULL,
	[numberOfBytes] [numeric](19, 0) NULL,
	[numberOfRows] [numeric](19, 0) NULL,
	[startTime] [datetime] NULL,
	[status] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[MERGESERVICE_MASTER]    Script Date: 04/10/2012 19:51:24 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[MERGESERVICE_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[endTime] [datetime] NULL,
	[errorMessage] [text] NULL,
	[insertTimestamp] [datetime] NULL,
	[numberOfBytes] [numeric](19, 0) NULL,
	[numberOfRows] [numeric](19, 0) NULL,
	[startTime] [datetime] NULL,
	[status] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NOT NULL,
	[uploadQueueId] [numeric](19, 0) NOT NULL,
	[userId] [numeric](19, 0) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[CONSOLE_JOB]    Script Date: 04/02/2012 18:08:56 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[CONSOLE_JOB](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[errorMessage] [text] NULL,
	[ipAddress] [varchar](255) NULL,
	[jobClass] [varchar](255) NULL,
	[nextFireTime] [datetime] NULL,
	[prevFireTime] [datetime] NULL,
	[startTime] [datetime] NULL,
	[status] [varchar](255) NULL,
	[triggerDetails] [varchar](255) NULL,
	[triggerType] [varchar](255) NULL,
	[applicationId] [numeric](19, 0) NOT NULL,
	[templateId] [numeric](19, 0) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[JOB_TEMPLATE]    Script Date: 03/22/2012 14:08:12 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[JOB_TEMPLATE](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[name] [varchar](200) NULL,
	[description] [varchar](255) NULL,
	[jobClass] [varchar](255) NULL,
	[triggerType] [varchar](255) NULL,
	[triggerDetails] [varchar](255) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[JOB_HISTORY]    Script Date: 04/02/2012 18:08:56 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[JOB_HISTORY](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[endTime] [datetime] NULL,
	[errorMessage] [text] NULL,
	[ipAddress] [varchar](255) NULL,
	[startTime] [datetime] NULL,
	[status] [varchar](255) NULL,
	[consoleJobId] [numeric](19, 0) NOT NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET ANSI_PADDING OFF





/****** Object:  Table [dbo].[CHANGEREPLAY_MASTER]    Script Date: 04/10/2012 19:51:24 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[CHANGEREPLAY_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[changeEndTime] [datetime] NULL,
	[changeStartTime] [datetime] NULL,
	[changeType] [varchar](255) NULL,
	[errorMessage] [text] NULL,
	[insertTimestamp] [datetime] NULL,
	[operation] [varchar](255) NULL,
	[request] [text] NULL,
	[response] [text] NULL,
	[target] [varchar](255) NULL,
	[uploadQueue] [numeric](19, 0) NULL,
	[applicationId] [numeric](19, 0) NULL,
	[deviceId] [numeric](19, 0) NULL,
	[userId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

SET ANSI_PADDING OFF



/****** Object:  Table [dbo].[CHANGETARGET_MASTER]    Script Date: 06/29/2012 14:11:35 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

CREATE TABLE [dbo].[CHANGETARGET_MASTER](
	[id] [numeric](19, 0) IDENTITY(1,1) NOT NULL,
	[insertTimestamp] [datetime] NULL,
	[operation] [varchar](255) NULL,
	[request] [text] NULL,
	[response] [text] NULL,
	[target] [varchar](255) NULL,
	[updateTimestamp] [datetime] NULL,
	[applicationId] [numeric](19, 0) NULL,
	[deviceId] [numeric](19, 0) NULL,
	[userId] [numeric](19, 0) NULL,
	[SYNCCOL1] [varchar](255) NULL,
	[SYNCCOL2] [varchar](255) NULL,
	[SYNCCOL3] [varchar](255) NULL,
	[SYNCCOL4] [varchar](255) NULL,
	[SYNCCOL5] [varchar](255) NULL,
	[SYNCCOL6] [varchar](255) NULL,
	[SYNCCOL7] [varchar](255) NULL,
	[SYNCCOL8] [varchar](255) NULL,
	[SYNCCOL9] [varchar](255) NULL,
	[SYNCCOL10] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET ANSI_PADDING OFF

/****** Object:  ForeignKey [FKFC7177208E326E43]    Script Date: 06/26/2012 12:06:35 ******/
ALTER TABLE [dbo].[CHANGETARGET_MASTER]  WITH CHECK ADD  CONSTRAINT [FKFC7177208E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[CHANGETARGET_MASTER] CHECK CONSTRAINT [FKFC7177208E326E43]

/****** Object:  ForeignKey [FKFC7177209AB21329]    Script Date: 06/26/2012 12:06:35 ******/
ALTER TABLE [dbo].[CHANGETARGET_MASTER]  WITH CHECK ADD  CONSTRAINT [FKFC7177209AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[CHANGETARGET_MASTER] CHECK CONSTRAINT [FKFC7177209AB21329]

/****** Object:  ForeignKey [FKFC717720FF859019]    Script Date: 06/26/2012 12:06:35 ******/
ALTER TABLE [dbo].[CHANGETARGET_MASTER]  WITH CHECK ADD  CONSTRAINT [FKFC717720FF859019] FOREIGN KEY([deviceId])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[CHANGETARGET_MASTER] CHECK CONSTRAINT [FKFC717720FF859019]







/****** Object:  ForeignKey [FK262090148E326E43]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[DEVICE_USER]  WITH CHECK ADD  CONSTRAINT [FK262090148E326E43] FOREIGN KEY([userid])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[DEVICE_USER] CHECK CONSTRAINT [FK262090148E326E43]

/****** Object:  ForeignKey [FK26209014FF859019]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[DEVICE_USER]  WITH CHECK ADD  CONSTRAINT [FK26209014FF859019] FOREIGN KEY([deviceid])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[DEVICE_USER] CHECK CONSTRAINT [FK26209014FF859019]

/****** Object:  ForeignKey [FKE78F6F6F8E326E43]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[CONFLICT_MASTER]  WITH CHECK ADD  CONSTRAINT [FKE78F6F6F8E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[CONFLICT_MASTER] CHECK CONSTRAINT [FKE78F6F6F8E326E43]

/****** Object:  ForeignKey [FKE78F6F6F9AB21329]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[CONFLICT_MASTER]  WITH CHECK ADD  CONSTRAINT [FKE78F6F6F9AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[CONFLICT_MASTER] CHECK CONSTRAINT [FKE78F6F6F9AB21329]

/****** Object:  ForeignKey [FKE78F6F6FFF859019]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[CONFLICT_MASTER]  WITH CHECK ADD  CONSTRAINT [FKE78F6F6FFF859019] FOREIGN KEY([deviceId])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[CONFLICT_MASTER] CHECK CONSTRAINT [FKE78F6F6FFF859019]

/****** Object:  ForeignKey [FKB54491EB8E326E43]    Script Date: 05/04/2012 14:55:14 ******/
ALTER TABLE [dbo].[CONFIGURATION_MASTER]  WITH CHECK ADD  CONSTRAINT [FKB54491EB8E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[CONFIGURATION_MASTER] CHECK CONSTRAINT [FKB54491EB8E326E43]

/****** Object:  ForeignKey [FK3277569051981047]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[APPLICATION_GROUP]  WITH CHECK ADD  CONSTRAINT [FK3277569051981047] FOREIGN KEY([groupid])
REFERENCES [dbo].[GROUP_MASTER] ([id])

ALTER TABLE [dbo].[APPLICATION_GROUP] CHECK CONSTRAINT [FK3277569051981047]

/****** Object:  ForeignKey [FK327756909AB21329]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[APPLICATION_GROUP]  WITH CHECK ADD  CONSTRAINT [FK327756909AB21329] FOREIGN KEY([applicationid])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[APPLICATION_GROUP] CHECK CONSTRAINT [FK327756909AB21329]
/****** Object:  ForeignKey [FK25C2CC514454509B]    Script Date: 12/18/2012 14:02:28 ******/
ALTER TABLE [dbo].[APPLICATION_MASTER]  WITH CHECK ADD  CONSTRAINT [FK25C2CC514454509B] FOREIGN KEY([profileId])
REFERENCES [dbo].[PROFILE_MASTER] ([id])

ALTER TABLE [dbo].[APPLICATION_MASTER] CHECK CONSTRAINT [FK25C2CC514454509B]

/****** Object:  ForeignKey [FKF99141F18E326E43]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[UPLOADQUEUE_MASTER]  WITH CHECK ADD  CONSTRAINT [FKF99141F18E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[UPLOADQUEUE_MASTER] CHECK CONSTRAINT [FKF99141F18E326E43]

/****** Object:  ForeignKey [FKF99141F19AB21329]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[UPLOADQUEUE_MASTER]  WITH CHECK ADD  CONSTRAINT [FKF99141F19AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[UPLOADQUEUE_MASTER] CHECK CONSTRAINT [FKF99141F19AB21329]

/****** Object:  ForeignKey [FKF99141F1FF859019]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[UPLOADQUEUE_MASTER]  WITH CHECK ADD  CONSTRAINT [FKF99141F1FF859019] FOREIGN KEY([deviceId])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[UPLOADQUEUE_MASTER] CHECK CONSTRAINT [FKF99141F1FF859019]

/****** Object:  ForeignKey [FKC85FF2C28E326E43]    Script Date: 05/03/2012 16:53:13 ******/
ALTER TABLE [dbo].[TRACELOG_MASTER]  WITH CHECK ADD  CONSTRAINT [FKC85FF2C28E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[TRACELOG_MASTER] CHECK CONSTRAINT [FKC85FF2C28E326E43]

/****** Object:  ForeignKey [FKC85FF2C29AB21329]    Script Date: 05/03/2012 16:53:13 ******/
ALTER TABLE [dbo].[TRACELOG_MASTER]  WITH CHECK ADD  CONSTRAINT [FKC85FF2C29AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[TRACELOG_MASTER] CHECK CONSTRAINT [FKC85FF2C29AB21329]

/****** Object:  ForeignKey [FKC85FF2C2FF859019]    Script Date: 05/03/2012 16:53:13 ******/
ALTER TABLE [dbo].[TRACELOG_MASTER]  WITH CHECK ADD  CONSTRAINT [FKC85FF2C2FF859019] FOREIGN KEY([deviceId])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[TRACELOG_MASTER] CHECK CONSTRAINT [FKC85FF2C2FF859019]

/****** Object:  ForeignKey [FKCC6E05418E326E43]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[SYNCHRONIZATION_MASTER]  WITH CHECK ADD  CONSTRAINT [FKCC6E05418E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[SYNCHRONIZATION_MASTER] CHECK CONSTRAINT [FKCC6E05418E326E43]

/****** Object:  ForeignKey [FKCC6E05419AB21329]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[SYNCHRONIZATION_MASTER]  WITH CHECK ADD  CONSTRAINT [FKCC6E05419AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[SYNCHRONIZATION_MASTER] CHECK CONSTRAINT [FKCC6E05419AB21329]

/****** Object:  ForeignKey [FKCC6E0541FF859019]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[SYNCHRONIZATION_MASTER]  WITH CHECK ADD  CONSTRAINT [FKCC6E0541FF859019] FOREIGN KEY([deviceId])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[SYNCHRONIZATION_MASTER] CHECK CONSTRAINT [FKCC6E0541FF859019]

/****** Object:  ForeignKey [FK6B1EC1AB51981047]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[GROUP_USER]  WITH CHECK ADD  CONSTRAINT [FK6B1EC1AB51981047] FOREIGN KEY([groupid])
REFERENCES [dbo].[GROUP_MASTER] ([id])

ALTER TABLE [dbo].[GROUP_USER] CHECK CONSTRAINT [FK6B1EC1AB51981047]

/****** Object:  ForeignKey [FK6B1EC1AB8E326E43]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[GROUP_USER]  WITH CHECK ADD  CONSTRAINT [FK6B1EC1AB8E326E43] FOREIGN KEY([userid])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[GROUP_USER] CHECK CONSTRAINT [FK6B1EC1AB8E326E43]

/****** Object:  ForeignKey [FK6B1D565651981047]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[GROUP_ROLE]  WITH CHECK ADD  CONSTRAINT [FK6B1D565651981047] FOREIGN KEY([groupid])
REFERENCES [dbo].[GROUP_MASTER] ([id])

ALTER TABLE [dbo].[GROUP_ROLE] CHECK CONSTRAINT [FK6B1D565651981047]

/****** Object:  ForeignKey [FK6B1D565688DD18D9]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[GROUP_ROLE]  WITH CHECK ADD  CONSTRAINT [FK6B1D565688DD18D9] FOREIGN KEY([roleid])
REFERENCES [dbo].[ROLE_MASTER] ([id])

ALTER TABLE [dbo].[GROUP_ROLE] CHECK CONSTRAINT [FK6B1D565688DD18D9]

/****** Object:  ForeignKey [FK918E19E49AB21329]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[REPLICASERVICE_MASTER]  WITH CHECK ADD  CONSTRAINT [FK918E19E49AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[REPLICASERVICE_MASTER] CHECK CONSTRAINT [FK918E19E49AB21329]

/****** Object:  ForeignKey [FK14A249648E326E43]    Script Date: 02/27/2012 19:37:50 ******/
ALTER TABLE [dbo].[MERGESERVICE_MASTER]  WITH CHECK ADD  CONSTRAINT [FK14A249648E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[MERGESERVICE_MASTER] CHECK CONSTRAINT [FK14A249648E326E43]

/****** Object:  ForeignKey [FK14A249649AB21329]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[MERGESERVICE_MASTER]  WITH CHECK ADD  CONSTRAINT [FK14A249649AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[MERGESERVICE_MASTER] CHECK CONSTRAINT [FK14A249649AB21329]

/****** Object:  ForeignKey [FK14A24964A2695DCD]    Script Date: 02/27/2012 11:41:54 ******/
ALTER TABLE [dbo].[MERGESERVICE_MASTER]  WITH CHECK ADD  CONSTRAINT [FK14A24964A2695DCD] FOREIGN KEY([uploadQueueId])
REFERENCES [dbo].[UPLOADQUEUE_MASTER] ([id])

ALTER TABLE [dbo].[MERGESERVICE_MASTER] CHECK CONSTRAINT [FK14A24964A2695DCD]

/****** Object:  ForeignKey [FKE154C959AB21329]    Script Date: 03/28/2012 16:14:54 ******/
ALTER TABLE [dbo].[CONSOLE_JOB]  WITH CHECK ADD  CONSTRAINT [FKE154C959AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[CONSOLE_JOB] CHECK CONSTRAINT [FKE154C959AB21329]

/****** Object:  ForeignKey [FKE154C95F46D2FAB]    Script Date: 03/28/2012 16:14:54 ******/
ALTER TABLE [dbo].[CONSOLE_JOB]  WITH CHECK ADD  CONSTRAINT [FKE154C95F46D2FAB] FOREIGN KEY([templateId])
REFERENCES [dbo].[JOB_TEMPLATE] ([id])

ALTER TABLE [dbo].[CONSOLE_JOB] CHECK CONSTRAINT [FKE154C95F46D2FAB]

/****** Object:  ForeignKey [FK950549D25C3B4068]    Script Date: 03/28/2012 16:14:54 ******/
ALTER TABLE [dbo].[JOB_HISTORY]  WITH CHECK ADD  CONSTRAINT [FK950549D25C3B4068] FOREIGN KEY([consoleJobId])
REFERENCES [dbo].[CONSOLE_JOB] ([id])

ALTER TABLE [dbo].[JOB_HISTORY] CHECK CONSTRAINT [FK950549D25C3B4068]

/****** Object:  ForeignKey [FK902BF40A8E326E43]    Script Date: 03/19/2012 18:55:25 ******/
ALTER TABLE [dbo].[CHANGEREPLAY_MASTER]  WITH CHECK ADD  CONSTRAINT [FK902BF40A8E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[CHANGEREPLAY_MASTER] CHECK CONSTRAINT [FK902BF40A8E326E43]

/****** Object:  ForeignKey [FK902BF40A9AB21329]    Script Date: 03/19/2012 18:55:25 ******/
ALTER TABLE [dbo].[CHANGEREPLAY_MASTER]  WITH CHECK ADD  CONSTRAINT [FK902BF40A9AB21329] FOREIGN KEY([applicationId])
REFERENCES [dbo].[APPLICATION_MASTER] ([id])

ALTER TABLE [dbo].[CHANGEREPLAY_MASTER] CHECK CONSTRAINT [FK902BF40A9AB21329]

/****** Object:  ForeignKey [FK902BF40AFF859019]    Script Date: 03/19/2012 18:55:25 ******/
ALTER TABLE [dbo].[CHANGEREPLAY_MASTER]  WITH CHECK ADD  CONSTRAINT [FK902BF40AFF859019] FOREIGN KEY([deviceId])
REFERENCES [dbo].[DEVICE_MASTER] ([id])

ALTER TABLE [dbo].[CHANGEREPLAY_MASTER] CHECK CONSTRAINT [FK902BF40AFF859019]

/****** Object:  ForeignKey [FK791A66A68E326E43]    Script Date: 03/31/2012 17:21:28 ******/
ALTER TABLE [dbo].[SECURITYAUDIT_MASTER]  WITH CHECK ADD  CONSTRAINT [FK791A66A68E326E43] FOREIGN KEY([userId])
REFERENCES [dbo].[USER_MASTER] ([id])

ALTER TABLE [dbo].[SECURITYAUDIT_MASTER] CHECK CONSTRAINT [FK791A66A68E326E43]



/***** Indexes *********/
CREATE INDEX USER_MASTER_INDEX ON USER_MASTER (USERID);
CREATE INDEX APPLICATION_MASTER_INDEX ON APPLICATION_MASTER (APPLICATIONID);
CREATE INDEX DEVICE_MASTER_INDEX ON DEVICE_MASTER (DEVICEID);

/****Inser statements to insert required data **/

SET IDENTITY_INSERT USER_MASTER ON


INSERT INTO USER_MASTER(id, email, enterpriseId, insertId, isDeleted, isEnabled, mobile, name, password, updateId, userId, insertTimestamp,updateTimestamp) 
    VALUES(1, 'syncadmin@konylabs.com', '', 'syncadmin', 0, 1, '1234567890', 'Sync Admin', '679ab80ab3880b5bf73a841cfe32f8dccf64edf10a0d21f1c3e1b8d6a3920948', 'syncadmin', 'syncadmin',getdate(),getdate());

SET IDENTITY_INSERT USER_MASTER OFF


SET IDENTITY_INSERT ROLE_MASTER ON

	
INSERT INTO ROLE_MASTER(id, details, name) VALUES(1, 'Represents the system administrator', 'ROLE_ADMIN');
INSERT INTO ROLE_MASTER(id, details, name) VALUES(2, 'Represents the report viewer who uses application for report viewing', 'ROLE_REPORT_VIEWER');
INSERT INTO ROLE_MASTER(id, details, name) VALUES(3, 'Represents the end user who access the application from a device', 'ROLE_USER');

SET IDENTITY_INSERT ROLE_MASTER OFF


SET IDENTITY_INSERT GROUP_MASTER ON


INSERT INTO GROUP_MASTER(id, details, insertId, isDeleted, name, updateId,insertTimestamp,updateTimestamp) 
	VALUES(1, 'This group represents Administrator', '',  0, 'Administrator', '',getdate(),getdate());
	
SET IDENTITY_INSERT GROUP_MASTER OFF


INSERT INTO GROUP_USER(userid, groupid) VALUES(1, 1);
INSERT INTO GROUP_ROLE(groupid, roleid) VALUES(1, 1);



SET IDENTITY_INSERT JOB_TEMPLATE ON


INSERT INTO JOB_TEMPLATE (id, name,description,jobClass,triggerType,triggerDetails) 
values (1, 'ReplicaService','Replica service job','com.kony.sync.services.job.ReplicaServiceJob','cron','0/10 * * * * ? *')
INSERT INTO JOB_TEMPLATE (id, name,description,jobClass,triggerType,triggerDetails) 
values (2, 'MergeService','Merge service job','com.kony.sync.services.job.MergeServiceJob','cron','0/10 * * * * ? *')


SET IDENTITY_INSERT JOB_TEMPLATE OFF


SET IDENTITY_INSERT CONFIGURATION_MASTER ON


INSERT INTO CONFIGURATION_MASTER (id, propName,propValue,insertTimestamp)
VALUES (1, 'enable.tracelog', '1', getdate())
INSERT INTO CONFIGURATION_MASTER (id, propName,propValue,insertTimestamp)
VALUES (2, 'log.level', 'INFO',  getdate())
INSERT INTO CONFIGURATION_MASTER (id, propName,propValue,insertTimestamp)
VALUES (3, 'diagnostics.retention.period', '90', getdate())


SET IDENTITY_INSERT CONFIGURATION_MASTER OFF;

/* Quartz Tables  */

CREATE TABLE [dbo].[QRTZ_CALENDARS] (
  [CALENDAR_NAME] [VARCHAR] (200)  NOT NULL ,
  [CALENDAR] [IMAGE] NOT NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_CRON_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL ,
  [CRON_EXPRESSION] [VARCHAR] (120)  NOT NULL ,
  [TIME_ZONE_ID] [VARCHAR] (80) 
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_FIRED_TRIGGERS] (
  [ENTRY_ID] [VARCHAR] (95)  NOT NULL ,
  [TRIGGER_NAME] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [INSTANCE_NAME] [VARCHAR] (200)  NOT NULL ,
  [FIRED_TIME] [BIGINT] NOT NULL ,
  [PRIORITY] [INTEGER] NOT NULL ,
  [STATE] [VARCHAR] (16)  NOT NULL,
  [JOB_NAME] [VARCHAR] (200)  NULL ,
  [JOB_GROUP] [VARCHAR] (200)  NULL ,
  [IS_STATEFUL] [VARCHAR] (1)  NULL ,
  [REQUESTS_RECOVERY] [VARCHAR] (1)  NULL 
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_PAUSED_TRIGGER_GRPS] (
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL 
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_SCHEDULER_STATE] (
  [INSTANCE_NAME] [VARCHAR] (200)  NOT NULL ,
  [LAST_CHECKIN_TIME] [BIGINT] NOT NULL ,
  [CHECKIN_INTERVAL] [BIGINT] NOT NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_LOCKS] (
  [LOCK_NAME] [VARCHAR] (40)  NOT NULL 
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_JOB_DETAILS] (
  [JOB_NAME] [VARCHAR] (200)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (200)  NOT NULL ,
  [DESCRIPTION] [VARCHAR] (250) NULL ,
  [JOB_CLASS_NAME] [VARCHAR] (250)  NOT NULL ,
  [IS_DURABLE] [VARCHAR] (1)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [IS_STATEFUL] [VARCHAR] (1)  NOT NULL ,
  [REQUESTS_RECOVERY] [VARCHAR] (1)  NOT NULL ,
  [JOB_DATA] [IMAGE] NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_JOB_LISTENERS] (
  [JOB_NAME] [VARCHAR] (200)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (200)  NOT NULL ,
  [JOB_LISTENER] [VARCHAR] (200)  NOT NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_SIMPLE_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL ,
  [REPEAT_COUNT] [BIGINT] NOT NULL ,
  [REPEAT_INTERVAL] [BIGINT] NOT NULL ,
  [TIMES_TRIGGERED] [BIGINT] NOT NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_BLOB_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL ,
  [BLOB_DATA] [IMAGE] NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_TRIGGER_LISTENERS] (
  [TRIGGER_NAME] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_LISTENER] [VARCHAR] (200)  NOT NULL
) ON [PRIMARY]


CREATE TABLE [dbo].[QRTZ_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (200)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (200)  NOT NULL ,
  [JOB_NAME] [VARCHAR] (200)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (200)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [DESCRIPTION] [VARCHAR] (250) NULL ,
  [NEXT_FIRE_TIME] [BIGINT] NULL ,
  [PREV_FIRE_TIME] [BIGINT] NULL ,
  [PRIORITY] [INTEGER] NULL ,
  [TRIGGER_STATE] [VARCHAR] (16)  NOT NULL ,
  [TRIGGER_TYPE] [VARCHAR] (8)  NOT NULL ,
  [START_TIME] [BIGINT] NOT NULL ,
  [END_TIME] [BIGINT] NULL ,
  [CALENDAR_NAME] [VARCHAR] (200)  NULL ,
  [MISFIRE_INSTR] [SMALLINT] NULL ,
  [JOB_DATA] [IMAGE] NULL
) ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_CALENDARS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_CALENDARS] PRIMARY KEY  CLUSTERED
  (
    [CALENDAR_NAME]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_CRON_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_CRON_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_FIRED_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_FIRED_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [ENTRY_ID]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_PAUSED_TRIGGER_GRPS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_PAUSED_TRIGGER_GRPS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_GROUP]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_SCHEDULER_STATE] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_SCHEDULER_STATE] PRIMARY KEY  CLUSTERED
  (
    [INSTANCE_NAME]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_LOCKS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_LOCKS] PRIMARY KEY  CLUSTERED
  (
    [LOCK_NAME]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_JOB_DETAILS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_JOB_DETAILS] PRIMARY KEY  CLUSTERED
  (
    [JOB_NAME],
    [JOB_GROUP]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_JOB_LISTENERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_JOB_LISTENERS] PRIMARY KEY  CLUSTERED
  (
    [JOB_NAME],
    [JOB_GROUP],
    [JOB_LISTENER]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_SIMPLE_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_SIMPLE_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_TRIGGER_LISTENERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_TRIGGER_LISTENERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP],
    [TRIGGER_LISTENER]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]


ALTER TABLE [dbo].[QRTZ_CRON_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_CRON_TRIGGERS_QRTZ_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE


ALTER TABLE [dbo].[QRTZ_JOB_LISTENERS] ADD
  CONSTRAINT [FK_QRTZ_JOB_LISTENERS_QRTZ_JOB_DETAILS] FOREIGN KEY
  (
    [JOB_NAME],
    [JOB_GROUP]
  ) REFERENCES [dbo].[QRTZ_JOB_DETAILS] (
    [JOB_NAME],
    [JOB_GROUP]
  ) ON DELETE CASCADE


ALTER TABLE [dbo].[QRTZ_SIMPLE_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_SIMPLE_TRIGGERS_QRTZ_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE


ALTER TABLE [dbo].[QRTZ_TRIGGER_LISTENERS] ADD
  CONSTRAINT [FK_QRTZ_TRIGGER_LISTENERS_QRTZ_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE


ALTER TABLE [dbo].[QRTZ_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_TRIGGERS_QRTZ_JOB_DETAILS] FOREIGN KEY
  (
    [JOB_NAME],
    [JOB_GROUP]
  ) REFERENCES [dbo].[QRTZ_JOB_DETAILS] (
    [JOB_NAME],
    [JOB_GROUP]
  )


INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('TRIGGER_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('JOB_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('CALENDAR_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('STATE_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('MISFIRE_ACCESS');

CREATE INDEX [QRTZ_JOB_DETAILS_I] ON [dbo].[QRTZ_JOB_DETAILS]([JOB_NAME],[JOB_GROUP]);
CREATE INDEX [QRTZ_JOB_LISTENERS_I] ON [dbo].[QRTZ_JOB_LISTENERS]([JOB_NAME],[JOB_GROUP],[JOB_LISTENER]);
CREATE INDEX [QRTZ_TRIGGERS_I] ON [dbo].[QRTZ_TRIGGERS]([TRIGGER_NAME],[TRIGGER_GROUP]);
CREATE INDEX [QRTZ_SIMPLE_TRIGGERS_I] ON [dbo].[QRTZ_SIMPLE_TRIGGERS]([TRIGGER_NAME],[TRIGGER_GROUP]);
CREATE INDEX [QRTZ_CRON_TRIGGERS_I] ON [dbo].[QRTZ_CRON_TRIGGERS]([TRIGGER_NAME],[TRIGGER_GROUP]);
CREATE INDEX [QRTZ_TRIGGER_LISTENERS_I] ON [dbo].[QRTZ_TRIGGER_LISTENERS]([TRIGGER_NAME],[TRIGGER_GROUP],[TRIGGER_LISTENER]);
CREATE INDEX [QRTZ_PAUSED_TRIGGER_GRPS_I] ON [dbo].[QRTZ_PAUSED_TRIGGER_GRPS]([TRIGGER_GROUP]);
CREATE INDEX [QRTZ_FIRED_TRIGGERS_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([ENTRY_ID]);
CREATE INDEX [QRTZ_SCHEDULER_STATE_I] ON [dbo].[QRTZ_SCHEDULER_STATE]([INSTANCE_NAME]);
CREATE INDEX [QRTZ_LOCKS_I] ON [dbo].[QRTZ_LOCKS]([LOCK_NAME]);

CREATE INDEX [QRTZ_JDET_REQ_RECOVERY_I] ON [dbo].[QRTZ_JOB_DETAILS]([REQUESTS_RECOVERY]);
CREATE INDEX [QRTZ_T_NEXT_FIRE_TIME_I] ON [dbo].[QRTZ_TRIGGERS]([NEXT_FIRE_TIME]);
CREATE INDEX [QRTZ_T_TRIGGER_STATE_I] ON [dbo].[QRTZ_TRIGGERS]([TRIGGER_STATE]);
CREATE INDEX [QRTZ_T_NFT_ST_I] ON [dbo].[QRTZ_TRIGGERS]([NEXT_FIRE_TIME],[TRIGGER_STATE]);
CREATE INDEX [QRTZ_T_VOLATILE_I] ON [dbo].[QRTZ_TRIGGERS]([IS_VOLATILE]);
CREATE INDEX [QRTZ_FT_TNAME_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([TRIGGER_NAME]);
CREATE INDEX [QRTZ_FT_TGROUP_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([TRIGGER_GROUP]);
CREATE INDEX [QRTZ_FT_TRIG_NM_GP_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([TRIGGER_NAME],[TRIGGER_GROUP]);
CREATE INDEX [QRTZ_FT_TRIG_VOLATILE_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([IS_VOLATILE]);
CREATE INDEX [QRTZ_FT_INST_NAME_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([INSTANCE_NAME]);
CREATE INDEX [QRTZ_FT_JOB_NAME_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([JOB_NAME]);
CREATE INDEX [QRTZ_FT_JOB_GROUP_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([JOB_GROUP]);
CREATE INDEX [QRTZ_FT_JOB_STATEFUL_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([IS_STATEFUL]);
CREATE INDEX [QRTZ_FT_JOB_REQ_RECOVERY_I] ON [dbo].[QRTZ_FIRED_TRIGGERS]([REQUESTS_RECOVERY]);


